<link rel="icon" type="image/png" href="http://webdamn.com/wp-content/themes/v2/webdamn.png">
</head>
<body class="">
<div role="navigation" class="navbar navbar-default navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a href="index.php" class="navbar-brand">HOME</a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="index.php">Home</a></li>
			 <li class="active"><a href="#" id="Price">price</a></li>
			 <li class="active"><a href="#" id="Partner">Partner</a></li>
			 <li class="active"><a href="#" id="User">User</a></li>
			 <li class="active"><a href="#" id="Registerstudent">Register Student (Đăng ký học sinh)</a></li>
			 <li class="active"><a href="#" id="Registerparent">Register Parent (Đăng ký Phụ Huynh)</a></li>
			 <li class="active"><a href="#" id="Deposit">Deposit Money (Nạp tiền)</a></li>
			 <input type="hidden" value="<?php if(isset($_SESSION['userid'])) echo $_SESSION['userid'];?>" name="Id">
           
          </ul>
         
        </div><!--/.nav-collapse -->
      </div>
    </div>
	
	<div class="container" style="min-height:500px;">
	<div class=''>
	</div>
	<script>
	/*$(document).ready(function() {
    $('#Price').click(function(event) {
        event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết
        // Lấy giá trị của thẻ input có id là 'Id'
			var idValue = $("#Id").val();
        // Gửi yêu cầu AJAX để lấy nội dung
        $.ajax({
            url: 'get_price.php', // Đường dẫn đến tệp PHP
            method: 'POST',
			 data: { Id:idValue },
            success: function(response) {
                // Hiển thị kết quả trong phần tử #content
                //$('#content').html(response);
				$('#content').html(response.Id1);
            },
            error: function() {
                $('#content').html('<p>An error has occurred</p>');
            }
        });
    });
});*/
</script>

	