<?php
header("Content-Type: application/json");
$API_KEY = "123456";

if(!isset($_GET['key']) || $_GET['key'] != $API_KEY){
    echo json_encode([
        "success" => false,
        "message" => "Sai API KEY"
    ]);
    exit;
}

require_once("User.php");

$user = new User();

// lấy action từ request
$action = $_GET['action'] ?? '';

switch($action){

    case "login":
        login($user);
        break;

    case "getData":
        getData($user);
        break;

    default:
        echo json_encode([
            "success" => false,
            "message" => "API không hợp lệ"
        ]);
}

?>