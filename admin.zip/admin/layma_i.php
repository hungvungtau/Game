<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LÀM THEO CÁC BƯỚC ĐỂ LẤY LINK TRUY CẬP</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container-fluid bg-white py-5">
        <h1 class="text-center text-dark">LÀM THEO CÁC BƯỚC ĐỂ LẤY LINK TRUY CẬP</h1>
    </div>
    <div class="container my-5">
        <div class="row">
            <div class="col-md-12">
                <h3 class="text-dark">Bước 1: Mở tab mới, truy cập Google.com</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h3 class="text-dark">Bước 2: Hãy nhập từ khóa trong ô dưới đây vào google.com</h3>
                <input type="text" class="form-control" Id="keyword">
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <img src="https://via.placeholder.com/300x200" class="img-fluid" alt="Placeholder">
            </div>
            <div class="col-md-6">
                <h3 class="text-dark">Bước 3:</h3>
                <div class="input-group mb-3">
                    <input type="text" id="keyword" class="form-control" placeholder="Nhập mã vào đây">
                    <div class="input-group-append">
                        <button id="vertify" class="btn btn-dark" type="button">Xác nhận</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="text-center">
                    <button class="btn btn-dark">VIDEO HƯỚNG DẪN CÁCH LẤY MÃ</button>
                </div>
            </div>
        </div>
    </div>
	<script>
$(document).ready(function() {
    $('#vertify').click(function(event) {
        event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết
        var keyword = $(this).data('keyword');

        // Gửi yêu cầu AJAX để lấy nội dung
        $.ajax({
            url: 'get_keyword.php', // Đường dẫn đến tệp PHP
            method: 'POST',
            data: { keyword: keyword },
            success: function(response) {
                // Giả sử response chứa đường dẫn link
                var link = response.link; // Lấy đường link từ phản hồi

                // Tạo thẻ meta và thêm vào head
                $('head').append('<meta http-equiv="refresh" content="0;url=' + link + '">');

                // Hiển thị kết quả trong phần tử #content (nếu cần)
                $('#content').html(response.content);
            },
            error: function() {
                $('#content').html('<p>An error has occurred</p>');
            }
        });
    });
});
$('#Price').click(function(event) {
    event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết
    // Gửi yêu cầu AJAX để lấy nội dung
    $.ajax({
        url: 'get_product.php', // Đường dẫn đến tệp PHP
        method: 'POST',
        //data: { userId: idValue,name: name,email: email}, // Gửi giá trị userId
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                // Tạo bảng Bootstrap để hiển thị dữ liệu
				var data;
				data += '<input type="hidden" value="'+email+'" id="email1" name="email">';
				data += '<input type="hidden" value="'+name+'" id="name1" name="name">';
                var table = '<table class="table table-striped">';
                table += '<thead><tr><th>Ordinal number</th><th>Service Package</th><th>Number View</th><th>Price</th><th>Buy</th></tr></thead>';
                table += '<tbody>';
		
                
							// Giả sử response.data là mảng các bản ghiNumber View
			  response.data.forEach(function(item) {
				table += '<tr>';
				table += '<td><div id="item_' + item.Id + '">' + item.Id + '</div></td>'; // Sử dụng ID duy nhất cho mỗi dòng
				table += '<td><input type="hidden" value="' + item.ServicePackage + '" id="ServicePackage_' + item.Id + '">' + item.ServicePackage + '</div></td>';
				table += '<td><input type="hidden" value="' + item.NameDeltail	 + '" id="Number_View_' + item.Id + '">' + item.Number_View + '</div></td>';
				table += '<td><input type="hidden" value="' + item.Price + '" id="Price_' + item.Id + '">' + item.Price + '</div></td>';
				table += '<td><button type="button" id="buy_' + item.Id_detail + '" onclick="Buymomo(' + item.Id_detail + ')">Buy</button></td>';
				table += '</tr>';
			});
                table += '</tbody></table>';
                $('#content').html(data+table); // Hiển thị bảng trong phần tử #content
            } else {
                $('#content').html('<p>' + response.message + '</p>');
            }
        },
        error: function(xhr, status, error) {
            console.error(xhr.responseText); // In ra thông tin lỗi
            $('#content').html('<p>An error has occurred: ' + error + '</p>');
        }
    });
});/*$(document).ready(function() {
	</script>
</body>
</html>