<?php
//session_start(); // Bật session để đảm bảo có $_SESSION['userid']
include('class/UserLink.php');
$user = new User1();

// Fetch links data
$links = $user->getdata1('question', true);

// Fetch categories for dropdown
$categories = $user->getdata1('categories', true);
?>  
<div class="container mt-4">
    <h2>Question Manager</h2>
    
    <!-- Message display area -->
    <div id="message" class="alert" style="display: none;"></div>
    
    <!-- Bulk action tools -->
    <div class="mb-3">
        <button id="selectAll" class="btn btn-sm btn-outline-secondary">Select All</button>
        <button id="unselectAll" class="btn btn-sm btn-outline-secondary">Unselect All</button>
        <button id="deleteSelected" class="btn btn-sm btn-danger">Delete Selected</button>
    </div>
    
    <!-- Questions table -->
    <div class="table-responsive">
        <table class="table table-bordered table-hover" id="linksTable">
            <thead class="thead-dark">
                <tr>
                    <th width="40px"><input type="checkbox" id="checkAll"></th>
                    <th width="100px">Actions</th>
                    <th width="60px">Id</th>
                    <th width="150px">Id_Categories</th>
                    <th width="200px">Namequestion</th>
                    <th width="200px">Images</th>
                    <th width="200px">Question</th>
                    <th width="150px">Type</th>
                    <th width="150px">answer1</th>
                    <th width="150px">answer2</th>
                    <th width="150px">answer3</th>
                    <th width="150px">answer4</th>
                    <th width="150px">Correct_answer</th>
                    <th width="150px">Created_at</th>
                </tr>
            </thead>
            <tbody>
                <?php if(empty($links)): ?>
                    <tr>
                        <td colspan="14" class="text-center">No questions found</td>
                    </tr>
                <?php else: ?>
                    <?php foreach($links as $link): ?>
                        <tr data-id="<?php echo $link['Id']; ?>">
                            <td><input type="checkbox" class="link-checkbox" value="<?php echo $link['Id']; ?>"></td>
                            <td class="action-buttons">
                                <div class="normal-buttons">
                                    <button class="btn btn-sm btn-info edit-btn" data-id="<?php echo $link['Id']; ?>">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-danger delete-btn" data-id="<?php echo $link['Id']; ?>">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                                <div class="edit-buttons" style="display:none;">
                                    <button class="btn btn-sm btn-success save-inline-btn" data-id="<?php echo $link['Id']; ?>">
                                        <i class="fas fa-save"></i>
                                    </button>
                                    <button class="btn btn-sm btn-secondary cancel-inline-btn" data-id="<?php echo $link['Id']; ?>">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </td>
                            <td><?php echo $link['Id']; ?></td>
                            <td class="link-category" data-id="<?php echo $link['Id_Categories']; ?>">
                                <span class="display-text"><?php echo $link['Id_Categories']; ?></span>
                                <select class="form-control edit-input" style="display:none;">
                                    <?php foreach($categories as $cat): ?>
                                        <option value="<?php echo $cat['Id']; ?>" <?php echo ($cat['Id'] == $link['Id_Categories']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($cat['Category_name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td class="link-namequestion">
                                <span class="display-text"><?php echo htmlspecialchars($link['Namequestion']); ?></span>
                                <input type="text" class="form-control edit-input" value="<?php echo htmlspecialchars($link['Namequestion']); ?>" style="display:none;">
                            </td>
                            <td class="link-images">
                                <span class="display-text"><?php echo htmlspecialchars($link['Images']); ?></span>
                                <input type="text" class="form-control edit-input" value="<?php echo htmlspecialchars($link['Images']); ?>" style="display:none;">
                            </td>
                            <td class="link-question">
                                <span class="display-text"><?php echo htmlspecialchars($link['Question']); ?></span>
                                <textarea class="form-control edit-input" style="display:none;"><?php echo htmlspecialchars($link['Question']); ?></textarea>
                            </td>
                            <td class="link-type">
                                <span class="display-text"><?php echo htmlspecialchars($link['Type']); ?></span>
                                <select class="form-control edit-input" style="display:none;">
                                    <option value="multiple" <?php echo ($link['Type'] == 'multiple') ? 'selected' : ''; ?>>Multiple</option>
                                    <option value="truefalse" <?php echo ($link['Type'] == 'truefalse') ? 'selected' : ''; ?>>True/False</option>
                                    <option value="single" <?php echo ($link['Type'] == 'single') ? 'selected' : ''; ?>>Single</option>
                                    <option value="drag_and_drop" <?php echo ($link['Type'] == 'drag_and_drop') ? 'selected' : ''; ?>>Drag and Drop</option>
                                </select>
                            </td>
                            <td class="link-answer1">
                                <span class="display-text"><?php echo htmlspecialchars($link['answer1']); ?></span>
                                <input type="text" class="form-control edit-input" value="<?php echo htmlspecialchars($link['answer1']); ?>" style="display:none;">
                            </td>
                            <td class="link-answer2">
                                <span class="display-text"><?php echo htmlspecialchars($link['answer2']); ?></span>
                                <input type="text" class="form-control edit-input" value="<?php echo htmlspecialchars($link['answer2']); ?>" style="display:none;">
                            </td>
                            <td class="link-answer3">
                                <span class="display-text"><?php echo htmlspecialchars($link['answer3']); ?></span>
                                <input type="text" class="form-control edit-input" value="<?php echo htmlspecialchars($link['answer3']); ?>" style="display:none;">
                            </td>
                            <td class="link-answer4">
                                <span class="display-text"><?php echo htmlspecialchars($link['answer4']); ?></span>
                                <input type="text" class="form-control edit-input" value="<?php echo htmlspecialchars($link['answer4']); ?>" style="display:none;">
                            </td>
                            <td class="link-correct-answer">
                                <span class="display-text"><?php echo htmlspecialchars($link['Correct_answer']); ?></span>
                                <textarea class="form-control edit-input" style="display:none;"><?php echo htmlspecialchars($link['Correct_answer']); ?></textarea>
                            </td>
                            <td class="link-created-at">
                                <span class="display-text"><?php echo htmlspecialchars($link['Created_at']); ?></span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- JavaScripts for Question Manager -->
<script>
$(document).ready(function() {
    // Check/Uncheck all checkboxes
    $('#checkAll').on('click', function() {
        $('.link-checkbox').prop('checked', this.checked);
    });
    
    $('#selectAll').on('click', function() {
        $('.link-checkbox').prop('checked', true);
    });
    
    $('#unselectAll').on('click', function() {
        $('.link-checkbox').prop('checked', false);
    });
    
    // Edit question action - Enable inline editing
    $(document).on('click', '.edit-btn', function() {
        const questionId = $(this).data('id');
        const row = $('tr[data-id="' + questionId + '"]');
        
        // Show input fields, hide display text
        row.find('.display-text').hide();
        row.find('.edit-input').show();
        
        // Show save/cancel buttons, hide normal buttons
        row.find('.normal-buttons').hide();
        row.find('.edit-buttons').show();
    });
    
    // Cancel inline editing
    $(document).on('click', '.cancel-inline-btn', function() {
        const questionId = $(this).data('id');
        const row = $('tr[data-id="' + questionId + '"]');
        
        // Hide input fields, show display text
        row.find('.display-text').show();
        row.find('.edit-input').hide();
        
        // Show normal buttons, hide save/cancel buttons
        row.find('.normal-buttons').show();
        row.find('.edit-buttons').hide();
    });
    
    // Save inline changes
    $(document).on('click', '.save-inline-btn', function() {
        const questionId = $(this).data('id');
        const row = $('tr[data-id="' + questionId + '"]');
        
        // Get values from input fields
        const id_categories = row.find('.link-category .edit-input').val();
        const namequestion = row.find('.link-namequestion .edit-input').val();
        const images = row.find('.link-images .edit-input').val();
        const question = row.find('.link-question .edit-input').val();
        const type = row.find('.link-type .edit-input').val();
        const answer1 = row.find('.link-answer1 .edit-input').val();
        const answer2 = row.find('.link-answer2 .edit-input').val();
        const answer3 = row.find('.link-answer3 .edit-input').val();
        const answer4 = row.find('.link-answer4 .edit-input').val();
        const correct_answer = row.find('.link-correct-answer .edit-input').val();
        
        // Show loading message
        $('#message').removeClass().addClass('alert alert-info').text('Saving changes...').show();
        
        // Debugging - show data being sent
        console.log("Data being sent:", {
            Id: questionId,
            Id_Categories: id_categories,
            Namequestion: namequestion,
            Images: images,
            Question: question,
            Type: type,
            answer1: answer1,
            answer2: answer2,
            answer3: answer3,
            answer4: answer4,
            Correct_answer: correct_answer
        });
        
        // Save changes with AJAX
        $.ajax({
            url: 'update_question.php',
            type: 'POST',
            data: {
                Id: questionId,
                Id_Categories: id_categories,
                Namequestion: namequestion,
                Images: images,
                Question: question,
                Type: type,
                answer1: answer1,
                answer2: answer2,
                answer3: answer3,
                answer4: answer4,
                Correct_answer: correct_answer
            },
            cache: false, // Vô hiệu hóa cache
            dataType: 'json',
            success: function(response) {
                console.log("Success response:", response); // Log the response
                
                if (response.success) {
                    // Update display values
                    row.find('.link-category .display-text').text(id_categories);
                    row.find('.link-namequestion .display-text').text(namequestion);
                    row.find('.link-images .display-text').text(images);
                    row.find('.link-question .display-text').text(question);
                    row.find('.link-type .display-text').text(type);
                    row.find('.link-answer1 .display-text').text(answer1);
                    row.find('.link-answer2 .display-text').text(answer2);
                    row.find('.link-answer3 .display-text').text(answer3);
                    row.find('.link-answer4 .display-text').text(answer4);
                    row.find('.link-correct-answer .display-text').text(correct_answer);
                    
                    // Hide input fields, show display text
                    row.find('.display-text').show();
                    row.find('.edit-input').hide();
                    
                    // Show normal buttons, hide save/cancel buttons
                    row.find('.normal-buttons').show();
                    row.find('.edit-buttons').hide();
                    
                    // Show success message
                    $('#message').removeClass().addClass('alert alert-success')
                        .text(response.message).show().delay(3000).fadeOut();
                } else {
                    // Show error message
                    $('#message').removeClass().addClass('alert alert-danger')
                        .text(response.message).show();
                }
            },
            error: function(xhr, status, error) {
                console.log("Error:", status, error); // Log detailed error
                console.log("Response:", xhr.responseText); // Log the actual response text
                
                // Show error message
                $('#message').removeClass().addClass('alert alert-danger')
                    .text('Error saving question: ' + (xhr.responseJSON ? xhr.responseJSON.message : error))
                    .show();
            }
        });
    });
    
    // Delete question action
    $(document).on('click', '.delete-btn', function() {
        const questionId = $(this).data('id');
        
        if (confirm('Are you sure you want to delete this question?')) {
            $.ajax({
                url: 'delete_question.php',
                type: 'POST',
                data: { Id: questionId },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        $('tr[data-id="' + questionId + '"]').fadeOut(300, function() {
                            $(this).remove();
                            $('#message').removeClass().addClass('alert alert-success')
                                .text(response.message).show().delay(3000).fadeOut();
                        });
                    } else {
                        $('#message').removeClass().addClass('alert alert-danger')
                            .text(response.message).show();
                    }
                },
                error: function(xhr) {
                    $('#message').removeClass().addClass('alert alert-danger')
                        .text('Error deleting question: ' + (xhr.responseJSON ? xhr.responseJSON.message : xhr.statusText))
                        .show();
                }
            });
        }
    });
    
    // Delete selected questions
    $('#deleteSelected').on('click', function() {
        const selectedIds = $('.link-checkbox:checked').map(function() {
            return this.value;
        }).get();
        
        if (selectedIds.length === 0) {
            alert('Please select at least one question to delete.');
            return;
        }
        
        if (confirm('Are you sure you want to delete ' + selectedIds.length + ' selected questions?')) {
            $.ajax({
                url: 'delete_multiple_questions.php',
                type: 'POST',
                data: { ids: selectedIds },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        $.each(selectedIds, function(index, id) {
                            $('tr[data-id="' + id + '"]').fadeOut(300, function() {
                                $(this).remove();
                            });
                        });
                        $('#message').removeClass().addClass('alert alert-success')
                            .text(response.message).show().delay(3000).fadeOut();
                    } else {
                        $('#message').removeClass().addClass('alert alert-danger')
                            .text(response.message).show();
                    }
                },
                error: function(xhr) {
                    $('#message').removeClass().addClass('alert alert-danger')
                        .text('Error deleting questions: ' + (xhr.responseJSON ? xhr.responseJSON.message : xhr.statusText))
                        .show();
                }
            });
        }
    });
});
</script>