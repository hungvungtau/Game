<?php
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header('Content-Type: application/json');
session_start();
include('class/UserLink.php');

if (!isset($_SESSION['userid'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

// Kiểm tra đúng tên field AJAX gửi lên
if (
    !isset($_POST['id']) || empty($_POST['id']) ||
    !isset($_POST['id_hocsinh']) || $_POST['id_hocsinh'] === '' ||
    !isset($_POST['id_noidung']) || $_POST['id_noidung'] === '' ||
    !isset($_POST['active'])
) {
    echo json_encode(['success' => false, 'message' => 'Thiếu dữ liệu bắt buộc']);
    exit;
}

$id         = intval($_POST['id']);
$id_hocsinh = intval($_POST['id_hocsinh']);
$id_noidung = intval($_POST['id_noidung']);
$active     = intval($_POST['active']);

$user = new User1();

try {
    $result = $user->updateHocSinhNoiDung(
        $id,
        $id_hocsinh,
        $id_noidung,
        $active
    );

    if ($result['success']) {
        echo json_encode(['success' => true, 'message' => 'Cập nhật thành công']);
    } else {
        echo json_encode(['success' => false, 'message' => $result['message']]);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Lỗi: ' . $e->getMessage()]);
}
?>