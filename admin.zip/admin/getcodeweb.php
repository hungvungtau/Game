<?php
session_start();
if (isset($_SESSION["userid"])) $id = $_SESSION["userid"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Copy Code Example</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            text-align: center;
        }
        #result {
            margin-top: 20px;
            font-size: 24px;
            font-weight: bold;
        }
        textarea {
            width: 100%;
            height: 150px;
            margin-top: 20px;
            font-family: monospace;
            font-size: 14px;
        }
        button {
            margin-top: 10px;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <h2>Code You Insert into your Website</h2>
	<h2> (Bạn copy code chèn vào các trang muốn view)</h2>
    <textarea id="codeSnippet" readonly>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="http://marketingfunnel.top/insertcode.js"></script>
        <style>
            body {
                font-family: Arial, sans-serif;
                padding: 20px;
                text-align: center;
            }
            #result {
                margin-top: 20px;
                font-size: 24px;
                font-weight: bold;
            }
        </style>
        <h1>Lấy Mã Code Ngẫu Nhiên</h1>
        <input type="hidden" id="ma" value="NTc5MDc5"/>
        <input type="hidden" id="id" value="<?php echo $id; ?>" />
        <button id="getRandomCode">Get Code (Lấy mã code)</button>
        <div id="result"></div>
        <div id="result1"></div>
        <div id="nd"></div>
    </textarea>
    <button id="copyButton">Copy Code</button> <!-- Nút sao chép -->
</div>
<div id="message"></div>
<div id="addWebsiteForm"></div>

<script>
    document.getElementById('copyButton').addEventListener('click', function() {
        // Lấy textarea
        var textarea = document.getElementById('codeSnippet');
        
        // Chọn nội dung trong textarea
        textarea.select();
        textarea.setSelectionRange(0, 99999); // Cho các thiết bị di động
        
        // Sao chép nội dung vào bộ nhớ tạm
        document.execCommand('copy');

        // Hiển thị thông báo
        document.getElementById('message').innerText = 'Code đã được sao chép vào bộ nhớ tạm!';
    });
</script>
</body>
</html>