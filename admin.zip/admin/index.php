<?php 
include('class/User.php');
$user = new User();
$user->loginStatus();
include('include/header.php');
?>
<title>Increase website traffic free SSC</title>
<?php include('include/container.php');?>
<div class="container contact">	
	<h2>Increase website traffic free SSC</h2>	
	<?php include('menu.php');?>
	<div class="table-responsive" id="message">	
	
	</div>
</div>	
<?php include('include/footer.php');?>