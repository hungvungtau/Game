<?php
session_start();
//including the database connection file
include_once("config.php");
if (isset($_GET['id']))
{
  $id=$_GET['id'];
  $_SESSION["id"]=$id;
}
else
{
 $id=$_SESSION["id"];
}
//fetching data in descending order (lastest entry first)
//$result = mysql_query("SELECT * FROM users ORDER BY id DESC"); // mysql_query is deprecated
$sql="SELECT * FROM link where idlink='".$id."'";
$result = mysqli_query($mysqli,$sql); // using mysqli_query instead
$result1 = mysqli_query($mysqli, "SELECT * FROM danhmucweb"); // using mysqli_query instead
?>

<html>
<head>	
	<title>Gia Sư Dạy Kèm Tin Học Văn Phòng Bát Nhã</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<body>
<div class="container">
<fieldset>
<div style="text-align:center; font-weight:bold; color:#0000FF;">YOUR LINK IS PROCESSING</div>
<div style="text-align:center; font-weight:bold; color:#0000FF;">PLEASE WAIT A FEW SECONDS</div>
<div>
  <p>(vi)&nbsp;<strong>Li&ecirc;n k&#7871;t link&nbsp;</strong>c&#7911;a b&#7841;n &#273;ang &#273;&#432;&#7907;c x&#7917; l&yacute;. B&#7841;n vui l&ograve;ng &#273;&#7907;i trong gi&acirc;y l&aacute;t v&agrave; &#7845;n "<strong>Get Link</strong>" &#273;&#7875; chuy&#7875;n h&#432;&#7899;ng truy c&#7853;p.</p>
</div>
<p>(en)&nbsp;<strong>Your link</strong>&nbsp;is being processed. Please wait a moment and press "<strong>Get Link</strong>" to access your link</p>
 <table class="table table-bordered">
	<?php 
	//while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array 
	while($res = mysqli_fetch_array($result)) 
	{
	    $row=$res['url'];	
		$Tenfile=$res['tenfile'];
	}
		//$row[]=$res;
	while($res1 = mysqli_fetch_array($result1)) { 		
	    $row1[]=$res1;	
	}
	$num1 = array_rand($row1);
	//echo $num;
$item = $row1[$num1];
//echo $rowlink=$row[2];
$linkweb="http://".$item['linkweb']."/downloads/";
//printf('<a href="%s?url=%s" target="_blank"><img src="Get Link.png"></a>',$linkweb, $row, $item['linkweb']);
//<meta http-equiv="refresh" content="15;url=http://www.new-url.com/">
?>
</table>
<?php

if(isset($_POST['ok']))
{
	if($_POST['txtCaptcha'] == NULL)
	{
		echo "Please enter your code";
	}
	else
	{
		if($_POST['txtCaptcha'] == $_SESSION['security_code'])
		{
			echo "Mời Bạn nhấp vào Link để nhận tài liệu";
			//<meta http-equiv=”Refresh” content=”10;url=http://www.urltoredirect.com“>
			//printf('setTimeout(function(){document.write("<a href="%s?url=%s" target="_blank" ><img src="Get Link.png"></a>',$linkweb, $row, $item['linkweb'])}, 30000)');
			echo "Bạn đang tải tài liệu <H2><b>".$Tenfile."</b></H2></br>";
			printf('<a href="%s?url=%s" target="_blank"><img src="Get Link.png"></a>',$linkweb, $row, $item['linkweb']);
		}
		else
		{
			echo "Mời bạn nhập lại mã bảo mật";
		}
	}
}
else
{
?>
<form action="view.php" method=post>
<table class="table table-bordered" width="30%">
<tbody>
<tr class="active" width="30%">
    <td style="font-weight:bold">Mã bảo vệ</td>
	 <td>
      <img src="random_image.php" width="70%"/>
    </td>
   </tr>
  <tr class="active" width="50%">
    <td align="left">
      <label for="captcha">Nhập mã bảo vệ</label>
    </td>
    <td>
     <input type="text" name="txtCaptcha" maxlength="7" size="15" height="70%" autocomplete="off"/>
    </td>
    <td> </tr>
  <tr class="active">
    <td>&nbsp;</td>
    <td>
      <input type=submit name=ok value="Check" />
    </td>
  </tr>
  </tbody>
</table> 
</form>
</div>
<?php } ?>
</fieldset>
</body>
</html>
