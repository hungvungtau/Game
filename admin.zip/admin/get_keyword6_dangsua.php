<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Connection: keep-alive");
header("Content-Type: application/json; charset=UTF-8");
header("Expires: Thu, 19 Nov 1981 08:52:00 GMT");
header("Pragma: no-cache");
header("Vary: Accept-Encoding");
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");
header("X-XSS-Protection: 1; mode=block");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

function msg($success, $status, $message, $extra = []) {
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ], $extra);
}

function getPostObject() {
    $str = file_get_contents('php://input');
    $std = json_decode($str);
    
    if ($std === null) {
        $std = new stdClass();
        $array = explode('&', $str);
        foreach ($array as $parm) {
            $parts = explode('=' ,$parm);
            if (sizeof($parts) != 2) {
                continue;
            }
            $key = urldecode($parts[0]);
            $value = urldecode($parts[1]);
            $std->$key = $value === '' ? null : $value;
        }
    }
    return $std;
}
$data = getPostObject();
$returnData = [];
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0, 404, 'Page Not Found!');
} elseif (!isset($data->id) || !isset($data->Id) || !isset($data->keyword)) {
    $fields = ['fields' => ['id', 'Id', 'keyword']];
    $returnData = msg(0, 422, 'Please Fill in all Required Fields!', $fields);
} else {
    $Id1 = trim($data->Id);
    $id = trim($data->id);
    $keyword = trim($data->keyword);
    
    include('class/User.php');
    include('class/UserLink.php');
    
    $user = new User();
    $user1 = new UserLink(); // Sửa lại tên lớp nếu cần

    /*$userTable = "link";
    $links = $user1->getLink1($userTable, $id);
    $link = null;
    if (!empty($links)) {
        foreach ($links as $linkRow) {
            $link = $linkRow['url']; // Giả định 'url' là một cột
        }
    } else {
		echo json_encode(['success' => false, 'message' => 'No links found.']);
        echo json_encode($returnData);
        exit;
    }*/

    // Lấy mã
   /* $Result = $user->getCode($Id1, "view", false);
    if (!empty($Result)) {
        $Code = $Result[0]['Code'];
    } else {
        echo json_encode(['success' => false, 'message' => 'Not yet Code.']);
        exit;
    }*/

    // So sánh mã nhập vào với mã trong cookie
    if ($keyword === $Code) {
        echo json_encode(['success' => true, 'message' => "You entered successfully", 'link' => $link]);
    } else {
        echo json_encode(['success' => false, 'message' => 'You entered code not successful.']);
    }
}
?>