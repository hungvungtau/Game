<?php //session_start(); // Khởi động phiên làm việc
include('class/User.php');

class NetworkManager {
    private $ethIP = '';
    private $ethDns = '';
    private $ethName = '';

    private $wifiIP = '';
    private $wifiDns = '';
    private $wifiName = '';

    private $newIps = [];
    private $stepNewIp = 0;

    public function getWifiInfo() {
        $this->wifiIP = '';
        $this->wifiDns = '';
        $this->wifiName = '';

        // Lấy thông tin WiFi
        $interfaces = $this->getNetworkInterfaces();
        foreach ($interfaces as $ni) {
            if ($ni['type'] == 'Wireless') {
                $this->wifiName = $ni['name'];
                $this->wifiIP = $ni['ip'];
                $this->wifiDns = $ni['dns'];
                break;
            }
        }
    }

    public function getEthernetInfo() {
        $this->ethIP = '';
        $this->ethDns = '';
        $this->ethName = '';

        // Lấy thông tin Ethernet
        $interfaces = $this->getNetworkInterfaces();
        foreach ($interfaces as $ni) {
            if ($ni['type'] == 'Ethernet') {
                $this->ethName = $ni['name'];
                $this->ethIP = $ni['ip'];
                $this->ethDns = $ni['dns'];
                break;
            }
        }
    }

    private function getNetworkInterfaces() {
        // Logic để lấy thông tin mạng (cần sử dụng thư viện hoặc lệnh hệ thống)
        // Trả về danh sách các giao diện mạng với tên, IP, DNS và loại
        return [];
    }

    public function getNewIP($ip, $dns) {
        $dsIP = [];
        $ipParts = explode('.', $ip);
        $ipBase = implode('.', array_slice($ipParts, 0, -1)) . '.';
        $dnsLastOctet = (int)explode('.', $dns)[3];

        for ($i = $dnsLastOctet + 1; $i <= 254; $i++) {
            $newIp = $ipBase . $i;
            if ($newIp !== $dns && $newIp !== $ip) {
                $dsIP[] = $newIp;
            }
        }
        return $dsIP;
    }

    public function randomIP() {
        $this->getEthernetInfo();
        $this->getWifiInfo();

        if ($this->ethIP) {
            $this->newIps = $this->getNewIP($this->ethIP, $this->ethDns);
            $this->stepNewIp = 0;
            $newIp = $this->newIps[$this->stepNewIp];
            $this->setStaticIP($this->ethName, $newIp, $this->ethDns);
        } else {
            $this->newIps = $this->getNewIP($this->wifiIP, $this->wifiDns);
            $this->stepNewIp = 0;
            $newIp = $this->newIps[$this->stepNewIp];
            $this->setStaticIP($this->wifiName, $newIp, $this->wifiDns);
        }
    }

    public function setStaticIP($interface, $ip, $dns) {
        $subnet = '255.255.255.0';
        $command = "netsh interface ip set address \"$interface\" static $ip $subnet $dns";
        $command .= " & netsh interface ip set dns \"$interface\" static $dns";

        $this->executeCommand($command);
    }

    private function executeCommand($command) {
        // Chạy lệnh hệ thống
        $output = [];
        $returnVar = 0;
        exec("cmd.exe /c $command", $output, $returnVar);

        if ($returnVar !== 0) {
            // Xử lý lỗi nếu cần
            echo "Error executing command: " . implode("\n", $output);
        }
    }

    public function setNewIP() {
        $this->stepNewIp++;
        if ($this->stepNewIp >= count($this->newIps)) {
            $this->stepNewIp = 0;
        }

        if ($this->ethIP) {
            $newIp = $this->newIps[$this->stepNewIp];
            $this->setStaticIP($this->ethName, $newIp, $this->ethDns);
        } else {
            $newIp = $this->newIps[$this->stepNewIp];
            $this->setStaticIP($this->wifiName, $newIp, $this->wifiDns);
        }
    }
}

// Ví dụ sử dụng
//$networkManager = new NetworkManager();
//$networkManager->randomIP(); // Gọi hàm để thực hiện thiết lập IP ngẫu nhiên



// Khởi tạo đối tượng User
//$user = new User();
$user = new User();
// Gọi hàm getLinks với tên bảng là 'linkwebsite' getwebsite
//$links=$user->getLinks('linkwebsite');
$website=$user->getwebsite('linkwebsite');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Websites</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        #timer {
            font-size: 24px;
            margin-top: 20px;
        }
					table {
			  border-collapse: collapse;
			  width: 100%;
			}

			th, td {
			  padding: 8px;
			  text-align: left;
			  border-bottom: 1px solid #ddd;
			}

			th {
			  background-color: #f2f2f2;
			}

			th:first-child, td:first-child {
			  width: 10%; /* Chiều rộng cột Serial Number */
			}

			th:nth-child(2), td:nth-child(2) {
			  width: 20%; /* Chiều rộng cột Site */
			}

			th:nth-child(3), td:nth-child(3) {
			  width: 30%; /* Chiều rộng cột Link */
			}

			th:nth-child(4), td:nth-child(4) {
			  width: 15%; /* Chiều rộng cột Status */
			}

			th:nth-child(5), td:nth-child(5) {
			  width: 15%; /* Chiều rộng cột Action */
			}

			th:last-child, td:last-child {
			  width: 10%; /* Chiều rộng cột Visits */
			}
    </style>
</head>
<body>

<h1>Website Links</h1>
<div id="linkList">
	<table>
  <thead >
    <tr>
	   <th>Serial Number</th>
      <th>Site</th>
      <th>Link</th>
      <th>Status</th>
	   <th>Action</th>
	  <th>Visits</th>
    </tr>
  </thead>
  <tbody>
    <?php $Stt=0; foreach ($website as $website): $Stt=$Stt+1;?>
    <tr>
	   <td><?php echo $Stt; ?></td>
      <td><?php echo htmlspecialchars($website['Tenwebsite']); ?></td>
      <td>
	 <input id="id[<?php echo $Stt; ?>]" type="hidden" value="<?php echo $website['Id']; ?>">
	  <input type="text" value="<?php echo htmlspecialchars($website['Link']); ?>">
	  </td>
      <td>
        <button type="button" name="update" id="<?php echo $website['Id']; ?>" class="btn btn-warning btn-xs update" onclick="UpdateLink()">Update</button>
        <button type="button" name="delete" id="<?php echo $website['Id']; ?>" class="btn btn-danger btn-xs delete">Delete</button>
      </td>
	  <td>     <button class="view-button" data-id="<?php echo $website['Id']; ?>" data-link="<?php echo htmlspecialchars($website['Link']); ?>" >Click</button></td>
	   <td>
	    <td class="visits" ><div id="<?php echo "id".$website['Id']; ?>"><?php echo $website['View']; ?></div></td>
	  </td>
	 
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>
</div>

<div id="timer"></div> <!-- Thêm đồng hồ hiển thị -->
<div id="countdownDisplay"></div>
    
<script>
$(document).ready(function() {
    let currentIndex = 0;
    const website1 = $(".view-button");
    let currentWindow;
    //Getlink();
    function getRandomInRange(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
    /*function countdown(seconds,Id) {
    let timeLeft = seconds;
    const displayElement = document.getElementById(Id);

    const countdownInterval = setInterval(() => {
        displayElement.textContent = timeLeft; // Cập nhật nội dung phần tử
        timeLeft--;

        if (timeLeft < 0) {
            clearInterval(countdownInterval); // Dừng đếm ngược khi hết thời gian
            displayElement.textContent = "Thời gian đã hết!"; // Thông báo khi hết thời gian
        }
    }, 1000); // Cập nhật mỗi giây
}*/
  function countdown(seconds) {
    let timeLeft = seconds;
    const displayElement = document.getElementById("countdownDisplay");

    const countdownInterval = setInterval(() => {
        displayElement.textContent = timeLeft; // Cập nhật nội dung phần tử
        timeLeft--;

        if (timeLeft < 0) {
            clearInterval(countdownInterval); // Dừng đếm ngược khi hết thời gian
            displayElement.textContent = "Thời gian đã hết!"; // Thông báo khi hết thời gian
        }
    }, 1000); // Cập nhật mỗi giây
}
function Updateview(id){
 $.post('update_view.php', { id: id }, function(response) {
        //alert(response); // Kiểm tra phản hồi từ server
    }).fail(function() {
        //alert("Có lỗi xảy ra khi gửi yêu cầu.");
    });
}

    function UpdateLink(){
		$(document).ready(function() {
    $(".update").click(function() {
        // Lấy ID và dữ liệu từ nút
        const id = $(this).attr("id");
        const tenWebsite = $(this).data("tenwebsite");
        const link = $(this).data("website");
        const view = 0; // Bạn có thể thay đổi số lượt view nếu cần

        // Gửi yêu cầu AJAX để cập nhật
        $.ajax({
            url: 'update_link.php', // Đường dẫn đến file PHP xử lý
            type: 'POST',
            data: {
                id: id,
                tenwebsite: tenWebsite,
                link: link,
                view: view // Gửi số lượt view nếu cần
            },
            success: function(response) {
                alert(response); // Hiển thị phản hồi từ server

                // Cập nhật giao diện nếu cần
                // Ví dụ: cập nhật số lượt view hiển thị
                // $("#view-" + id).text(view); // Nếu bạn có một phần tử để hiển thị số lượt view
            },
            error: function(xhr, status, error) {
                console.error("Có lỗi xảy ra: " + error);
                alert("Đã xảy ra lỗi khi cập nhật. Vui lòng thử lại!");
            }
        });
    });
});
	}
	// Tạo mảng hai chiều
let idCountArray = [];

// Hàm để thêm hoặc cập nhật ID và biến đếm
// Cập nhật hoặc thêm ID và biến đếm
function addOrUpdateIdCount(id, count) {
    let found = false;
    for (let i = 0; i < idCountArray.length; i++) {
        if (idCountArray[i][0] === id) {
            // Nếu ID đã tồn tại, cập nhật biến đếm
            idCountArray[i][1] += count; // Cộng thêm count từ cơ sở dữ liệu
            found = true;
            break;
        }
    }
    
    // Nếu ID chưa tồn tại, thêm mới
    if (!found) {
        idCountArray.push([id, count]); // Thêm ID với biến đếm từ cơ sở dữ liệu
    }
}
// Hàm chính
var myVariables = {};
function updateViewCount(Id) {
    let dynamicVar = "id" + Id;
    let divContent = parseInt($('#id' + Id).text(), 10)+1; // Chuyển đổi giá trị chuỗi sang số

    // Kiểm tra xem ID đã được xử lý chưa
    if (myVariables[dynamicVar] == null) {				
        addOrUpdateIdCount(Id, divContent); // Gọi hàm cập nhật với nội dung ban đầu
        myVariables[dynamicVar] = 1; // Đánh dấu ID là đã xử lý
    } else {
        addOrUpdateIdCount(Id, 1); // Cập nhật với giá trị 1 nếu đã xử lý
    }

    // Lấy chỉ số từ idCountArray
    let index = idCountArray.findIndex(item => item[0] === Id);
    if (index !== -1) {
        $("#id" + Id).text(idCountArray[index][1]); // Cập nhật nội dung thẻ div
    } else {
        console.log("ID không tồn tại trong mảng.");
    }
}    
 // Mảng để lưu trữ thông tin website
let Links = [];
function Getlink() {
    $(document).ready(function() {
        // Gọi AJAX để lấy danh sách website
        $.ajax({
            url: 'get_link.php', // Đường dẫn đến file PHP
            type: 'POST',
            dataType: 'json', // Đảm bảo rằng bạn đang mong đợi JSON
            success: function(response) {
                if (response.success !== false) {
                    Links = response; // Lưu dữ liệu vào biến Links
                    //console.log(Links); // Kiểm tra dữ liệu
					 //alert(JSON.stringify(Links));
                } else {
                    alert('Lỗi: ' + response.message);
                }
            },
            error: function(xhr, status, error) {
                alert('Có lỗi xảy ra: ' + error);
            }
        });
    });
}
Getlink();
/*function Updateview(id){
 $.post('get_link.php', { id: id }, function(response) {
       // alert(response); // Kiểm tra phản hồi từ server
    }).fail(function() {
        //alert("Có lỗi xảy ra khi gửi yêu cầu.");
    });
}*/

// Gọi hàm Getlink khi trang được tải
//Getlink();
function openWebsite() {
        if (currentIndex < Links.length) {
           const website = $(website1[currentIndex]).data('link');  
		    //alert(website);
			const Id = $(website1[currentIndex]).data('id');
			//alert(JSON.stringify(Links));
			const Linkwesite = Links[currentIndex]; // Lấy thông tin website
            const link1 = Linkwesite.Link; // Giả sử link là một thuộc tính trong đối tượng website
			//alert(link1);
			// Ví dụ gọi hàm
			updateViewCount(Id); // Gọi hàm với ID 1
			//alert(link1);
            currentWindow = window.open(link1, '_blank'); // Mở website mới
			// Sử dụng hàm để lấy số ngẫu nhiên từ 40 đến 90
			//let timeLeft = Math.floor(Math.random() * (90 - 40 + 1)) + 40;
            let timeLeft = 40;
            $("#timer").text(timeLeft); // Hiển thị thời gian ban đầu
            Updateview(Id);
            const countdown = setInterval(() => {
                timeLeft--;
                $("#timer").text(timeLeft); // Cập nhật hiển thị thời gian
                if (timeLeft <= 0) {
                    clearInterval(countdown);
                    currentWindow.close(); // Đóng website sau 40 giây
                    currentIndex++;
                    $("#timer").text("10"); // Hiển thị thời gian chờ 10 giây
					// Gọi hàm countdown với 10 giây
					//countdown(10,"timer");
					 // Gọi hàm countdown với 10 giây
					//countdown(10);
                    setTimeout(() => {
                        if (currentIndex < Links.length) {
                            openWebsite(); // Mở website tiếp theo
                        } else {
                            currentIndex = 0; // Quay lại từ đầu
                            setTimeout(openWebsite, 10000); // Nghỉ 10 giây trước khi bắt đầu lại
                        }
                    }, 10000); // Nghỉ 10 giây trước khi mở website tiếp theo
                }
            }, 1000); // Cập nhật mỗi giây
        } else {
            currentIndex = 0; // Quay lại từ đầu
            setTimeout(openWebsite, 10000); // Nghỉ 10 giây trước khi bắt đầu lại
        }
    }

    $(".view-button").click(function() {
        currentIndex = 0; // Reset index khi nhấn nút
        openWebsite();
    });
});
</script>

</body>
</html>