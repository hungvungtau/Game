<?php
include('class/UserLink.php');
$user = new User1();

$hocsinhResult = $user->getAllHocSinh();
$hocsinhList = $hocsinhResult['success'] ? $hocsinhResult['data'] : array();

$noidungResult = $user->getAllNoiDung();
$noidungList = $noidungResult['success'] ? $noidungResult['data'] : array();
?>

<div class="container mt-4">
    <h2>Gán Nội Dung Cho Học Sinh</h2>

    <div id="message" class="alert" style="display: none;"></div>

    <div class="form-group">
        <label for="selectHocSinh"><strong>Chọn học sinh:</strong></label>
        <select id="selectHocSinh" class="form-control" style="max-width: 400px;">
            <option value="">-- Chọn học sinh --</option>
            <?php foreach ($hocsinhList as $hs): ?>
                <option value="<?php echo $hs['Id_hocsinh']; ?>">
                    <?php echo htmlspecialchars($hs['Hovaten']) . ' - ' . htmlspecialchars($hs['Lop']); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <hr>

    <h4>Danh sách nội dung (bấm "Gán" để thêm cho học sinh đã chọn)</h4>

    <div class="table-responsive">
        <table class="table table-bordered table-hover">
            <thead class="thead-dark">
                <tr>
                    <th width="60px">ID</th>
                    <th>Tên Nội Dung</th>
                    <th width="100px">Type</th>
                    <th>Folder</th>
                    <th width="100px">Hành động</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($noidungList)): ?>
                    <tr><td colspan="5" class="text-center">Chưa có nội dung nào</td></tr>
                <?php else: ?>
                    <?php foreach ($noidungList as $nd): ?>
                        <tr>
                            <td><?php echo $nd['id']; ?></td>
                            <td><?php echo htmlspecialchars($nd['ten_noidung']); ?></td>
                            <td><?php echo htmlspecialchars($nd['type']); ?></td>
                            <td><?php echo htmlspecialchars($nd['Folder']); ?></td>
                            <td>
                                <button class="btn btn-sm btn-primary btn-assign" data-id-noidung="<?php echo $nd['id']; ?>">
                                    Gán
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
$(document).ready(function() {

    $(document).on('click', '.btn-assign', function() {
        var $btn = $(this);
        var id_hocsinh = $('#selectHocSinh').val();
        var id_noidung = $btn.data('id-noidung');

        if (id_hocsinh === '') {
            $('#message').removeClass().addClass('alert alert-danger').text('Vui lòng chọn học sinh trước').show();
            return;
        }

        $btn.prop('disabled', true).text('Đang gán...');

        $.ajax({
            url: 'add_hocsinh_noidung.php',
            type: 'POST',
            data: {
                id_hocsinh: id_hocsinh,
                id_noidung: id_noidung
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    $('#message').removeClass().addClass('alert alert-success')
                        .text(response.message).show().delay(2000).fadeOut();
                } else {
                    $('#message').removeClass().addClass('alert alert-warning')
                        .text(response.message).show();
                }
            },
            error: function(xhr) {
                $('#message').removeClass().addClass('alert alert-danger')
                    .text('Lỗi: ' + xhr.responseText).show();
            },
            complete: function() {
                $btn.prop('disabled', false).text('Gán');
            }
        });
    });

});
</script>