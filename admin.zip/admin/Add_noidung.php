<?php
header('Content-Type: application/json'); // Đặt tiêu đề cho phản hồi JSON

include('class/UserLink.php');
$user = new User1();

// Add_noidung.php
// Lấy dữ liệu từ POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

	$response = []; // Khởi tạo phản hồi ngay từ đầu để tránh lỗi undefined

	if ($_POST['txtCaptcha'] == NULL)
	{
		$response['success'] = false;
		$response['message'] = "Please enter your code ";
	}
	else
	{
		if ($_POST['txtCaptcha'] == $_SESSION['security_code'])
		{
			$userId       = $_SESSION['userid']; // Sử dụng ID người dùng từ session
			$Partner      = isset($_SESSION["Partner"]) ? $_SESSION["Partner"] : null;

			$id_chuong    = isset($_POST['id_chuong'])    ? trim($_POST['id_chuong'])    : '';
			$ten_noidung  = isset($_POST['ten_noidung'])  ? trim($_POST['ten_noidung'])  : '';
			$type         = isset($_POST['type'])         ? trim($_POST['type'])         : '';
			$placeholder  = isset($_POST['placeholder'])  ? trim($_POST['placeholder'])  : '';
			$Namefunction = isset($_POST['Namefunction']) ? trim($_POST['Namefunction']) : '';
			$Folder       = isset($_POST['Folder'])       ? trim($_POST['Folder'])       : '';
			$Linkvideo    = isset($_POST['Linkvideo'])    ? trim($_POST['Linkvideo'])    : '';
			$active       = isset($_POST['active'])       ? (int)$_POST['active']        : 1;

			// Gọi hàm addNoiDung và kiểm tra kết quả
			$insertResult = $user->addNoiDung(array(
				'id_chuong'    => $id_chuong,
				'ten_noidung'  => $ten_noidung,
				'type'         => $type,
				'placeholder'  => $placeholder,
				'Namefunction' => $Namefunction,
				'Folder'       => $Folder,
				'Linkvideo'    => $Linkvideo,
				'active'       => $active
			));

			if (isset($insertResult['success']) && $insertResult['success'] == true)
			{
				$response['success'] = $insertResult['success'];
				$response['message'] = $insertResult['message'];
			}
			else
			{
				$response['success'] = false;
				$response['message'] = isset($insertResult['message']) ? $insertResult['message'] : 'Lỗi không xác định';
			}
		}
		else
		{
			$response['success'] = false;
			$response['message'] = "Error: Invalid code ";
		}
	}

	// Trả về dữ liệu dưới dạng JSON
	echo json_encode($response);
	exit; // Đảm bảo không có thêm thông tin nào được in
}
?>