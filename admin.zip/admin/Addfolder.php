<?php session_start(); ?>
<div class="container mt-5">
    <h2>Add Website</h2>

    <select id="FolderType" class="form-control">
        <option value="exercise">exercise</option>
        <option value="exercise_process">exercise_process</option>
    </select>

    <br>

    <input type="text"
           id="Namecategory"
           class="form-control"
           placeholder="Nhập tên thư mục">

    <br>

    <button type="button"
            class="btn btn-primary"
            id="Addcategory">
        Tạo thư mục
    </button>

    <div id="message" class="mt-2"></div>
</div>

<div id="addWebsiteForm"></div>

<script>
$(document).on('click', '#Addcategory', function(){
    var $btn = $(this);
    var FolderType   = $('#FolderType').val();
    var Namecategory = $('#Namecategory').val().trim();

    if (Namecategory === '') {
        $('#message').css('color', 'red').html('Chưa nhập tên thư mục');
        return;
    }

    var validName = /^[a-zA-Z0-9_\-]+$/;
    if (!validName.test(Namecategory)) {
        $('#message').css('color', 'red')
            .html('Tên thư mục chỉ được chứa chữ, số, gạch dưới (_), gạch ngang (-)');
        return;
    }

    $btn.prop('disabled', true).text('Đang tạo...');

    $.ajax({
        type: 'POST',
        url: 'Add_folder.php',
        data: { FolderType: FolderType, Namecategory: Namecategory },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                $('#message').css('color', 'green').html(response.message);
                $('#Namecategory').val('');
            } else {
                $('#message').css('color', 'red').html(response.message);
            }
        },
        error: function(xhr) {
            $('#message').css('color', 'red')
                .html('Lỗi server: ' + xhr.status + ' - ' + xhr.responseText);
        },
        complete: function() {
            $btn.prop('disabled', false).text('Tạo thư mục');
        }
    });
});
</script>