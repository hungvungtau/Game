<?php
include('class/User.php'); // Đảm bảo đường dẫn đúng

$user = new User();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $tableName = 'linkwebsite'; // Tên bảng bạn muốn cập nhật

    // Gọi hàm updateView
    $isUpdated = $user->updateView($id, $tableName);

    // Phản hồi kết quả
    /*if ($isUpdated) {
        echo "Cập nhật lượt view thành công!";
    } else {
        echo "Cập nhật lượt view thất bại.";
    }*/
}
?>