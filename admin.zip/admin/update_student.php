<?php
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// update_student.php - Cập nhật thông tin học sinh
// session_start();
include('class/UserLink.php');

// Kiểm tra đăng nhập
if (!isset($_SESSION['userid'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

// Kiểm tra dữ liệu bắt buộc
if (
    !isset($_POST['Id_hocsinh']) || empty($_POST['Id_hocsinh']) ||
    !isset($_POST['Id_khoi']) ||
    !isset($_POST['Hovaten']) ||
    !isset($_POST['Lop']) ||
    !isset($_POST['Ngaysinh']) ||
    !isset($_POST['Diachi']) ||
    !isset($_POST['Dienthoai']) ||
    !isset($_POST['Hotencha']) ||
    !isset($_POST['Dienthoai1']) ||
    !isset($_POST['Hotenme'])
) {
    echo json_encode(['success' => false, 'message' => 'Thiếu dữ liệu bắt buộc']);
    exit;
}

// Lấy dữ liệu từ form và làm sạch
$Id_hocsinh  = intval($_POST['Id_hocsinh']);
$Id_khoi     = intval($_POST['Id_khoi']);
$Hovaten     = trim($_POST['Hovaten']);
$Lop         = trim($_POST['Lop']);
$Ngaysinh    = trim($_POST['Ngaysinh']);
$Diachi      = trim($_POST['Diachi']);
$Dienthoai   = trim($_POST['Dienthoai']);
$Hotencha    = trim($_POST['Hotencha']);
$Dienthoai1  = trim($_POST['Dienthoai1']);
$Hotenme     = trim($_POST['Hotenme']);

$user = new User1();

// Gọi hàm cập nhật học sinh
try {
    $result = $user->updateStudent(
        $Id_hocsinh,
        $Id_khoi,
        $Hovaten,
        $Lop,
        $Ngaysinh,
        $Diachi,
        $Dienthoai,
        $Hotencha,
        $Dienthoai1,
        $Hotenme
    );

    if ($result['success']) {
        echo json_encode(['success' => true, 'message' => 'Cập nhật học sinh thành công']);
    } else {
        echo json_encode(['success' => false, 'message' => $result['message']]);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Lỗi cập nhật học sinh: ' . $e->getMessage()]);
}
?>
