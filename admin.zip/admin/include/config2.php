<?php
class dbConfig {
    protected $serverName;
    protected $userName;
    protected $password;
    protected $dbName;
	protected $Site_url;
	protected $Cookie;
    public function __construct(){
        $this -> serverName = 'localhost';
        $this -> userName = 'marketingfab79';
        $this -> password = 'ff109edb7e2f2a89';
        $this -> dbName = 'marketingfu_ab79';
		$this -> Site_url = 'http://marketingfunnel.top/';
    }
	    
}
?>