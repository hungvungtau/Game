<?php
class dbConfig {
    protected $serverName;
    protected $userName;
    protected $password;
    protected $dbName;
	protected $Site_url;
    public function __construct(){
        $this -> serverName = 'localhost';
        $this -> userName = 'root';//24e8b633ed7d622b
        $this -> password = '';
        //$this -> dbName = 'quanliuser';//tailieu_tin_ea6f
		$this -> dbName = 'hoctoan7';
		$this -> Site_url = 'http://localhost:8012/quanli/';
    }
	    
}
?>
