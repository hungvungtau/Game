<?php
class dbConfig {
    protected $serverName;
    protected $userName;
    protected $password;
    protected $dbName;
	protected $Site_url;
	protected $Cookie;
    public function __construct(){
        $this -> serverName = 'localhost';
        $this -> userName = 'tailieubiz771a';
        $this -> password = '24e8b633ed7d622b';
        $this -> dbName = 'tailieu_biz_771a';
		$this -> Site_url = 'http://tailieu.bizcrmweb.com/';
    }
	    
}
?>