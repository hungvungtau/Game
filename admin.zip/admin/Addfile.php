<?php session_start(); ?>
<div class="container mt-5">
    <h2>Tạo file JS / PHP</h2>

    <div class="row">
        <div class="col-md-6">
            <label>Loại thư mục</label>
            <select id="FolderType" class="form-control">
                <option value="exercise">exercise</option>
                <option value="exercise_process">exercise_process</option>
            </select>
        </div>
        <div class="col-md-6">
            <label>Lớp</label>
            <select id="ClassName" class="form-control">
                <option value="">-- Chọn lớp --</option>
            </select>
        </div>
    </div>

    <br>

    <label>Tên file (vd: bai1.js, xuly.php)</label>
    <input type="text"
           id="FileName"
           class="form-control"
           placeholder="Nhập tên file kèm đuôi .js hoặc .php">

    <br>

    <label>Nội dung code</label>
    <textarea id="FileContent"
              class="form-control"
              rows="20"
              style="font-family: Consolas, monospace; font-size: 14px;"
              placeholder="Dán code vào đây..."></textarea>

    <br>

    <button type="button" class="btn btn-primary" id="CreateFile">
        Tạo file
    </button>

    <div id="message" class="mt-2"></div>
</div>

<script>
// load danh sách lớp khi đổi FolderType
function loadClasses() {
    var FolderType = $('#FolderType').val();
    $.ajax({
        type: 'GET',
        url: 'get_classes.php',
        data: { FolderType: FolderType },
        dataType: 'json',
        success: function(res) {
            var $select = $('#ClassName');
            $select.html('<option value="">-- Chọn lớp --</option>');
            if (res.success && res.classes.length > 0) {
                $.each(res.classes, function(i, cls) {
                    $select.append('<option value="' + cls + '">' + cls + '</option>');
                });
            }
        },
        error: function() {
            $('#message').css('color', 'red').html('Không tải được danh sách lớp');
        }
    });
}

$(document).ready(function() {
    loadClasses();
});

$(document).on('change', '#FolderType', function() {
    loadClasses();
});

$(document).on('click', '#CreateFile', function() {
    var $btn = $(this);
    var FolderType   = $('#FolderType').val();
    var ClassName    = $('#ClassName').val();
    var FileName     = $('#FileName').val().trim();
    var FileContent  = $('#FileContent').val();

    if (ClassName === '') {
        $('#message').css('color', 'red').html('Chưa chọn lớp');
        return;
    }
    if (FileName === '') {
        $('#message').css('color', 'red').html('Chưa nhập tên file');
        return;
    }
    if (!/^[a-zA-Z0-9_\-]+\.(js|php)$/.test(FileName)) {
        $('#message').css('color', 'red')
            .html('Tên file không hợp lệ. Chỉ chữ/số/_/- và đuôi .js hoặc .php');
        return;
    }

    $btn.prop('disabled', true).text('Đang tạo...');

    $.ajax({
        type: 'POST',
        url: 'Add_file.php',
        data: {
            FolderType: FolderType,
            ClassName: ClassName,
            FileName: FileName,
            FileContent: FileContent
        },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                $('#message').css('color', 'green').html(response.message);
            } else {
                $('#message').css('color', 'red').html(response.message);
            }
        },
        error: function(xhr) {
            $('#message').css('color', 'red')
                .html('Lỗi server: ' + xhr.status + ' - ' + xhr.responseText);
        },
        complete: function() {
            $btn.prop('disabled', false).text('Tạo file');
        }
    });
});
</script>