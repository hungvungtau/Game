<?php
include('class/UserLink.php');
$user = new User1();

// Lấy dữ liệu học sinh
$students = $user->getdata1('hocsinh', true);
?>

<div class="container mt-4">
    <h2>Danh sách học sinh</h2>

    <div id="message" class="alert" style="display: none;"></div>

    <div class="mb-3">
        <button id="selectAll" class="btn btn-sm btn-outline-secondary">Select All</button>
        <button id="unselectAll" class="btn btn-sm btn-outline-secondary">Unselect All</button>
        <button id="deleteSelected" class="btn btn-sm btn-danger">Delete Selected</button>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-hover" id="studentsTable">
            <thead class="thead-dark">
                <tr>
                    <th width="40px"><input type="checkbox" id="checkAll"></th>
                    <th width="100px">Actions</th>
                    <th>ID Học sinh</th>
                    <th>ID Khối</th>
                    <th>Họ và tên</th>
                    <th>Lớp</th>
                    <th>Ngày sinh</th>
                    <th>Địa chỉ</th>
                    <th>Điện thoại</th>
                    <th>Họ tên cha</th>
                    <th>Điện thoại cha</th>
                    <th>Họ tên mẹ</th>
                </tr>
            </thead>
            <tbody>
                <?php if(empty($students)): ?>
                    <tr><td colspan="12" class="text-center">Chưa có học sinh</td></tr>
                <?php else: ?>
                    <?php foreach($students as $st): ?>
                        <tr data-id="<?php echo $st['Id_hocsinh']; ?>">
                            <td><input type="checkbox" class="student-checkbox" value="<?php echo $st['Id_hocsinh']; ?>"></td>
                            <td>
                                <div class="normal-buttons">
                                    <button class="btn btn-sm btn-info edit-btn"><i class="fas fa-edit"></i></button>
                                    <button class="btn btn-sm btn-danger delete-btn"><i class="fas fa-trash"></i></button>
                                </div>
                                <div class="edit-buttons" style="display:none;">
                                    <button class="btn btn-sm btn-success save-inline-btn"><i class="fas fa-save"></i></button>
                                    <button class="btn btn-sm btn-secondary cancel-inline-btn"><i class="fas fa-times"></i></button>
                                </div>
                            </td>

                            <td><?php echo $st['Id_hocsinh']; ?></td>
                            <td class="editable" data-field="Id_khoi"><?php echo htmlspecialchars($st['Id_khoi']); ?></td>
                            <td class="editable" data-field="Hovaten"><?php echo htmlspecialchars($st['Hovaten']); ?></td>
                            <td class="editable" data-field="Lop"><?php echo htmlspecialchars($st['Lop']); ?></td>
                            <td class="editable" data-field="Ngaysinh"><?php echo htmlspecialchars($st['Ngaysinh']); ?></td>
                            <td class="editable" data-field="Diachi"><?php echo htmlspecialchars($st['Diachi']); ?></td>
                            <td class="editable" data-field="Dienthoai"><?php echo htmlspecialchars($st['Dienthoai']); ?></td>
                            <td class="editable" data-field="Hotencha"><?php echo htmlspecialchars($st['Hotencha']); ?></td>
                            <td class="editable" data-field="Dienthoai1"><?php echo htmlspecialchars($st['Dienthoai1']); ?></td>
                            <td class="editable" data-field="Hotenme"><?php echo htmlspecialchars($st['Hotenme']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
$(document).ready(function() {
    // Chọn/Bỏ chọn tất cả
    $('#checkAll').click(function() {
        $('.student-checkbox').prop('checked', this.checked);
    });
    $('#selectAll').click(function() {
        $('.student-checkbox').prop('checked', true);
    });
    $('#unselectAll').click(function() {
        $('.student-checkbox').prop('checked', false);
    });

    // Bật chế độ sửa
    $(document).on('click', '.edit-btn', function() {
        const row = $(this).closest('tr');
        row.find('.editable').each(function() {
            const val = $(this).text().trim();
            $(this).data('old', val);
            $(this).html(`<input type="text" class="form-control form-control-sm" value="${val}">`);
        });
        row.find('.normal-buttons').hide();
        row.find('.edit-buttons').show();
    });

    // Hủy sửa
    $(document).on('click', '.cancel-inline-btn', function() {
        const row = $(this).closest('tr');
        row.find('.editable').each(function() {
            $(this).text($(this).data('old'));
        });
        row.find('.edit-buttons').hide();
        row.find('.normal-buttons').show();
    });

    // Lưu chỉnh sửa
    $(document).on('click', '.save-inline-btn', function() {
        const row = $(this).closest('tr');
        const id = row.data('id');
        let data = { Id_hocsinh: id };

        row.find('.editable').each(function() {
            const field = $(this).data('field');
            const value = $(this).find('input').val();
            data[field] = value;
        });

        $('#message').removeClass().addClass('alert alert-info').text('Đang lưu...').show();

        $.ajax({
            url: 'update_student.php',
            type: 'POST',
            data: data,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    row.find('.editable').each(function() {
                        const field = $(this).data('field');
                        $(this).text(data[field]);
                    });
                    row.find('.edit-buttons').hide();
                    row.find('.normal-buttons').show();
                    $('#message').removeClass().addClass('alert alert-success').text('Cập nhật thành công!').show().delay(2000).fadeOut();
                } else {
                    $('#message').removeClass().addClass('alert alert-danger').text('Lỗi: ' + response.message).show();
                }
            },
            error: function() {
                $('#message').removeClass().addClass('alert alert-danger').text('Không thể cập nhật dữ liệu.').show();
            }
        });
    });
});
</script>