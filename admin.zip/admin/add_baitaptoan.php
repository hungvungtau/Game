<?php
header('Content-Type: application/json');
//session_start();
include('class/UserLink.php');

$user = new User1(); // SỬA: đã include UserLink.php thì class phải là UserLink
$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    /* ===== KIỂM TRA CAPTCHA ===== */
    if (!isset($_POST['txtCaptcha']) || $_POST['txtCaptcha'] == '') {
        $response['message'] = "Vui lòng nhập mã xác nhận.";
        echo json_encode($response);
        exit;
    }

    if (!isset($_SESSION['security_code']) || $_POST['txtCaptcha'] != $_SESSION['security_code']) {
        $response['message'] = "Sai mã xác nhận.";
        echo json_encode($response);
        exit;
    }

    /* ===== LẤY DỮ LIỆU FORM ===== */
    $id_user   = isset($_SESSION['userid']) ? $_SESSION['userid'] : 0;
    $id_khoi   = isset($_POST['id_khoi']) ? $_POST['id_khoi'] : 1;
    $id_hocky  = isset($_POST['id_hocky']) ? $_POST['id_hocky'] : 1;
    $id_chuong = isset($_POST['id_chuong']) ? $_POST['id_chuong'] : 1;
    $tenbaitap = isset($_POST['keyword']) ? trim($_POST['keyword']) : '';
    $ngaygiao  = isset($_POST['Date_begin']) ? $_POST['Date_begin'] : null;
    $ngaynop   = isset($_POST['Date_end']) ? $_POST['Date_end'] : null;

    if ($tenbaitap == '') {
        $response['message'] = "Vui lòng nhập tên bài tập.";
        echo json_encode($response);
        exit;
    }

    /* ===== UPLOAD HÌNH ===== */
    $hinh = '';

    if (isset($_FILES['Image']) && $_FILES['Image']['error'] == UPLOAD_ERR_OK) {

        $uploadDir = 'images/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // Đổi tên file an toàn
        $safeName = preg_replace('/[^a-zA-Z0-9._-]/', '_', $_FILES['Image']['name']);
        $fileName = date('Ymd_His') . '_' . $safeName;

        $uploadFile = $uploadDir . $fileName;

        if (move_uploaded_file($_FILES['Image']['tmp_name'], $uploadFile)) {
            $hinh = $uploadFile;
        } else {
            $response['message'] = "Không thể tải hình lên máy chủ.";
            echo json_encode($response);
            exit;
        }
    }

    /* ===== GỌI CLASS ===== */
    try {

        $result = $user->AddExcise(
            null,       // id_bttoan
            $id_user,
            $id_khoi,
            $id_hocky,
            $id_chuong,
            $tenbaitap,
            $hinh,
            $ngaygiao,
            $ngaynop
        );

        if (isset($result['rowCount']) && $result['rowCount'] > 0) {

            $response = array(
                'success' => true,
                'message' => "Thêm bài tập thành công!",
                'data' => $result
            );

        } else {

            $response = array(
                'success' => false,
                'message' => isset($result['message']) ? $result['message'] : "Không thể thêm bài tập."
            );
        }

    } catch (Exception $e) {

        $response = array(
            'success' => false,
            'message' => "Lỗi hệ thống: " . $e->getMessage()
        );
    }

    echo json_encode($response);
    exit;
}
?>
