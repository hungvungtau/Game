<?php
// Đặt cookie có tên 'global_cookie' với giá trị 'your_value'
// Cookie sẽ có thời gian sống là 30 ngày và có thể truy cập từ mọi thư mục
setcookie("global_cookie", "your_value", time() + (86400 * 30), "/"); // "/" để cookie có thể được sử dụng toàn cục

// Thông báo cho người dùng
echo "Cookie đã được tạo!";
?>