<?php
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
session_start();
include('class/UserLink.php');

// Kiểm tra đăng nhập
if (!isset($_SESSION['userid'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

// Kiểm tra dữ liệu bắt buộc
if (
    !isset($_POST['Id_noidung']) || empty($_POST['Id_noidung']) ||
    !isset($_POST['Id_chuong']) ||
    !isset($_POST['Tennoidung']) ||
    !isset($_POST['Linkvideo']) ||
    !isset($_POST['Namefunction'])
) {
    echo json_encode(['success' => false, 'message' => 'Thiếu dữ liệu bắt buộc']);
    exit;
}

// Lấy dữ liệu từ form
$Id_noidung   = intval($_POST['Id_noidung']);
$Id_chuong    = intval($_POST['Id_chuong']);
$Tennoidung   = trim($_POST['Tennoidung']);
$Linkvideo    = trim($_POST['Linkvideo']);
$Namefunction = trim($_POST['Namefunction']);

$user = new User1();

// Gọi hàm cập nhật nội dung khóa học
try {
    $result = $user->Updatecourse(
        $Id_noidung,
        $Id_chuong,
        $Tennoidung,
        $Linkvideo,
        $Namefunction
    );

    if ($result['success']) {
        echo json_encode(['success' => true, 'message' => 'Cập nhật nội dung khóa học thành công']);
    } else {
        echo json_encode(['success' => false, 'message' => $result['message']]);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Lỗi cập nhật khóa học: ' . $e->getMessage()]);
}
?>
