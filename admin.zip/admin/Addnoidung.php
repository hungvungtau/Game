<?php
session_start();
?>
<div class="container mt-5">
    <h2>Thêm Nội Dung</h2>

   <form id="addNoidungForm">
        <div class="form-group">
            <label for="id_chuong">ID Chương:</label>
            <input type="number" class="form-control" id="id_chuong" required>
        </div>

        <div class="form-group">
            <label for="ten_noidung">Tên Nội Dung:</label>
            <input type="text" class="form-control" id="ten_noidung" required>
        </div>

        <div class="form-group">
            <label for="type">Type:</label>
            <input type="text" class="form-control" id="type" placeholder="vd: text, video, pdf...">
        </div>

        <div class="form-group">
            <label for="placeholder">Placeholder:</label>
            <input type="text" class="form-control" id="placeholder">
        </div>

        <div class="form-group">
            <label for="Namefunction">Name Function:</label>
            <input type="text" class="form-control" id="Namefunction">
        </div>

        <div class="form-group">
            <label for="Folder">Folder:</label>
            <input type="text" class="form-control" id="Folder" placeholder="vd: exercise/class8">
        </div>
        <div class="form-group">
			<label>Hình ảnh</label>
			<input type="file" class="form-control" id="image" accept="image/*">
	</div>
        <div class="form-group">
            <label for="Linkvideo">Link Video:</label>
            <input type="text" class="form-control" id="Linkvideo" placeholder="vd: https://youtube.com/...">
        </div>

        <div class="form-group">
            <label for="active">Hoạt động:</label>
            <select class="form-control" id="active">
                <option value="1">Mở</option>
                <option value="0">Khóa</option>
            </select>
        </div>

        <div class="form-group row">
            <label for="txtCaptcha" class="col-md-3 control-label">Captcha*</label>
            <div class="col-md-9">
                <input type="text" name="txtCaptcha" class="form-control" id="txtCaptcha"
                       placeholder="Nhập mã captcha" required maxlength="10" size="32" />
            </div>
        </div>

        <div class="form-group row">
            <div class="col-md-9">
                <img src="random_image.php" id="captchaImg" style="cursor:pointer;" title="Bấm để đổi mã khác" />
            </div>
        </div>

        <button type="submit" class="btn btn-primary" id="AddNoiDung">Thêm Nội Dung</button>
    </form>
</div>

<div id="message" class="mt-3"></div>

<script>
$(document).ready(function() {

    $('#addWebsiteForm').on('submit', function(e) {

        e.preventDefault();

        var formData = new FormData();

        formData.append('id_chuong', $('#id_chuong').val());
        formData.append('ten_noidung', $('#ten_noidung').val());
        formData.append('type', $('#type').val());
        formData.append('placeholder', $('#placeholder').val());
        formData.append('Namefunction', $('#Namefunction').val());
        formData.append('Folder', $('#Folder').val());
        formData.append('Linkvideo', $('#Linkvideo').val());
        formData.append('active', $('#active').val());
        formData.append('txtCaptcha', $('#txtCaptcha').val());

        var imageFile = $('#image')[0].files[0];

        if(imageFile)
        {
            formData.append('image', imageFile);
        }

        $.ajax({

            type: 'POST',

            url: 'Add_noidung.php',

            data: formData,

            processData: false,

            contentType: false,

            dataType: 'json',

            success: function(response) {

                if(response.message)
                {
                    $('#message').html(response.message);
                }
                else
                {
                    $('#message').html("Không có dữ liệu trả về.");
                }

            },

            error: function(xhr, status, error) {

                $('#message').html(
                    "Đã xảy ra lỗi: " + xhr.responseText
                );

            }

        });

    });

});
</script>