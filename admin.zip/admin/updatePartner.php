<?php 
include('class/User.php');
$user = new User();
//$message =  $user->register1();
include('include/header.php');
?>
<title> Unlock Free Strategies to Boost Your Website Traffic with SSC!</title>
<?php include('include/container.php');?>
<div class="container contact">	
	<h2> Unlock Free Strategies to Boost Your Website Traffic Your Online Success with SSC!</h2>
	<div id="signupbox" class="col-md-7">
		<div class="panel panel-info">
			<div class="panel-heading">
				<div class="panel-title">Sign Up</div>				
			</div>  
			<div class="panel-body" >
				<form id="signupform" class="form-horizontal" role="form" method="POST" action="">				
					<?php //if ($message != '') { ?>
						<div id="login-alert" class="alert alert-danger col-sm-12"><?php //echo $message; ?></div>                            
					<?php //} ?>
                    <div class="form-group">
						<label for="password" class="col-md-3 control-label">Captcha*</label>
						<div class="col-md-9">
							 <input type="text" name="txtCaptcha" class="form-control" id="txtCaptcha" placeholder="txtCaptcha" required maxlength="10" size="32" />
						</div>
						<div class="col-md-9">
							<img src="random_image.php" />
						</div>	
					</div>						
					<div class="form-group">						                                  
						<div class="col-md-offset-3 col-md-9">
							<button id="btn-signup" type="button" name="register" value="register" class="btn btn-info"><i class="icon-hand-right"></i> &nbsp Register Partner</button>			
						</div>
					</div>					
					<div class="form-group">
						<div class="col-md-12 control">
							<div style="border-top: 1px solid#888; padding-top:15px; font-size:85%" >
								If You've already an account! 
							<a href="login.php">
								Log In 
							</a>Here
							</div>
						</div>
					</div>  				
				</form>
			 </div>
		</div>
	</div>	
</div>
<div id="message"></div>
<script>
$(document).ready(function() {
    $('#btn-signup').on('click', function(e) {
        e.preventDefault(); // Ngăn chặn hành vi mặc định của nút

		var txtCaptcha = $('#txtCaptcha').val();

        // Gửi dữ liệu qua AJAX
        $.ajax({
            type: 'POST',
            url: 'update_Partner.php', // Đường dẫn đến file PHP xử lý
            data: {
				txtCaptcha:txtCaptcha
            },
            dataType: 'json', // Đặt kiểu dữ liệu mong muốn là JSON
            success: function(response) {
                if (response.message) {
                    $('#message').html(response.success+response.message+response.data);
                } else {
                    $('#message').html("Không có câu lệnh SQL nào để hiển thị.");
                }
            },
            error: function(xhr, status, error) {
                $('#message').html(xhr.responseText); // Hiển thị chi tiết lỗi
            }
        });
    });
});
</script>
<?php include('include/footer.php');?>