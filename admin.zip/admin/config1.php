 <?php
$databaseHost = 'localhost';
$databaseName = 'tailieu_biz_771a';
$databaseUsername = 'tailieubiz771a'; // Thay 'your_username' bằng tên người dùng của bạn
$databasePassword = '24e8b633ed7d622b'; // Thay 'your_password' bằng mật khẩu của bạn

// Tạo kết nối
$mysqli = new mysqli($databaseHost, $databaseUsername, $databasePassword, $databaseName);

// Kiểm tra kết nối
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Thiết lập charset cho kết nối
$mysqli->set_charset("utf8");

// Bạn có thể thực hiện các truy vấn ở đây

// Đóng kết nối khi không còn sử dụng
// $mysqli->close();
?>
