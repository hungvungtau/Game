<?php
session_start();
header('Content-Type: application/json');

// Kiểm tra xem cookie có tồn tại không
if (!isset($_COOKIE['ma'])) {
    echo json_encode(['success' => false, 'message' => 'Not yet Code.']);
    exit; 
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ma = $_COOKIE['ma'];
    $keyword = $_POST['keyword'];
    $link = "http://daykembatnha.top"; // Thay đổi link nếu cần

    // So sánh mã nhập vào với mã trong cookie
    if ($keyword === $ma) {
        echo json_encode(['success' => true, 'message' => "You entered successfully", 'link' => $link]);
    } else {
        echo json_encode(['success' => false, 'message' => 'You entered code not successful.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
}
?>