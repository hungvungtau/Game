<?php 
include('class/UserLink.php'); 
$user = new User1();  

// Lấy dữ liệu nội dung khóa học
$contents = $user->getdata1('noidungkhoahoc', true);
?>  

<div class="container mt-4">
    <h2>Danh sách nội dung khóa học</h2>

    <div id="message" class="alert" style="display: none;"></div>

    <div class="mb-3">
        <button id="selectAll" class="btn btn-sm btn-outline-secondary">Select All</button>
        <button id="unselectAll" class="btn btn-sm btn-outline-secondary">Unselect All</button>
        <button id="deleteSelected" class="btn btn-sm btn-danger">Delete Selected</button>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-hover" id="contentTable">
            <thead class="thead-dark">
                <tr>
                    <th width="40px"><input type="checkbox" id="checkAll"></th>
                    <th width="100px">Actions</th>
                    <th>ID Nội dung</th>
                    <th>ID Chương</th>
                    <th>Tên nội dung</th>
                    <th>Link video</th>
                    <th>Tên function</th>
                </tr>
            </thead>
            <tbody>
                <?php if(empty($contents)): ?>
                    <tr><td colspan="7" class="text-center">Chưa có nội dung khóa học</td></tr>
                <?php else: ?>
                    <?php foreach($contents as $ct): ?>
                        <tr data-id="<?php echo $ct['Id_noidung']; ?>">
                            <td><input type="checkbox" class="content-checkbox" value="<?php echo $ct['Id_noidung']; ?>"></td>
                            <td>
                                <div class="normal-buttons">
                                    <button class="btn btn-sm btn-info edit-btn"><i class="fas fa-edit"></i></button>
                                    <button class="btn btn-sm btn-danger delete-btn"><i class="fas fa-trash"></i></button>
                                </div>
                                <div class="edit-buttons" style="display:none;">
                                    <button class="btn btn-sm btn-success save-inline-btn"><i class="fas fa-save"></i></button>
                                    <button class="btn btn-sm btn-secondary cancel-inline-btn"><i class="fas fa-times"></i></button>
                                </div>
                            </td>

                            <td><?php echo $ct['Id_noidung']; ?></td>
                            <td class="editable" data-field="Id_chuong"><?php echo htmlspecialchars($ct['Id_chuong']); ?></td>
                            <td class="editable" data-field="Tennoidung"><?php echo htmlspecialchars($ct['Tennoidung']); ?></td>
                            <td class="editable" data-field="Linkvideo"><?php echo htmlspecialchars($ct['Linkvideo']); ?></td>
                            <td class="editable" data-field="Namefunction"><?php echo htmlspecialchars($ct['Namefunction']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
$(document).ready(function() {

    // Chọn/Bỏ chọn tất cả
    $('#checkAll').click(function() {
        $('.content-checkbox').prop('checked', this.checked);
    });
    $('#selectAll').click(function() {
        $('.content-checkbox').prop('checked', true);
    });
    $('#unselectAll').click(function() {
        $('.content-checkbox').prop('checked', false);
    });

    // Bật chế độ sửa
    $(document).on('click', '.edit-btn', function() {
        const row = $(this).closest('tr');
        row.find('.editable').each(function() {
            const val = $(this).text().trim();
            $(this).data('old', val);
            $(this).html(`<input type="text" class="form-control form-control-sm" value="${val}">`);
        });
        row.find('.normal-buttons').hide();
        row.find('.edit-buttons').show();
    });

    // Hủy sửa
    $(document).on('click', '.cancel-inline-btn', function() {
        const row = $(this).closest('tr');
        row.find('.editable').each(function() {
            $(this).text($(this).data('old'));
        });
        row.find('.edit-buttons').hide();
        row.find('.normal-buttons').show();
    });

    // Lưu chỉnh sửa
    $(document).on('click', '.save-inline-btn', function() {
        const row = $(this).closest('tr');
        const id = row.data('id');
        let data = { Id_noidung: id };

        row.find('.editable').each(function() {
            const field = $(this).data('field');
            const value = $(this).find('input').val();
            data[field] = value;
        });

        $('#message').removeClass().addClass('alert alert-info').text('Đang lưu...').show();

        $.ajax({
            url: 'update_course.php',
            type: 'POST',
            data: data,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    row.find('.editable').each(function() {
                        const field = $(this).data('field');
                        $(this).text(data[field]);
                    });
                    row.find('.edit-buttons').hide();
                    row.find('.normal-buttons').show();
                    $('#message').removeClass().addClass('alert alert-success').text('Cập nhật thành công!').show().delay(2000).fadeOut();
                } else {
                    $('#message').removeClass().addClass('alert alert-danger').text('Lỗi: ' + response.message).show();
                }
            },
            error: function() {
                $('#message').removeClass().addClass('alert alert-danger').text('Không thể cập nhật dữ liệu.').show();
            }
        });
    });
});
</script>
