<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Lấy Mã Code Ngẫu Nhiên</title>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="insertcode.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            text-align: center;
        }
        #result {
            margin-top: 20px;
            font-size: 24px;
            font-weight: bold;
        }
		 #nd {
            border: 1px solid #ccc;
            padding: 10px;
            margin-bottom: 10px;
            background-color: #f9f9f9;
            white-space: pre-wrap; /* Để giữ định dạng mã */
        }
        button {
            padding: 10px 15px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
    
</head>
<body>
    <h1>Lấy Mã Code Ngẫu Nhiên</h1>
    <input type="hidden" id="ma" value="NTc5MDc5"/>
	 <input type="hidden" id="id" value="1" />
    <button id="getRandomCode">Lấy Mã Code</button>
    <div id="result"></div>
	 <div id="result1"></div>
      <div id="nd"></div>
	<button id="copyButton" onclick="Copy()">Copy Code</button>  
     <script language="javascript">
       $(document).ready(function() {
    $('#getRandomCode').click(function() {
        // Lấy giá trị từ textbox ẩn
        var ma = $('#ma').val();//
		var id = $('#id').val();
		//alert(id);
        //alert(ma);
        $.ajax({
            url: 'http://localhost:8012/layma1/update_layma.php', 
            //url: 'marketingfunnel.top/update_layma.php',
            method: 'post',
            data: {'ma' : ma,'id' : id},
            success: function(data) {
                // Giả sử dữ liệu trả về là một đối tượng JSON
                //$('#result').text('Mã Code: ' + data.ma + ', success: ' + data.success);
				  //this.disabled = true; // Vô hiệu hóa nút
				  
			//document.getElementById('getRandomCode').addEventListener('click', function() {
				//this.innerHTML = "Bạn Chờ Một Xíu Để Nhận Mã Giải Nén";
				//startCountdown(40,data.ma);// Bắt đầu đếm ngược từ 40 giây
				//this.disabled = true; // Vô hiệu hóa nút
				//document.getElementById('getRandomCode').disabled =true;
       // });
				
                //wpb_ma(data.ma);
            },
            error: function() {
                $('#result').text('Có lỗi xảy ra khi lấy mã code.');
            }
        });
		//
		 $.ajax({
           url: 'http://localhost:8012/layma1/layma1.php', 
            //url: 'http://tailieu.bizcrmweb.com/layma1.php',
            method: 'post',
            data: {'ma' : ma,'id' : id},
            success: function(data) {
                // Giả sử dữ liệu trả về là một đối tượng JSON
                //$('#result').text('Mã Code: ' + data.ma + ', success: ' + data.success);
				  //this.disabled = true; // Vô hiệu hóa nútcookie_name
				  $('#result').text('Cookie' + data.cookie_name);
			//document.getElementById('getRandomCode').addEventListener('click', function() {
				this.innerHTML = "Bạn Chờ Một Xíu Để Nhận Mã Giải Nén";
				startCountdown(40,data.ma);// Bắt đầu đếm ngược từ 40 giây
				//this.disabled = true; // Vô hiệu hóa nút
				document.getElementById('getRandomCode').disabled =true;
       // });
				
                //wpb_ma(data.ma);
            },
            error: function() {
                $('#result').text('Có lỗi xảy ra khi lấy mã code.');
            }
        });
		
		
		
    });
});	
function Copy()
{
document.getElementById('copyButton').addEventListener('click', function() {
        const codeElement = document.getElementById('nd');
        const codeText = codeElement.innerText;

        navigator.clipboard.writeText(codeText).then(function() {
            alert('You Copied Code!');
        }, function(err) {
            alert('Lỗi khi sao chép mã: ', err);
        });
    });	
}
function startCountdown(seconds,ma) {
            let countdownTime = seconds;
            const display = document.getElementById("nd");
			var Rs = document.getElementById("result1");

            const interval = setInterval(() => {
                if (countdownTime >= 0) {
                    display.innerText = "Bạn còn " + countdownTime + " giây nữa";
                    countdownTime--;
                } else {
                    clearInterval(interval); // Dừng bộ đếm Mã của bạn là: 
					Rs.innerText="Your Code is";
                    display.innerText = ma; // Hiển thị mã
					
                }
            }, 1000);
        }
/*function wpb_ma(s) {
   
    const form = '<style>#nd { color: blue; font-size: 16pt; }</style><form name="form1"><button type="button" name="button" id="button" onclick="Ketqua();">Bạn Click Vào Đây Để Nhận Mã</button></form><div id="nd"></div>';
    document.body.innerHTML += form; 
    let Hienthi;
    let h = 0; 
    let m = 0; 
    let sCountdown = 38; 
    let timeout = null; 

    
    Hienthi = setTimeout(function() {
        document.getElementById("nd").innerHTML = s;
    }, 40000);

    
    window.Ketqua = function() {
        document.getElementById("button").innerHTML = "Bạn Chờ Một Xíu Để Nhận Mã Giải Nén";
        start();
        Hienthi(); 
        document.getElementById("button").disabled = true;
    };

  
    function start() {
        if (sCountdown === -1) {
            m -= 1;
            sCountdown = 60;
        }

        if (m === -1) {
            h -= 1;
            m = 59;
        }

        if (h == -1) {
            clearTimeout(timeout);
            return false;
        }

        document.getElementById("nd").innerText = "Bạn còn " + sCountdown.toString() + " giây nữa";

        timeout = setTimeout(function() {
            sCountdown--;
            start();
        }, 1000);
    }
}*/	
    </script>
</body>
</html>