<?php header('Content-Type: application/json');
$Id='ma_'.$_POST['Id'];
include_once("config.php");
$id=$_POST['id'];
//fetching data in descending order (lastest entry first)
//$result = mysql_query("SELECT * FROM users ORDER BY id DESC"); // mysql_query is deprecated
$sql="SELECT * FROM link where idlink='".$id."'";
$result = mysqli_query($mysqli,$sql); // using mysqli_query instead
$result1 = mysqli_query($mysqli, "SELECT * FROM danhmucweb"); // using mysqli_query instead
	<?php 
	//while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array 
	while($res = mysqli_fetch_array($result)) 
	{
	    $row=$res['url'];	
		$Tenfile=$res['tenfile'];
	}
	while($res1 = mysqli_fetch_array($result1)) { 		
	   $row1[]=$res1;	
	}
	$num1 = array_rand($row1);
//$item = $row1[$num1];
//$linkweb="http://".$item['linkweb']."/downloads/";

// Kiểm tra xem cookie có tồn tại không
if (!isset($_COOKIE[$Id])) {
    echo json_encode(['success' => false, 'message' => 'Not yet Code.']);
    exit; 
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ma = $_COOKIE[$Id];
    $keyword = $_POST['keyword'];
    $link = $row; // Thay đổi link nếu cần

    // So sánh mã nhập vào với mã trong cookie
    if ($keyword === $ma) {
        echo json_encode(['success' => true, 'message' => "You entered successfully", 'link' => $link]);
    } else {
        echo json_encode(['success' => false, 'message' => 'You entered code not successful.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
}
?>