<?php
session_start();
?>    

<div class="container mt-5">
    <h2>Thêm Bài Tập Toán</h2>
    <form id="addExciseForm" enctype="multipart/form-data">
        <div class="form-group">
            <label for="tenbaitap">Tên bài tập</label>
            <input type="text" class="form-control" id="tenbaitap" required>
        </div>
        <div class="form-group">
            <label for="Image">Hình ảnh (nếu có):</label>
            <input type="file" class="form-control" id="Image" name="Image">
        </div>
        <div class="form-group">
            <label for="Date_begin">Ngày giao:</label>
            <input type="date" class="form-control" id="Date_begin" required>
        </div>
        <div class="form-group">
            <label for="Date_end">Ngày nộp:</label>
            <input type="date" class="form-control" id="Date_end" required>
        </div>
        <div class="form-group">
            <label for="txtCaptcha">Captcha*</label>
            <input type="text" class="form-control" id="txtCaptcha" placeholder="Nhập mã captcha" required>
            <img src="random_image.php" alt="Captcha" style="margin-top:10px;">
        </div>
        <button type="submit" class="btn btn-primary">Thêm Bài Tập</button>
    </form>
</div>

<div id="message"></div>

<script>
$(document).ready(function() {
    $('#addExciseForm').on('submit', function(e) {
        e.preventDefault();

        var formData = new FormData(this);
        var tenbaitap = $('#tenbaitap').val();
        var ngaygiao = $('#Date_begin').val();
        var ngaynop = $('#Date_end').val();
        var txtCaptcha = $('#txtCaptcha').val();
        var id_user = <?php echo json_encode($_SESSION['userid']); ?>;

        formData.append('Tenbaitap', tenbaitap);
        formData.append('Ngaygiao', ngaygiao);
        formData.append('Ngaynop', ngaynop);
        formData.append('id_user', id_user);
        formData.append('txtCaptcha', txtCaptcha);

        $.ajax({
            type: 'POST',
            url: 'add_baitaptoan.php',
            data: formData,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function(response) {
                $('#message').html(response.message);
            },
            error: function(xhr) {
                $('#message').html("Lỗi: " + xhr.responseText);
            }
        });
    });
});
</script>