<?php
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
// delete_question.php - Deletes a question record
//session_start();
include('class/UserLink.php');

// Check if user is logged in
if (!isset($_SESSION['userid'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

// Check if ID is provided
if (!isset($_POST['Id']) || empty($_POST['Id'])) {
    echo json_encode(['success' => false, 'message' => 'Question ID is required']);
    exit;
}

$questionId = intval($_POST['Id']);
$user = new User1();

// Delete question data
try {
    $result = $user->deleteQuestion($questionId);
    
    if ($result['success']) {
        echo json_encode(['success' => true, 'message' => 'Question deleted successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => $result['message']]);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error deleting question: ' . $e->getMessage()]);
}
?>