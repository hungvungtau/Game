<?php
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

session_start();

include('class/UserLink.php');


/*
kiểm tra login
*/
if(
    !isset($_SESSION['userid'])
){
    echo json_encode(
        array(
            'success'=>false,
            'message'=>'User not logged in'
        )
    );
    exit();
}


/*
kiểm tra dữ liệu
*/
if(

    !isset($_POST['Id_qs'])

    ||

    !isset($_POST['Id_cs'])

    ||

    !isset($_POST['Quenstion'])

    ||

    !isset($_POST['Image'])

){
    echo json_encode(
        array(
            'success'=>false,
            'message'=>'Thiếu dữ liệu'
        )
    );
    exit();
}


/*
lấy dữ liệu
*/
$Id_qs = intval(
    $_POST['Id_qs']
);

$Id_cs = intval(
    $_POST['Id_cs']
);

$Quenstion = trim(
    $_POST['Quenstion']
);

$Image = trim(
    $_POST['Image']
);


$user = new User();


/*
update
*/
try{

    $result = $user->Editquestion(

        $Id_qs,

        $Id_cs,

        $Quenstion,

        $Image

    );


    if(
        $result['success']
    ){

        echo json_encode(
            array(
                'success'=>true,
                'message'=>'Cập nhật câu hỏi thành công'
            )
        );

    }else{

        echo json_encode(
            array(
                'success'=>false,
                'message'=>$result['message']
            )
        );

    }

}catch(Exception $e){

    echo json_encode(
        array(
            'success'=>false,
            'message'=>$e->getMessage()
        )
    );

}

?>