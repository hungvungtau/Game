<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

function msg($success, $status, $message, $extra = []) {
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ], $extra);
}

function getPostObject() {
    $str = file_get_contents('php://input');
    $std = json_decode($str);
    if ($std === null) {
        $std = new stdClass();
        $array = explode('&', $str);
        foreach ($array as $parm) {
            $parts = explode('=', $parm);
            if (sizeof($parts) != 2) {
                continue;
            }
            $key = urldecode($parts[0]);
            $value = urldecode($parts[1]);
            $std->$key = $value === '' ? null : $value;
        }
    }
    return $std;
}

$data = getPostObject();
$returnData = [];
include('class/User.php');
$user = new User();

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0, 404, 'Page Not Found!');
} elseif (!isset($data->ma) || !isset($data->id)) {
    $fields = ['fields' => ['ma', 'id']];
    $returnData = msg(0, 422, 'Please Fill in all Required Fields!', $fields);
} else {
    $id = trim($data->id);
    $ma = mt_rand(100000, 999999); // Hoặc sử dụng $data->ma nếu cần
    
    // Gọi hàm insertCode
    $insertResult = $user->insertCode($id, $ma);
    
    if (isset($insertResult['rowCount']) && $insertResult['rowCount'] > 0) {
        $success = true;
        $message = $insertResult['message'];
        
        // Thiết lập cookie nếu cần
       /* $cookie_name = "ma_" . $id; // Định nghĩa cookie_name
        $cookie_value = $ma; // Giá trị cookie
        $cookie_expire = time() + (86400 * 30); // Thời gian sống của cookie (30 ngày)
        setcookie($cookie_name, $cookie_value, $cookie_expire, "/");*/

    } else {
        $success = false;
        $message = isset($insertResult['error']) ? "Error: " . $insertResult['error'] : "Insert failed";
		 
    }

    if ($success) {
        $returnData = msg(1, 200, "Code succeeded", ['ma' => $ma, 'cookie_name' => $cookie_name]);
    } else {
        //$returnData = msg(0, 500, $message);
		$returnData = msg(1, 200, "Code succeeded", ['ma' => $ma]);
    }
}

echo json_encode($returnData);
?>