<?php
session_start();
?>    
<div class="container mt-5">
    <h2>Add Website</h2>
    <form id="addWebsiteForm">
        <div class="form-group">
            <label for="tenWebsite">Name Website:</label>
            <input type="text" class="form-control" id="tenWebsite" required>
        </div>
        <div class="form-group">
            <label for="linkWebsite">Link Website:</label>
            <input type="url" class="form-control" id="linkWebsite" required>
        </div>
		 <div class="form-group">
           <label for="password" class="col-md-3 control-label">Captcha*</label>
			<div class="col-md-9">
				<input type="text" name="txtCaptcha" class="form-control" id="txtCaptcha" placeholder="txtCaptcha" required maxlength="10" size="32" />
		</div>
		</div>	
		<div class="form-group">
						
						<div class="col-md-9">
							<img src="random_image.php" />
						</div>	
		</div>	
        <button type="submit" class="btn btn-primary" id="AddWebsite">Add Website</button>
    </form>
</div>
<div id="message"></div>
<div id="addWebsiteForm"></div> 
<script>
$(document).ready(function() {
    $('#addWebsiteForm').on('submit', function(e) {
        e.preventDefault(); // Ngăn chặn hành vi mặc định của nút
        
        // Lấy giá trị từ các trường input
        var tenWebsite = $('#tenWebsite').val();
        var linkWebsite = $('#linkWebsite').val();
        var userId = <?php echo json_encode($_SESSION['userid']); ?>;
      var txtCaptcha = $('#txtCaptcha').val();

        // Gửi dữ liệu qua AJAX
        $.ajax({
            type: 'POST',
           url: 'add_website.php', // Đường dẫn đến file PHP xử lý
            data: {
              userId: userId,
                websiteData: linkWebsite,
                tenWebsite: tenWebsite,
				txtCaptcha:txtCaptcha
            },
            dataType: 'json', // Đặt kiểu dữ liệu mong muốn là JSON
            success: function(response) {
                if (response.message) {
					//alert(response.success+response.message+response.debugSql);
                    $('#message').html(response.message);
                } else {
                    $('#message').html("Không có câu lệnh SQL nào để hiển thị.");
                }
            },
            error: function(xhr, status, error) {
                $('#message').html("Đã xảy ra lỗi: " + xhr.responseText); // Hiển thị chi tiết lỗi
            }
        });
    });
});
</script>