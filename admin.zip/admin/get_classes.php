<?php
header('Content-Type: application/json');

$allowedTypes = array('exercise', 'exercise_process');
$FolderType = isset($_GET['FolderType']) ? trim($_GET['FolderType']) : '';

if (!in_array($FolderType, $allowedTypes, true)) {
    echo json_encode(array('success' => false, 'message' => 'Loại thư mục không hợp lệ', 'classes' => array()));
    exit;
}

$baseDir = dirname(__DIR__) . '/' . $FolderType;

$classes = array();

if (is_dir($baseDir)) {
    $items = scandir($baseDir);
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;
        if (is_dir($baseDir . '/' . $item)) {
            $classes[] = $item;
        }
    }
    natsort($classes); // sắp xếp class8, class9... đúng thứ tự
    $classes = array_values($classes);
}

echo json_encode(array('success' => true, 'classes' => $classes));