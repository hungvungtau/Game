<?php
header('Content-Type: application/json');

$allowedTypes      = array('exercise', 'exercise_process');
$allowedExtensions = array('js', 'php');

$FolderType  = isset($_POST['FolderType'])  ? trim($_POST['FolderType'])  : '';
$ClassName   = isset($_POST['ClassName'])   ? trim($_POST['ClassName'])   : '';
$FileName    = isset($_POST['FileName'])    ? trim($_POST['FileName'])   : '';
$FileContent = isset($_POST['FileContent']) ? $_POST['FileContent']      : '';

// 1. Validate FolderType
if (!in_array($FolderType, $allowedTypes, true)) {
    echo json_encode(array('success' => false, 'message' => 'Loại thư mục không hợp lệ'));
    exit;
}

// 2. Validate ClassName (chỉ chữ/số/_/-)
if ($ClassName === '' || !preg_match('/^[a-zA-Z0-9_\-]+$/', $ClassName)) {
    echo json_encode(array('success' => false, 'message' => 'Tên lớp không hợp lệ'));
    exit;
}

// 3. Validate FileName + lấy đuôi file
$FileName = basename($FileName); // chống path traversal (../../...)
if (!preg_match('/^([a-zA-Z0-9_\-]+)\.(js|php)$/', $FileName, $matches)) {
    echo json_encode(array('success' => false, 'message' => 'Tên file không hợp lệ. Chỉ chữ/số/_/- và đuôi .js hoặc .php'));
    exit;
}
$extension = $matches[2];
if (!in_array($extension, $allowedExtensions, true)) {
    echo json_encode(array('success' => false, 'message' => 'Đuôi file không được phép'));
    exit;
}

// 4. Xác định thư mục đích — bắt buộc thư mục class phải đã tồn tại (không tự tạo)
$classDir = dirname(__DIR__) . '/' . $FolderType . '/' . $ClassName;
if (!is_dir($classDir)) {
    echo json_encode(array('success' => false, 'message' => 'Thư mục lớp không tồn tại: ' . $FolderType . '/' . $ClassName));
    exit;
}

$filePath = $classDir . '/' . $FileName;

// 5. Không cho ghi đè file đã có (tùy bạn, có thể bỏ check này nếu muốn cho phép ghi đè)
if (file_exists($filePath)) {
    echo json_encode(array('success' => false, 'message' => 'File đã tồn tại: ' . $FileName));
    exit;
}

// 6. Ghi file
$written = file_put_contents($filePath, $FileContent);

if ($written === false) {
    echo json_encode(array('success' => false, 'message' => 'Không thể tạo file'));
    exit;
}

// 7. Cấp quyền truy cập cho file (0644: chủ sở hữu đọc/ghi, người khác chỉ đọc)
chmod($filePath, 0644);

echo json_encode(array(
    'success' => true,
    'message' => 'Đã tạo file thành công: ' . $FolderType . '/' . $ClassName . '/' . $FileName
));