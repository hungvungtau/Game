<?php
session_start();
include('class/User.php');

// Tạo đối tượng User
$user = new User();

// Lấy ID từ query string (ví dụ: vertify.php?id=1)
//$id = isset($_GET['id']) ? $_GET['id'] : '1'; // Mặc định là 1 nếu không có ID
$id=1;
// Lấy giá trị cookie dựa trên ID
//$cookie_value = $user->getCookieValueById($id);//getSessionValueById
$cookie_value = $user->getSessionValueById($id);
//$cookie_value = isset($_COOKIE['ma_' . $id]) ? $_COOKIE['ma_' . $id] : null;
if ($cookie_value !== null) {
    echo "Giá trị của cookie ma_$id là: " . htmlspecialchars($cookie_value);
} else {
    echo "Cookie ma_$id không tồn tại.";
}
echo $_SESSION['ma_' . $id]."hung";
?>