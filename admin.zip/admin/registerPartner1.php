<?php
header('Content-Type: application/json'); // Đặt tiêu đề cho phản hồi JSON

include('class/User.php');
$user = new User();

// register1.php
// Lấy dữ liệu từ POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if($_POST['txtCaptcha'] == NULL)
	{
		//echo "Please enter your code";
		$response['message'] .= "Please enter your code ";
	}
	else
	{
	if($_POST['txtCaptcha'] == $_SESSION['security_code'])
	{
					//echo "ma lenh hop le";
			$first_name = trim($_POST["first_name"]);
			$last_name = trim($_POST["last_name"]);
			$phone_mobile = trim($_POST["phone"]);
			$email = trim($_POST["email"]);
			$emailfriend = trim($_POST["emailfriend"]);
			$message = trim($_POST["message"]);
			$partner = trim($_POST["partner"]);
			$password = md5(trim($_POST["password"])); // Chú ý: Nên dùng bcrypt thay cho md5//
			$id_form = 2;

			// Gọi hàm insertUser
			$insertResult = $user->registerPartner();

			// Khởi tạo phản hồi
			$response = [];

			if (isset($insertResult['rowCount']) && $insertResult['rowCount'] > 0) {
				$lastID = $insertResult['lastInsertId'];
				$response['success'] =$insertResult['success'];
				$response['message'] = $insertResult['message'];
			} else {
				$response['success'] = $insertResult['success'];;
				$response['message'] = $insertResult['message'];
				if (isset($insertResult['error'])) {
					$response['message'] = " Error: " . $insertResult['error'];
				}
			}

			
		}
		else
		{
			$response['message'] = "Error:Invalid code ";
		}
	}
	
	// Trả về dữ liệu dưới dạng JSON
			echo json_encode($response);
			exit; // Đảm bảo không có thêm thông tin nào được in 
				
}
?>

<?php
/*header('Content-Type: application/json');
include('class/User.php');
$user = new User();

// Kiểm tra nếu người dùng chưa đăng nhập
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if($_POST['txtCaptcha'] == NULL)
	{
		//echo "Please enter your code";
		echo json_encode(['success' => false, 'message' => 'Please enter your code ']);
	}
	elseif($_POST['txtCaptcha'] == $_SESSION['security_code'])
	{ 
			   // Gọi hàm insertUser
				$insertResult = $user->register1();

			// Khởi tạo phản hồi
				$response = [];
			   
					// Kiểm tra kết quả trả về
				 
			// Kiểm tra kết quả trả về
				if (isset($insertResult['success']) && $insertResult['success'] === true) {
					// Nếu có hàng được chèn vào, trả về thông tin thành công
					$lastInsertId  = $insertResult['lastInsertId'];
					//echo "User registered successfully with ID: " . $lastInsertId;
					echo json_encode([
						'success' => $insertResult['success'],
						'message' => $insertResult['message']
					]);
				} else {
					// Nếu không có hàng nào được chèn, kiểm tra lỗi
					$errorMessage = isset($insertResult['message']) ? $insertResult['message'] : 'An unknown error occurred.';
					echo "Error: " . $errorMessage;
					echo json_encode(['success' => false, 'message' => $errorMessage]);
				}
	}
	else echo json_encode(['success' => false, 'message' => 'Error:Invalid code']);
		
} else {
    echo json_encode(['success' => false, 'message' => 'Yêu cầu không hợp lệ.']);
}*/
?>
