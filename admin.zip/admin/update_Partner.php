<?php
header('Content-Type: application/json'); // Đặt tiêu đề cho phản hồi JSON

include('class/User.php');
$user = new User();

// register1.php
// Lấy dữ liệu từ POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if($_POST['txtCaptcha'] == NULL)
	{
		//echo "Please enter your code";
		$response['message'] .= "Please enter your code ";
	}
	else
	{
	if($_POST['txtCaptcha'] == $_SESSION['security_code'])
	{
			 $id = $_SESSION['userid'];
			$tableName = 'user'; // Tên bảng bạn muốn cập nhật
			$Partner=1;
			// Gọi hàm updateView
			$isUpdated = $user->updatePartner($id, $tableName,$Partner);

			// Gọi hàm insertUser
			

			// Khởi tạo phản hồi
			$response = [];

			if ($isUpdated ['success']=="success") {
				$response['success'] =$isUpdated ['success'];
				$response['message'] = $isUpdated ['message'];
			} else {
				$response['success'] = $isUpdated ['success'];;
				$response['message'] = $isUpdated ['message'];
				/*if (isset($insertResult['error'])) {
					$response['message'] = " Error: " . $insertResult['error'];
				}*/
			}

			
		}
		else
		{
			$response['message'] = "Error:Invalid code ";
		}
	}
	
	// Trả về dữ liệu dưới dạng JSON
			echo json_encode($response);
			exit; // Đảm bảo không có thêm thông tin nào được in 
				
}
?>
