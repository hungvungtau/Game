<?php 
include('class/User.php');
$user = new User();
//$message =  $user->register1();
include('include/header.php');
?>
<title> Unlock Free Strategies to Boost Your Website Traffic with SSC!</title>
<?php include('include/container.php');?>
<div class="container contact">	
	<h2> Unlock Free Strategies to Boost Your Website Traffic Your Online Success with SSC!</h2>
	<div id="signupbox" class="col-md-7">
		<div class="panel panel-info">
			<div class="panel-heading">
				<div class="panel-title">Sign Up</div>				
			</div>  
			<div class="panel-body" >
				<form id="signupform" class="form-horizontal" role="form" method="POST" action="">				
					<?php //if ($message != '') { ?>
						<div id="login-alert" class="alert alert-danger col-sm-12"><?php //echo $message; ?></div>                            
					<?php //} ?>	
					<div class="form-group">
						<label for="firstname" class="col-md-3 control-label">First Name*</label>
						<div class="col-md-9">
							<input type="text" class="form-control" id="first_name" name="first_name" placeholder="First Name" value="<?php //if(!empty($_POST["firstname"])) { echo $_POST["firstname"]; } ?>" required>
						</div>
					</div>
					<div class="form-group">
						<label for="lastname" class="col-md-3 control-label">Last Name</label>
						<div class="col-md-9">
							<input type="text" class="form-control" id="last_name" name="last_name" placeholder="Last Name" value="<?php //if(!empty($_POST["lastname"])) { echo $_POST["lastname"]; } ?>" >
						</div>
					</div>					
					<div class="form-group">
						<label for="email" class="col-md-3 control-label">Email*</label>
						<div class="col-md-9">
							<input type="email" class="form-control" id="email" name="email" placeholder="Email Address" value="<?php //if(!empty($_POST["email"])) { echo $_POST["email"]; } ?>" required>
						</div>
					</div>
					<div class="form-group">
						<label for="email" class="col-md-3 control-label">Phone*</label>
						<div class="col-md-9">
							<input type="phone_mobile" class="form-control" id="phone" name="phone" placeholder="phone mobile" value="<?php //if(!empty($_POST["phone_mobile"])) { echo $_POST["phone_mobile"]; } ?>" required>
						</div>
					</div>					
					<div class="form-group">
						<label for="password" class="col-md-3 control-label">Password*</label>
						<div class="col-md-9">
							<input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
						</div>
					</div>	
					<div class="form-group">
						<label for="password" class="col-md-3 control-label">Captcha*</label>
						<div class="col-md-9">
							 <input type="text" name="txtCaptcha" class="form-control" id="txtCaptcha" placeholder="txtCaptcha" required maxlength="10" size="32" />
						</div>
						<div class="col-md-9">
							<img src="random_image.php" />
						</div>	
					</div>	
                    <fieldset>
					<legend>Offer Your Close Friends a Way to Increase Traffic to Your Free Website</legend>
					<div class="form-group">
						<label for="email" class="col-md-3 control-label">Email*</label>
						<div class="col-md-9">
							<input type="email" class="form-control" id="emailfriend" name="emailfriend" placeholder="Email Address" value="<?php //if(!empty($_POST["email"])) { echo $_POST["email"]; } ?>" required>
						</div>
					</div>
				<div class="form-group">
					<label for="message" class="col-md-3 control-label">You should send your message to your friend as a gift</label>
					<div class="col-md-9">
						<textarea class="form-control" id="message" name="message" placeholder="Your message" rows="5" required><?php //if(!empty($_POST["message"])) { echo $_POST["message"]; } ?></textarea>
					</div>
				</div>

				</fieldset>
					<div class="form-group">						                                  
						<div class="col-md-offset-3 col-md-9">
							<button id="btn-signup" type="button" name="register" value="register" class="btn btn-info"><i class="icon-hand-right"></i> &nbsp Register</button>			
						</div>
					</div>					
					<div class="form-group">
						<div class="col-md-12 control">
							<div style="border-top: 1px solid#888; padding-top:15px; font-size:85%" >
								If You've already an account! 
							<a href="login.php">
								Log In 
							</a>Here
							</div>
						</div>
					</div>  				
				</form>
			 </div>
		</div>
	</div>	
</div>
<div id="message"></div>
<script>
$(document).ready(function() {
    $('#btn-signup').on('click', function(e) {
        e.preventDefault(); // Ngăn chặn hành vi mặc định của nút

        // Lấy giá trị từ các trường input
        var first_name = $('#first_name').val();
        var last_name = $('#last_name').val();
        var phone_mobile = $('#phone').val();
        var email = $('#email').val();
		var emailfriend= $('#emailfriend').val();
		var message = $('#message').val();
		var txtCaptcha = $('#txtCaptcha').val();
        var password = $('#password').val(); // Lưu ý: Mã hóa mật khẩu sẽ được xử lý ở server

        // Gửi dữ liệu qua AJAX
        $.ajax({
            type: 'POST',
            url: 'register1.php', // Đường dẫn đến file PHP xử lý
            data: {
                first_name: first_name,
                last_name: last_name,
                phone: phone_mobile,
                email: email,
				txtCaptcha:txtCaptcha,
                password: password,
				emailfriend:emailfriend,
				message:message
            },
            dataType: 'json', // Đặt kiểu dữ liệu mong muốn là JSON
            success: function(response) {
                if (response.message) {
                    $('#message').html(response.success+response.message+response.data);
                } else {
                    $('#message').html("Không có câu lệnh SQL nào để hiển thị.");
                }
            },
            error: function(xhr, status, error) {
                $('#message').html("Đã xảy ra lỗi: " + xhr.responseText); // Hiển thị chi tiết lỗi
            }
        });
    });
});
</script>
<?php include('include/footer.php');?>