<?php
$dir = "images/";

if (!is_dir($dir)) mkdir($dir, 0777, true);

if (isset($_FILES['image'])) {

    $name = time() . "_" . $_FILES['image']['name'];
    $path = $dir . $name;

    if (move_uploaded_file($_FILES['image']['tmp_name'], $path)) {
        echo $name;
    } else {
        echo "ERROR";
    }
}
