$(document).ready(function() {
    $('#getRandomCode').click(function() {
        // Lấy giá trị từ textbox ẩn
        var ma = $('#ma').val();//
		var id = $('#id').val();
		//alert(id);
        //alert(ma);
        $.ajax({
            //url: 'http://downloads.daykembatnha.top/layma/layma1.php', 
            url: 'http://localhost:8012/layma1/layma1.php',
            method: 'post',
            data: {'ma' : ma,'id' : id},
            success: function(data) {
                // Giả sử dữ liệu trả về là một đối tượng JSON
                //$('#result').text('Mã Code: ' + data.ma + ', success: ' + data.success);
				  //this.disabled = true; // Vô hiệu hóa nút
				  
			//document.getElementById('getRandomCode').addEventListener('click', function() {
				this.innerHTML = "Bạn Chờ Một Xíu Để Nhận Mã Giải Nén";
				startCountdown(40,data.ma);// Bắt đầu đếm ngược từ 40 giây
				//this.disabled = true; // Vô hiệu hóa nút
				document.getElementById('getRandomCode').disabled =true;
       // });
				
                //wpb_ma(data.ma);
            },
            error: function() {
                $('#result').text('Có lỗi xảy ra khi lấy mã code.');
            }
        });
    });
});
function startCountdown(seconds,ma) {
            let countdownTime = seconds;
            const display = document.getElementById("nd");

            const interval = setInterval(() => {
                if (countdownTime >= 0) {
                    display.innerText = "Bạn còn " + countdownTime + " giây nữa";
                    countdownTime--;
                } else {
                    clearInterval(interval); // Dừng bộ đếm
                    display.innerText = "Mã của bạn là:"+ ma; // Hiển thị mã
                }
            }, 1000);
        }