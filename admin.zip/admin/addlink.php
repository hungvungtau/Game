<?php
//session_start();
// Giả sử bạn đã tạo một đối tượng của lớp này
include('class/UserLink.php'); // Đảm bảo đường dẫn đúng

$user = new User1();
$userTable = 'danhmucsanpham'; // Thay bằng tên bảng của bạn
$data = $user->getdata3($userTable); // Gọi hàm để lấy dữ liệu
?>
    
<div class="container mt-5">
    <h2>Add Link Website</h2>
    <form id="addWebsiteForm" enctype="multipart/form-data">
        <div class="form-group">
            <label for="category">Choose category</label>
           <select name="danhmuc" id="category">
			<option value="">Chọn danh mục</option> <!-- Tùy chọn mặc định -->
			<?php if (!empty($data)): // Kiểm tra xem dữ liệu có không ?>
				<?php foreach ($data as $item): ?>
					<option value="<?php echo htmlspecialchars($item['id_dm']); ?>">
						<?php echo htmlspecialchars($item['Tendm']); // Thay 'name' bằng tên cột bạn muốn hiển thị ?>
					</option>
				<?php endforeach; ?>
			<?php else: ?>
				<option value="">Nothing category</option>
			<?php endif; ?>
		</select>
        </div>
		<div class="form-group">
            <label for="Link">Name Link:</label>
            <input type="text" class="form-control" id="Namelink" name="Namelink" required>
        </div>
        <div class="form-group">
            <label for="Link">Link:</label>
            <input type="text" class="form-control" id="link" name="link" required>
        </div>
        <div class="form-group">
            <label for="txtCaptcha" class="col-md-3 control-label">Captcha*</label>
            <div class="col-md-9">
                <input type="text" name="txtCaptcha" class="form-control" id="txtCaptcha" placeholder="txtCaptcha" required maxlength="10" size="32" />
            </div>
        </div>
        <div class="form-group">
            <div class="col-md-9">
                <img src="random_image.php" />
            </div>	
        </div>	
        <button type="submit" class="btn btn-primary" id="AddWebsite">Add Website</button>
    </form>
</div>
<div id="message"></div>
<div id="addWebsiteForm"></div> 
<script>
$(document).ready(function() {
    $('#addWebsiteForm').on('submit', function(e) {
        e.preventDefault(); // Ngăn chặn hành vi mặc định của nút
        
        // Lấy giá trị từ các trường input
        var category = $('#category').val();//Namelink
		var Namelink = $('#Namelink').val();
        var link = $('#link').val();
        var userId = <?php echo json_encode($_SESSION['userid']); ?>;
      var txtCaptcha = $('#txtCaptcha').val();

        // Gửi dữ liệu qua AJAX
        $.ajax({
            type: 'POST',
           url: 'add_link.php', // Đường dẫn đến file PHP xử lýNamelink
            data: {
              userId: userId,
                link: link,
				Namelink: Namelink,
                category: category,
				txtCaptcha:txtCaptcha
            },
            dataType: 'json', // Đặt kiểu dữ liệu mong muốn là JSON
            success: function(response) {
                if (response.message) {
					//alert(response.success+response.message+response.debugSql);
                    $('#message').html(response.success+response.message);
                } else {
                    $('#message').html("Không có câu lệnh SQL nào để hiển thị.");
                }
            },
            error: function(xhr, status, error) {
                $('#message').html("Đã xảy ra lỗi: " + xhr.responseText); // Hiển thị chi tiết lỗi
            }
        });
    });
});
</script>