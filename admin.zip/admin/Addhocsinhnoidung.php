<?php
include('class/UserLink.php');
$user = new User1();

$hocsinhResult = $user->getAllHocSinh();
$hocsinhList = $hocsinhResult['success'] ? $hocsinhResult['data'] : array();

$noidungResult = $user->getAllNoiDung();
$noidungList = $noidungResult['success'] ? $noidungResult['data'] : array();
?>
<div class="container mt-5">
    <h2>Gán Nội Dung Cho Học Sinh</h2>

    <form id="addHocSinhNoiDungForm">
        <div class="form-group">
            <label for="id_hocsinh">Học Sinh:</label>
            <select class="form-control" id="id_hocsinh" required>
                <option value="">-- Chọn học sinh --</option>
                <?php foreach ($hocsinhList as $hs): ?>
                    <option value="<?php echo $hs['Id_hocsinh']; ?>">
                        <?php echo htmlspecialchars($hs['Hovaten']) . ' - ' . htmlspecialchars($hs['Lop']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="id_noidung">Nội Dung:</label>
            <select class="form-control" id="id_noidung" required>
                <option value="">-- Chọn nội dung --</option>
                <?php foreach ($noidungList as $nd): ?>
                    <option value="<?php echo $nd['id']; ?>">
                        <?php echo htmlspecialchars($nd['ten_noidung']) . ' (' . htmlspecialchars($nd['type']) . ')'; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group row">
            <label for="txtCaptcha" class="col-md-3 control-label">Captcha*</label>
            <div class="col-md-9">
                <input type="text" name="txtCaptcha" class="form-control" id="txtCaptcha"
                       placeholder="Nhập mã captcha" required maxlength="10" size="32" />
            </div>
        </div>

        <div class="form-group row">
            <div class="col-md-9">
                <img src="random_image.php" id="captchaImg" style="cursor:pointer;" title="Bấm để đổi mã khác" />
            </div>
        </div>

        <button type="submit" class="btn btn-primary" id="AddHocSinhNoiDung">Gán Nội Dung</button>
    </form>
</div>

<div id="message" class="mt-3"></div>

<script>
$(document).ready(function() {

    // Bấm vào ảnh captcha để đổi mã mới
    $('#captchaImg').on('click', function() {
        $(this).attr('src', 'random_image.php?' + new Date().getTime());
    });

    $('#addHocSinhNoiDungForm').on('submit', function(e) {
        e.preventDefault();

        var id_hocsinh = $('#id_hocsinh').val();
        var id_noidung = $('#id_noidung').val();
        var txtCaptcha = $('#txtCaptcha').val().trim();
        var userId     = <?php echo json_encode(isset($_SESSION['userid']) ? $_SESSION['userid'] : null); ?>;

        if (id_hocsinh === '') {
            $('#message').removeClass().addClass('alert alert-danger').text('Chưa chọn học sinh').show();
            return;
        }
        if (id_noidung === '') {
            $('#message').removeClass().addClass('alert alert-danger').text('Chưa chọn nội dung').show();
            return;
        }

        var $btn = $('#AddHocSinhNoiDung');
        $btn.prop('disabled', true).text('Đang lưu...');

        $.ajax({
            type: 'POST',
            url: 'Add_hocsinhnoidung.php',
            data: {
                userId: userId,
                id_hocsinh: id_hocsinh,
                id_noidung: id_noidung,
                txtCaptcha: txtCaptcha
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    $('#message').removeClass().addClass('alert alert-success').html(response.message).show();
                    $('#id_noidung').val(''); // chỉ reset nội dung, giữ lại học sinh đang chọn để gán tiếp
                    $('#txtCaptcha').val('');
                    $('#captchaImg').attr('src', 'random_image.php?' + new Date().getTime());
                } else {
                    $('#message').removeClass().addClass('alert alert-danger').html(response.message).show();
                    $('#captchaImg').attr('src', 'random_image.php?' + new Date().getTime());
                }
            },
            error: function(xhr) {
                $('#message').removeClass().addClass('alert alert-danger')
                    .html("Đã xảy ra lỗi: " + xhr.responseText).show();
            },
            complete: function() {
                $btn.prop('disabled', false).text('Gán Nội Dung');
            }
        });
    });
});
</script>