<?php
session_start();
//including the database connection file
include_once("config.php");
//$mysqli = new mysqli($servername, $username, $password, $dbname);
$mysqli->set_charset("utf8mb4");
// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
	$id=$_SESSION["id"];
	$position=$_SESSION["position"];
    session_write_close();
	// Fetch data from tbl_users
if($position=="admin")
  $sql = "SELECT id_khach, first_name, last_name, department, phone_mobile, email, birthdate, description, email2, noidung, status FROM tbl_khach";
else
  $sql = "SELECT id_khach, first_name, last_name, department, phone_mobile, email, birthdate, description, email2, noidung, status FROM tbl_khach where id_users='".$id."'";
$result = $mysqli->query($sql);

} else {
    // since the username is not set in session, the user is not-logged-in
    // he is trying to access this page unauthorized
    // so let's clear all session variables and redirect him to index
    session_unset();
    session_write_close();
    $url = "./index.php";
    header("Location: $url");
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Show List Customers</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            // Add new user
            $('#add-user').click(function() {
                // Code to add new user
            });

            // Edit user
            $('.edit-user').click(function() {
                // Code to edit user
            });

            // Delete user
            $('.delete-user').click(function() {
                // Code to delete user
            });
        });
    </script>
</head>
<body>
   <h1>Show List Customers</h1>
<table id="users-table" class="table table-striped table-hover">
    <thead>
        <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Department</th>
            <th>Phone Mobile</th>
            <th>Email</th>
            <th>Birthdate</th>
            <th>Description</th>
            <th>Email2</th>
            <th>Noidung</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $rowClass = '';
                switch ($row['status']) {
                    case 'Active':
                        $rowClass = 'table-success';
                        break;
                    case 'Inactive':
                        $rowClass = 'table-danger';
                        break;
                    default:
                        $rowClass = '';
                        break;
                }
                echo "<tr class='$rowClass'>";
                echo "<td>" . $row["first_name"] . "</td>";
                echo "<td>" . $row["last_name"] . "</td>";
                echo "<td>" . $row["department"] . "</td>";
                echo "<td>" . $row["phone_mobile"] . "</td>";
                echo "<td>" . $row["email"] . "</td>";
                echo "<td>" . $row["birthdate"] . "</td>";
                echo "<td>" . $row["description"] . "</td>";
                echo "<td>" . $row["email2"] . "</td>";
                echo "<td>" . $row["noidung"] . "</td>";
                echo "<td>" . $row["status"] . "</td>";
                echo "<td>
                        <button class='edit-user btn btn-primary btn-sm'>Edit</button>
                        <button class='delete-user btn btn-danger btn-sm'>Delete</button>
                     </td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='11'>No data available</td></tr>";
        }
        ?>
    </tbody>
</table>
    <button id="add-user">Add User</button>
</body>
</html>