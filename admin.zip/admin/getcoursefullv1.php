<?php
session_start();

if (!isset($_SESSION["type"]) || $_SESSION["type"] !== "administrator") {
    ?>
    <div class="container mt-5">
        <div class="alert alert-danger">
            Bạn không có quyền truy cập trang này.
        </div>
    </div>
    <?php
    exit;
}

include('class/UserLink.php');
$user = new User1();

$contentsResult = $user->getData9();
$contents = $contentsResult['success'] ? $contentsResult['data'] : array();

$hocsinhResult = $user->getAllHocSinh();
$hocsinhList = $hocsinhResult['success'] ? $hocsinhResult['data'] : array();

$noidungResult = $user->getAllNoiDung();
$noidungList = $noidungResult['success'] ? $noidungResult['data'] : array();
?>

<div class="container mt-4">
    <h2>Phân quyền nội dung cho học sinh</h2>

    <div id="message" class="alert" style="display: none;"></div>

    <div class="mb-3">
        <button id="selectAll" class="btn btn-sm btn-outline-secondary">Select All</button>
        <button id="unselectAll" class="btn btn-sm btn-outline-secondary">Unselect All</button>
        <button id="deleteSelected" class="btn btn-sm btn-danger">Delete Selected</button>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-hover" id="contentTable">
            <thead class="thead-dark">
                <tr>
                    <th width="40px"><input type="checkbox" id="checkAll"></th>
                    <th width="100px">Actions</th>
                    <th>ID</th>
                    <th>Học Sinh</th>
                    <th>Lớp</th>
                    <th>Tên Nội Dung</th>
                    <th>Hoạt động</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($contents)): ?>
                    <tr><td colspan="7" class="text-center">Chưa có dữ liệu</td></tr>
                <?php else: ?>
                    <?php foreach ($contents as $ct): ?>
                        <tr data-id="<?php echo $ct['id']; ?>">
                            <td><input type="checkbox" class="content-checkbox" value="<?php echo $ct['id']; ?>"></td>
                            <td>
                                <div class="normal-buttons">
                                    <button class="btn btn-sm btn-info edit-btn"><i class="fas fa-edit"></i></button>
                                    <button class="btn btn-sm btn-danger delete-btn"><i class="fas fa-trash"></i></button>
                                </div>
                                <div class="edit-buttons" style="display:none;">
                                    <button class="btn btn-sm btn-success save-inline-btn"><i class="fas fa-save"></i></button>
                                    <button class="btn btn-sm btn-secondary cancel-inline-btn"><i class="fas fa-times"></i></button>
                                </div>
                            </td>
                            <td><?php echo $ct['id']; ?></td>

                            <td class="editable" data-field="id_hocsinh" data-id-hocsinh="<?php echo $ct['id_hocsinh']; ?>">
                                <?php echo htmlspecialchars($ct['Hovaten']); ?>
                            </td>
                            <td class="editable-lop">
                                <?php echo htmlspecialchars($ct['Lop']); ?>
                            </td>

                            <td class="editable" data-field="id_noidung" data-id-noidung="<?php echo $ct['id_noidung']; ?>">
                                <?php echo htmlspecialchars($ct['ten_noidung']); ?>
                            </td>

                            <td class="editable" data-field="active">
                                <select class="form-control form-control-sm active-select">
                                    <option value="1" <?php if ($ct['active'] == 1) echo 'selected'; ?>>Mở</option>
                                    <option value="0" <?php if ($ct['active'] == 0) echo 'selected'; ?>>Khóa</option>
                                </select>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
var hocSinhList = <?php echo json_encode($hocsinhList); ?>;
var noiDungList = <?php echo json_encode($noidungList); ?>;

$(document).ready(function() {

    $('#checkAll').click(function() {
        $('.content-checkbox').prop('checked', this.checked);
    });
    $('#selectAll').click(function() {
        $('.content-checkbox').prop('checked', true);
    });
    $('#unselectAll').click(function() {
        $('.content-checkbox').prop('checked', false);
    });

    // Bật chế độ sửa
    $(document).on('click', '.edit-btn', function() {
        const row = $(this).closest('tr');
        const currentIdHocSinh = row.find('[data-field="id_hocsinh"]').data('id-hocsinh');
        const currentIdNoiDung = row.find('[data-field="id_noidung"]').data('id-noidung');

        row.find('.active-select').data('old', row.find('.active-select').val());

        // Dropdown chọn học sinh
        let hsOptions = '';
        hocSinhList.forEach(function(hs) {
            const selected = (String(hs.Id_hocsinh) === String(currentIdHocSinh)) ? 'selected' : '';
            hsOptions += `<option value="${hs.Id_hocsinh}" data-lop="${hs.Lop}" ${selected}>${hs.Hovaten} - ${hs.Lop}</option>`;
        });
        const $hsCell = row.find('[data-field="id_hocsinh"]');
        $hsCell.data('old-html', $hsCell.html());
        $hsCell.html(`<select class="form-control form-control-sm hocsinh-select">${hsOptions}</select>`);

        // Dropdown chọn nội dung (thay vì gõ ID)
        let ndOptions = '';
        noiDungList.forEach(function(nd) {
            const selected = (String(nd.id) === String(currentIdNoiDung)) ? 'selected' : '';
            ndOptions += `<option value="${nd.id}" ${selected}>${nd.ten_noidung}</option>`;
        });
        const $ndCell = row.find('[data-field="id_noidung"]');
        $ndCell.data('old-html', $ndCell.html());
        $ndCell.html(`<select class="form-control form-control-sm noidung-select">${ndOptions}</select>`);

        row.find('.normal-buttons').hide();
        row.find('.edit-buttons').show();
    });

    // Hủy sửa
    $(document).on('click', '.cancel-inline-btn', function() {
        const row = $(this).closest('tr');

        row.find('[data-field="id_hocsinh"]').html(row.find('[data-field="id_hocsinh"]').data('old-html'));
        row.find('[data-field="id_noidung"]').html(row.find('[data-field="id_noidung"]').data('old-html'));

        row.find('.active-select').val(row.find('.active-select').data('old'));
        row.find('.edit-buttons').hide();
        row.find('.normal-buttons').show();
    });

    // Lưu chỉnh sửa
    $(document).on('click', '.save-inline-btn', function() {
        const row = $(this).closest('tr');
        const id = row.data('id');

        const $hsSelect = row.find('.hocsinh-select');
        const id_hocsinh = $hsSelect.val();
        const hovaten    = $hsSelect.find('option:selected').text().split(' - ')[0];
        const lop        = $hsSelect.find('option:selected').data('lop');

        const $ndSelect = row.find('.noidung-select');
        const id_noidung  = $ndSelect.val();
        const ten_noidung = $ndSelect.find('option:selected').text();

        const active = row.find('.active-select').val();

        $('#message').removeClass().addClass('alert alert-info').text('Đang lưu...').show();

        $.ajax({
            url: 'update_coursefull.php',
            type: 'POST',
            data: { id: id, id_hocsinh: id_hocsinh, id_noidung: id_noidung, active: active },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    row.find('[data-field="id_hocsinh"]').attr('data-id-hocsinh', id_hocsinh).text(hovaten);
                    row.find('.editable-lop').text(lop);
                    row.find('[data-field="id_noidung"]').attr('data-id-noidung', id_noidung).text(ten_noidung);

                    row.find('.edit-buttons').hide();
                    row.find('.normal-buttons').show();
                    $('#message').removeClass().addClass('alert alert-success').text('Cập nhật thành công!').show().delay(2000).fadeOut();
                } else {
                    $('#message').removeClass().addClass('alert alert-danger').text('Lỗi: ' + response.message).show();
                }
            },
            error: function() {
                $('#message').removeClass().addClass('alert alert-danger').text('Không thể cập nhật dữ liệu.').show();
            }
        });
    });
});
</script>