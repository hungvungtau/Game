<?php
header('Content-Type: application/json');

function taoThuMuc($path) {
    if (!file_exists($path)) {
        if (mkdir($path, 0755, true)) {
            return array(
                'success' => true,
                'message' => 'Đã tạo thành công thư mục: ' . htmlspecialchars($path)
            );
        } else {
            return array(
                'success' => false,
                'message' => 'Lỗi: Không thể tạo thư mục ' . htmlspecialchars($path)
            );
        }
    } else {
        return array(
            'success' => false,
            'message' => 'Thư mục đã tồn tại: ' . htmlspecialchars($path)
        );
    }
}

$FolderType   = isset($_POST['FolderType']) ? trim($_POST['FolderType']) : '';
$Namecategory = isset($_POST['Namecategory']) ? trim($_POST['Namecategory']) : '';

$allowedTypes = array('exercise', 'exercise_process');

if ($Namecategory === '') {
    echo json_encode(array('success' => false, 'message' => 'Chưa nhập tên thư mục'));
    exit;
}

if (!in_array($FolderType, $allowedTypes, true)) {
    echo json_encode(array('success' => false, 'message' => 'Loại thư mục không hợp lệ'));
    exit;
}

if (!preg_match('/^[a-zA-Z0-9_\-]+$/', $Namecategory)) {
    echo json_encode(array('success' => false, 'message' => 'Tên thư mục chỉ được chứa chữ, số, _ , -'));
    exit;
}

// lùi lên 1 cấp (ra khỏi thư mục admin) rồi mới ghép FolderType/Namecategory
$folderPath = dirname(__DIR__) . '/' . $FolderType . '/' . $Namecategory;

$result = taoThuMuc($folderPath);

echo json_encode($result);