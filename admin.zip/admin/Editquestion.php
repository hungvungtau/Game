<?php

include('class/User.php');

$user = new User();


$questions = $user->getData5(
    'quenstion_practice',
    true
);

?>


<div class="container mt-4">

    <h2>Danh sách câu hỏi thực hành</h2>

    <div
        id="message"
        class="alert"
        style="display:none;">
    </div>


    <div class="table-responsive">

        <table
            class="table table-bordered table-hover">

            <thead class="thead-dark">

                <tr>

                    <th>Action</th>

                    <th>ID</th>

                    <th>ID bài</th>

                    <th>Câu hỏi</th>

                    <th>Hình</th>

                </tr>

            </thead>


            <tbody>

            <?php

            foreach(
                $questions
                as
                $row
            ){

            ?>

                <tr
                    data-id="<?php echo $row['Id_qs']; ?>">

                    <td>

                        <div class="normal-buttons">

                            <button
                                class="btn btn-info btn-sm edit-btn">

                                Edit

                            </button>

                        </div>


                        <div
                            class="edit-buttons"
                            style="display:none;">

                            <button
                                class="btn btn-success btn-sm save-inline-btn">

                                Save

                            </button>


                            <button
                                class="btn btn-secondary btn-sm cancel-inline-btn">

                                Cancel

                            </button>

                        </div>

                    </td>


                    <td>

                        <?php
                        echo $row['Id_qs'];
                        ?>

                    </td>


                    <td
                        class="editable"
                        data-field="Id_cs">

                        <?php
                        echo $row['Id_cs'];
                        ?>

                    </td>


                    <td
                        class="editable"
                        data-field="Quenstion">

                        <?php
                        echo htmlspecialchars(
                            $row['Quenstion']
                        );
                        ?>

                    </td>


                    <td
                        class="editable"
                        data-field="Image">

                        <?php
                        echo htmlspecialchars(
                            $row['Image']
                        );
                        ?>

                    </td>

                </tr>

            <?php
            }
            ?>

            </tbody>

        </table>

    </div>

</div>




<script>

$(document).ready(function(){



    /*
    edit
    */
    $(document).on(
    'click',
    '.edit-btn',
    function(){


        var row =
        $(this).closest('tr');


        row.find('.editable').each(
        function(){

            var val =
            $(this).text().trim();


            $(this).data(
                'old',
                val
            );


            $(this).html(

                '<input type="text" class="form-control form-control-sm" value="'+val+'">'

            );

        });


        row.find(
            '.normal-buttons'
        ).hide();


        row.find(
            '.edit-buttons'
        ).show();

    });





    /*
    cancel
    */
    $(document).on(
    'click',
    '.cancel-inline-btn',
    function(){


        var row =
        $(this).closest('tr');


        row.find('.editable').each(
        function(){

            $(this).text(

                $(this).data(
                    'old'
                )

            );

        });


        row.find(
            '.edit-buttons'
        ).hide();


        row.find(
            '.normal-buttons'
        ).show();

    });





    /*
    save
    */
    $(document).on(
    'click',
    '.save-inline-btn',
    function(){


        var row =
        $(this).closest('tr');


        var id =
        row.data('id');


        var data = {

            Id_qs:id

        };



        row.find('.editable').each(
        function(){

            var field =
            $(this).data(
                'field'
            );


            var value =
            $(this)
            .find('input')
            .val();


            data[field] =
            value;

        });




        $.ajax({

            url:'Edit_question.php',

            type:'POST',

            data:data,

            dataType:'json',


            success:function(response){


                if(
                    response.success
                ){


                    row.find('.editable').each(
                    function(){

                        var field =
                        $(this).data(
                            'field'
                        );


                        $(this).text(
                            data[field]
                        );

                    });


                    row.find(
                        '.edit-buttons'
                    ).hide();


                    row.find(
                        '.normal-buttons'
                    ).show();



                    $('#message')
                    .removeClass()
                    .addClass(
                        'alert alert-success'
                    )
                    .html(
                        'Cập nhật thành công'
                    )
                    .show();

                }

            }

        });

    });

});

</script>