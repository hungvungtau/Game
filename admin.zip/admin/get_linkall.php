<?php
header('Content-Type: application/json');

include('class/UserLink.php');
$user = new User1();

// Kiểm tra nếu người dùng chưa đăng nhập
if (!isset($_SESSION['userid'])) {
    echo json_encode(['success' => false, 'message' => 'Chưa đăng nhập.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_SESSION['userid'];
    $tableName = 'link';

    // Gọi hàm để lấy dữ liệu
    $result = $user->getdata1($tableName,true); // Lấy tất cả dữ liệu từ bảng
//print_r($result);
    // Kiểm tra kết quả trả về
    if ($result !== null) {
        if (count($result) > 0) {
            echo json_encode(['success' => true, 'data' => $result]); // Trả về toàn bộ dữ liệu
        } else {
            echo json_encode(['success' => false, 'message' => 'Không tìm thấy dữ liệu.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Lỗi truy vấn cơ sở dữ liệu.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Yêu cầu không hợp lệ.']);
}
?>