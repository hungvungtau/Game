
<?php
include('class/UserLink.php');
$user = new User1();

$id = intval($_POST['Id_hocsinh']);

$data = [
    'Id_khoi'     => $_POST['Id_khoi'],
    'Hovaten'     => $_POST['Hovaten'],
    'Lop'         => $_POST['Lop'],
    'Ngaysinh'    => $_POST['Ngaysinh'],
    'Diachi'      => $_POST['Diachi'],
    'Dienthoai'   => $_POST['Dienthoai'],
    'Hotencha'    => $_POST['Hotencha'],
    'Dienthoai1'  => $_POST['Dienthoai1'],
    'Hotenme'     => $_POST['Hotenme']
];

if ($user->updateRecord('hocsinh', $data, 'Id_hocsinh', $id)) {
    echo json_encode(['success' => true, 'message' => 'Cập nhật thành công']);
} else {
    echo json_encode(['success' => false, 'message' => 'Không thể cập nhật dữ liệu']);
}