<button id="btn-signup" type="button" name="register" value="register" class="btn btn-info">
    <i class="icon-hand-right"></i> &nbsp Register
</button>
<div id="message"></div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
$(document).ready(function() {
    $('#btn-signup').on('click', function(e) {
        e.preventDefault(); // Ngăn chặn hành vi mặc định của nút

        // Gửi dữ liệu qua AJAX
        $.ajax({
            type: 'POST',
            url: 'get_price1.php', // Đường dẫn đến file PHP xử lý
            dataType: 'json', // Đặt kiểu dữ liệu mong muốn là JSON
            success: function(response) {
                if (response.success) {
                    $('#message').html("Dữ liệu: " + JSON.stringify(response.data)); // Hiển thị dữ liệu
                } else {
                    $('#message').html("Lỗi: " + response.message); // Hiển thị thông điệp lỗi
                }
            },
            error: function(xhr, status, error) {
                $('#message').html("An error occurred: " + error); // Hiển thị lỗi nếu có
            }
        });
    });
});
</script>