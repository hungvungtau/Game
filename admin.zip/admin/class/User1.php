<?php session_start();
require('./include/config.php');

class User extends dbConfig {	
     protected $hostName;
    protected $userName;
    protected $password;
    protected $dbName;
    public $userTable = 'user';
    public $dbConnect; // MySQLi connection
    public $dbConnect1; // PDO connection
 		
   public function __construct($option = null) {
    // Kiểm tra và thiết lập các thông tin kết nối chỉ một lần
    if (empty($this->hostName) || empty($this->userName) || empty($this->password) || empty($this->dbName)) {
        $database = new dbConfig();            
        $this->hostName = $database->serverName;
        $this->userName = $database->userName;
        $this->password = $database->password;
        $this->dbName = $database->dbName;
    }

    // Kết nối đến cơ sở dữ liệu
    if ($option === 'mysqli') {
        $this->connectMySQLi();
    } elseif ($option === 'pdo') {
        $this->connectPDO();
    }
}

    public function connectMySQLi() {
        $this->dbConnect = new mysqli($this->hostName, $this->userName, $this->password, $this->dbName);
        
        if ($this->dbConnect->connect_error) {
            die("Error failed to connect to MySQL: " . $this->dbConnect->connect_error);
        }
    }

    public function connectPDO() {
        $dboptions = array(
            PDO::ATTR_PERSISTENT => FALSE,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
        );

        try {
            $this->dbConnect1 = new PDO('mysql:host=' . $this->hostName . ';dbname=' . $this->dbName, $this->userName, $this->password, $dboptions);
        } catch (Exception $ex) {
            echo $ex->getMessage();
            die;
        }
    }
	 // Phương thức để lấy kết nối MySQLi
    public function getMySQLiConnection() {
        return $this->dbConnect;
    }

    // Phương thức để lấy kết nối PDO
    public function getPDOConnection() {
        return $this->dbConnect1;
    }
public function getData($sqlQuery) {
    $result = mysqli_query($this->dbConnect, $sqlQuery);
    if (!$result) {
        return false; // Trả về false nếu truy vấn thất bại
    }
    return mysqli_fetch_all($result, MYSQLI_ASSOC); // Trả về tất cả các hàng trong một mảng
}
public function getData1($userTable, $includeSelf = false) {
    // Xây dựng câu lệnh SQL
    $sql = "SELECT * FROM " . $userTable;

    // Nếu không bao gồm bản ghi của người dùng hiện tại, thêm điều kiện
    if (!$includeSelf) {
        $sql .= " WHERE Id_user != '" . $_SESSION['userid'] . "'";
    }

    $result = $this->dbConnect->query($sql);

    // Kiểm tra lỗi truy vấn
    if (!$result) {
        die("Query failed: " . $this->dbConnect->error);
    }

    // Khởi tạo mảng kết quả
    $links = [];

    // Lấy dữ liệu từ kết quả truy vấn
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $links[] = $row; // Thêm từng hàng vào mảng
        }
    }

    // Trả về mảng kết quả, có thể rỗng nếu không có dữ liệu
    return $links;
}
public function getNumRows($sqlQuery) {
		$result = mysqli_query($this->dbConnect, $sqlQuery);
		if(!$result){
			die('Error in query: '. mysqli_error());
		}
		$numRows = mysqli_num_rows($result);
		return $numRows;
	}
 public function loginStatus (){
		if(empty($_SESSION["userid"])) {
			header("Location: login.php");
		}
	}	
   	public function login(){		
		$errorMessage = '';
		if(!empty($_POST["login"]) && $_POST["loginId"]!=''&& $_POST["loginPass"]!='') {	
			$loginId = $_POST['loginId'];
			$password = $_POST['loginPass'];
			if(isset($_COOKIE["loginPass"]) && $_COOKIE["loginPass"] == $password) {
				$password = $_COOKIE["loginPass"];
			} else {
				$password = md5($password);
			}	
			$sqlQuery = "SELECT * FROM ".$this->userTable." 
				WHERE email='".$loginId."' AND password='".$password."' AND status = 'active'";
			$resultSet = mysqli_query($this->dbConnect, $sqlQuery);
			$isValidLogin = mysqli_num_rows($resultSet);	
			if($isValidLogin){
				if(!empty($_POST["remember"]) && $_POST["remember"] != '') {
					setcookie ("loginId", $loginId, time()+ (10 * 365 * 24 * 60 * 60));  
					setcookie ("loginPass",	$password,	time()+ (10 * 365 * 24 * 60 * 60));
				} else {
					$_COOKIE['loginId' ]='';
					$_COOKIE['loginPass'] = '';
				}
				$userDetails = mysqli_fetch_assoc($resultSet);
				$_SESSION["userid"] = $userDetails['id'];
				$_SESSION["email"] = $userDetails['email'];
				$_SESSION["name"] = $userDetails['first_name']." ".$userDetails['last_name'];
				header("location: index.php"); 		
			} else {		
				$errorMessage = "Invalid login!";		 
			}
		} else if(!empty($_POST["loginId"])){
			$errorMessage = "Enter Both user and password!";	
		}
		return $errorMessage; 		
	}
public function adminLoginStatus (){
		if(empty($_SESSION["adminUserid"])) {
			header("Location: index.php");
		}
	}
	public function addWebsite($userId, $website, $Tenwebsite) {
    if ($userId) {
        // Bước 1: Kiểm tra số lượng website hiện tại của người dùng
        $countQuery = "SELECT COUNT(*) as total FROM linkwebsite WHERE Id_user = ?";
        
        // Chuẩn bị câu lệnh
        $stmtCount = $this->dbConnect1->prepare($countQuery);
        $stmtCount->bind_param("i", $userId);

        // Thực thi câu lệnh
        if ($stmtCount->execute()) {
            $result = $stmtCount->get_result();
            $row = $result->fetch_assoc();
            $currentCount = $row['total'];
        } else {
            return false; // Đếm không thành công
        }

        // Bước 2: Lấy Limit_website từ bảng user
        $limitQuery = "SELECT Limit_website FROM user WHERE id = ?";
        $stmtLimit = $this->dbConnect1->prepare($limitQuery);
        $stmtLimit->bind_param("i", $userId);

        if ($stmtLimit->execute()) {
            $result = $stmtLimit->get_result();
            $row = $result->fetch_assoc();
            $limitWebsite = $row['Limit_website'];
        } else {
            return false; // Lấy limit không thành công
        }

        // Bước 3: Kiểm tra xem có thể thêm website không
        if ($currentCount < $limitWebsite) {
            // Bước 4: Thêm website vào bảng linkwebsite
            $insertQuery = "INSERT INTO linkwebsite (Id_user, Link, Tenwebsite) VALUES (?, ?, ?)";
            $stmtInsert = $this->dbConnect1->prepare($insertQuery);
            $stmtInsert->bind_param("iss", $userId, $website, $Tenwebsite); // Sửa tên biến từ $Link thành $website

            // Thực thi câu lệnh
            if ($stmtInsert->execute()) {
                return true; // Thêm thành công
            } else {
                return false; // Thêm thất bại
            }
        } else {
            return false; // Đã đạt giới hạn website
        }
    }
    return false; // Nếu không có userId
} 
public function getLinks($userTable) {
    $sql = "SELECT Tenwebsite, Link, View, Id FROM " . $userTable . " WHERE Id_user != '" . $_SESSION['userid'] . "'";
    $result = $this->dbConnect->query($sql);

    if (!$result) {
        die("Query failed: " . $this->conn->error); // Kiểm tra lỗi truy vấn
    }

    $links = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $links[] = $row;
        }
    }

    return $links;
}
public function getwebsite($userTable) {
    $sql = "SELECT Tenwebsite, Link, View, Id FROM " . $userTable . " WHERE Id_user = '" . $_SESSION['userid'] . "'";
    $result = $this->dbConnect->query($sql);

    if (!$result) {
        die("Query failed: " . $this->conn->error); // Kiểm tra lỗi truy vấn
    }

    $links = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $links[] = $row;
        }
    }

    return $links;
}
public function updateWebsiteCount($userId, $websiteId) {
    if ($userId && $websiteId) {
        // Bước 1: Đếm số lượng website trong bảng linkwebsite với Id cụ thể
        $countQuery = "SELECT COUNT(*) as total FROM linkwebsite WHERE Id = ?";
        
        // Chuẩn bị câu lệnh
        $stmtCount = $this->dbConnect1->prepare($countQuery);
        $stmtCount->bind_param("i", $websiteId);

        // Thực thi câu lệnh
        if ($stmtCount->execute()) {
            $result = $stmtCount->get_result();
            $row = $result->fetch_assoc();
            $totalWebsites = $row['total'];
        } else {
            return false; // Đếm không thành công
        }

        // Bước 2: Cập nhật số lượng website vào bảng user
        $updateQuery = "UPDATE user SET number_web = ? WHERE Id = ?";
        
        // Chuẩn bị câu lệnh
        $stmtUpdate = $this->dbConnect1->prepare($updateQuery);
        $stmtUpdate->bind_param("ii", $totalWebsites, $userId);

        // Thực thi câu lệnh
        if ($stmtUpdate->execute()) {
            return true; // Cập nhật thành công
        } else {
            return false; // Cập nhật thất bại
        }
    }
    return false; // Nếu không có userId hoặc websiteId
}
public function updateView($id, $tableName) {
    if ($id) {
        // Truy vấn SQL để cập nhật lượt view
        $updateQuery = "UPDATE " . $tableName . " SET View = View + 1 WHERE Id = ?";
        
        // Chuẩn bị câu lệnh
        $stmt = $this->dbConnect1->prepare($updateQuery);
        $stmt->bind_param("i", $id);

        // Thực thi câu lệnh
        if ($stmt->execute()) {
            return true; // Cập nhật thành công
        } else {
            return false; // Cập nhật thất bại
        }
    }
    return false; // Nếu không có ID
}
	public function adminLogin(){		
		$errorMessage = '';
		if(!empty($_POST["login"]) && $_POST["email"]!=''&& $_POST["password"]!='') {	
			$email = $_POST['email'];
			$password = $_POST['password'];
			$sqlQuery = "SELECT * FROM ".$this->userTable." 
				WHERE email='".$email."' AND password='".md5($password)."' AND status = 'active' AND type = 'administrator'";
			$resultSet = mysqli_query($this->dbConnect, $sqlQuery);
			$isValidLogin = mysqli_num_rows($resultSet);	
			if($isValidLogin){
				$userDetails = mysqli_fetch_assoc($resultSet);
				$_SESSION["adminUserid"] = $userDetails['id'];
				$_SESSION["admin"] = $userDetails['first_name']." ".$userDetails['last_name'];
				header("location: dashboard.php"); 		
			} else {		
				$errorMessage = "Invalid login!";		 
			}
		} else if(!empty($_POST["login"])){
			$errorMessage = "Enter Both user and password!";	
		}
		return $errorMessage; 		
	}

public function checkEmailExists($email, $id_form) {
    if ($this->dbConnect1 === null) {
        return ['msg' => "Database connection is not established.", 'msgType' => "error"];
    }

    // Xây dựng câu lệnh SQL
    $sql = "SELECT COUNT(*) AS count FROM tbl_users WHERE email = :email_id AND id_form = :id_form";

    try {
        // Chuẩn bị câu lệnh
        $stmt = $this->dbConnect1->prepare($sql);

        // Liên kết giá trị với tham số
        $stmt->bindValue(":email_id", $email);
        $stmt->bindValue(":id_form", $id_form);
        
        // Thực thi câu lệnh
        $stmt->execute();
        
        // Lấy kết quả
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        // Kiểm tra số lượng email tồn tại
        if ($result['count'] > 0) {
            return ['msg' => "Email already exists", 'msgType' => "warning"];
        } else {
            return ['msg' => "Email is available", 'msgType' => "success"];
        }
    } catch (Exception $e) {
        // Xử lý lỗi nếu có
        return ['msg' => "Query failed: " . $e->getMessage(), 'msgType' => "error"];
    }
}
	public function register(){		
		$message = '';
		if(!empty($_POST["register"]) && $_POST["email"] !='') {
			$sqlQuery = "SELECT * FROM ".$this->userTable." 
				WHERE email='".$_POST["email"]."'";
			$result = mysqli_query($this->dbConnect, $sqlQuery);
			$isUserExist = mysqli_num_rows($result);
			if($isUserExist) {
				$message = "User already exist with this email address.";
			} else {			
				$authtoken = $this->getAuthtoken($_POST["email"]);
				$insertQuery = "INSERT INTO ".$this->userTable."(first_name, last_name, email, password, authtoken) 
				VALUES ('".$_POST["firstname"]."', '".$_POST["lastname"]."', '".$_POST["email"]."', '".md5($_POST["passwd"])."', '".$authtoken."')";
				$userSaved = mysqli_query($this->dbConnect, $insertQuery);
				if($userSaved) {				
					$link = "<a href='http://webdamn.com/demo/user-management-system/verify.php?authtoken=".$authtoken."'>Verify Email</a>";			
					$toEmail = $_POST["email"];
					$subject = "Verify email to complete registration";
					$msg = "Hi there, click on this ".$link." to verify email to complete registration.";
					$msg = wordwrap($msg,70);
					$headers = "From: info@webdamn.com";
					if(mail($toEmail, $subject, $msg, $headers)) {
						$message = "Verification email send to your email address. Please check email and verify to complete registration.";
					}
				} else {
					$message = "User register request failed.";
				}
			}
		}
		return $message;
	}
public function register1() {
    $message = '';
    $success = false;

    if (!empty($_POST["register"]) && !empty($_POST["email"])) {
        require_once "phpmailer/class.phpmailer.php";

        // Lấy dữ liệu từ POST
        $first_name = trim($_POST["first_name"]);
        $last_name = trim($_POST["last_name"]);
        $phone_mobile = trim($_POST["phone"]);
        $email = trim($_POST["email"]);
        $password = md5(trim($_POST["password"])); // Chú ý: Nên dùng bcrypt thay cho md5
        $id_form = 2;

        // Gọi hàm checkEmailExists
        $emailCheckResult = $this->checkEmailExists($email, $id_form);

        if ($emailCheckResult['msgType'] === "warning") {
            $message = $emailCheckResult['msg'];
        } else {
            $authtoken = $this->getAuthtoken($email);
            $insertResult = $this->insertUser($id_form, $first_name, $last_name, $phone_mobile, $email, $password);

            if (isset($insertResult['rowCount']) && $insertResult['rowCount'] > 0) {
                $lastID = $insertResult['lastInsertId'];
                $message = "User inserted successfully with ID: " . $lastID . ". Verification email sent.";
                $this->sendEmailVerification($last_name, $email, $lastID, $id_form);
                $success = true;
            } else {
                $message = "Failed to insert user.";
                if (isset($insertResult['error'])) {
                    $message .= " Error: " . $insertResult['error'];
                }
            }
        }
    } else {
        $message = "Please fill in all required fields.";
    }

    // Trả về thông báo dưới dạng JSON
    echo json_encode(['success' => $success, 'message' => $message]);
    return; // Đảm bảo không có gì khác được in ra
}
	public function getAuthtoken($email) {
		$code = md5(889966);
		$authtoken = $code."".md5($email);
		return $authtoken;
	}	
public function verifyRegister(){
		$verifyStatus = 0;
		if(!empty($_GET["authtoken"]) && $_GET["authtoken"] != '') {			
			$sqlQuery = "SELECT * FROM ".$this->userTable." 
				WHERE authtoken='".$_GET["authtoken"]."'";
			$resultSet = mysqli_query($this->dbConnect, $sqlQuery);
			$isValid = mysqli_num_rows($resultSet);	
			if($isValid){
				$userDetails = mysqli_fetch_assoc($resultSet);
				$authtoken = $this->getAuthtoken($userDetails['email']);
				if($authtoken == $_GET["authtoken"]) {					
					$updateQuery = "UPDATE ".$this->userTable." SET status = 'active'
						WHERE id='".$userDetails['id']."'";
					$isUpdated = mysqli_query($this->dbConnect, $updateQuery);					
					if($isUpdated) {
						$verifyStatus = 1;
					}
				}
			}
		}
		return $verifyStatus;
	}
public function userDetails () {
		$sqlQuery = "SELECT * FROM ".$this->userTable." 
			WHERE id ='".$_SESSION["userid"]."'";
		$result = mysqli_query($this->dbConnect, $sqlQuery);	
		$userDetails = mysqli_fetch_assoc($result);
		return $userDetails;
	}
public function editAccount () {
		$message = '';
		$updatePassword = '';
		if(!empty($_POST["passwd"]) && $_POST["passwd"] != '' && $_POST["passwd"] != $_POST["cpasswd"]) {
			$message = "Confirm passwords do not match.";
		} else if(!empty($_POST["passwd"]) && $_POST["passwd"] != '' && $_POST["passwd"] == $_POST["cpasswd"]) {
			$updatePassword = ", password='".md5($_POST["passwd"])."' ";
		}		
		$updateQuery = "UPDATE ".$this->userTable." 
			SET first_name = '".$_POST["firstname"]."', last_name = '".$_POST["lastname"]."', email = '".$_POST["email"]."', mobile = '".$_POST["mobile"]."' , designation = '".$_POST["designation"]."', gender = '".$_POST["gender"]."' $updatePassword
			WHERE id ='".$_SESSION["userid"]."'";
		$isUpdated = mysqli_query($this->dbConnect, $updateQuery);	
		if($isUpdated) {
			$_SESSION["name"] = $_POST['firstname']." ".$_POST['lastname'];
			$message = "Account details saved.";
		}
		return $message;
	}
public function resetPassword(){
		$message = '';
		if($_POST['email'] == '') {
			$message = "Please enter username or email to proceed with password reset";			
		} else {
			$sqlQuery = "
				SELECT email 
				FROM ".$this->userTable." 
				WHERE email='".$_POST['email']."'";			
			$result = mysqli_query($this->dbConnect, $sqlQuery);
			$numRows = mysqli_num_rows($result);
			if($numRows) {			
				$user = mysqli_fetch_assoc($result);
				$authtoken = $this->getAuthtoken($user['email']);
				$link="<a href='https://www.webdamn.com/demo/user-management-system/reset_password.php?authtoken=".$authtoken."'>Reset Password</a>";				
				$toEmail = $user['email'];
				$subject = "Reset your password on examplesite.com";
				$msg = "Hi there, click on this ".$link." to reset your password.";
				$msg = wordwrap($msg,70);
				$headers = "From: info@webdamn.com";
				if(mail($toEmail, $subject, $msg, $headers)) {
					$message =  "Password reset link send. Please check your mailbox to reset password.";
				}				
			} else {
				$message = "No account exist with entered email address.";
			}
		}
		return $message;
	}
public function savePassword(){
		$message = '';
		if($_POST['password'] != $_POST['cpassword']) {
			$message = "Password does not match the confirm password.";
		} else if($_POST['authtoken']) {
			$sqlQuery = "
				SELECT email, authtoken 
				FROM ".$this->userTable." 
				WHERE authtoken='".$_POST['authtoken']."'";			
			$result = mysqli_query($this->dbConnect, $sqlQuery);
			$numRows = mysqli_num_rows($result);
			if($numRows) {				
				$userDetails = mysqli_fetch_assoc($result);
				$authtoken = $this->getAuthtoken($userDetails['email']);
				if($authtoken == $_POST['authtoken']) {
					$sqlUpdate = "
						UPDATE ".$this->userTable." 
						SET password='".md5($_POST['password'])."'
						WHERE email='".$userDetails['email']."' AND authtoken='".$authtoken."'";	
					$isUpdated = mysqli_query($this->dbConnect, $sqlUpdate);	
					if($isUpdated) {
						$message = "Password saved successfully. Please <a href='login.php'>Login</a> to access account.";
					}
				} else {
					$message = "Invalid password change request.";
				}
			} else {
				$message = "Invalid password change request.";
			}	
		}
		return $message;
	}
	public function getUserList1() {
    // Xây dựng câu truy vấn để lấy danh sách người dùng
    $sqlQuery = "SELECT Id, Id_user, Tenwebsite, Link, View, Number_web FROM " . $this->userTable . " WHERE Id_user != '" . $_SESSION['userid'] . "' ";

    // Thêm điều kiện sắp xếp
    if (!empty($_POST["order"])) {
        $sqlQuery .= 'ORDER BY ' . $_POST['order']['0']['column'] . ' ' . $_POST['order']['0']['dir'] . ' ';
    } else {
        $sqlQuery .= 'ORDER BY Id DESC ';
    }

    // Thêm điều kiện giới hạn
    if ($_POST["length"] != -1) {
        $sqlQuery .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
    }

    // Thực hiện truy vấn
    $result = mysqli_query($this->dbConnect, $sqlQuery);

    // Truy vấn để đếm số lượng bản ghi
    $sqlQuery1 = "SELECT Id FROM " . $this->userTable . " WHERE Id_user != '" . $_SESSION['userid'] . "' ";
    $result1 = mysqli_query($this->dbConnect, $sqlQuery1);
    $numRows = mysqli_num_rows($result1);

    $userData = array();	
    while ($users = mysqli_fetch_assoc($result)) {
        $userRows = array();
        $userRows[] = $users['Id'];
        $userRows[] = $users['Id_user'];
        $userRows[] = $users['Tenwebsite'];
        $userRows[] = $users['Link'];
        $userRows[] = $users['View'];
        $userRows[] = $users['Number_web'];
        $userRows[] = '<button type="button" name="update" id="' . $users["Id"] . '" class="btn btn-warning btn-xs update">Update</button>';
        $userRows[] = '<button type="button" name="delete" id="' . $users["Id"] . '" class="btn btn-danger btn-xs delete">Delete</button>';
        $userData[] = $userRows;
    }

    // Tạo mảng đầu ra
    $output = array(
        "draw" => intval($_POST["draw"]),
        "recordsTotal" => $numRows,
        "recordsFiltered" => $numRows,
        "data" => $userData
    );

    // Trả về dữ liệu dưới dạng JSON
    echo json_encode($output);
}
	public function getUserList(){		
		$sqlQuery = "SELECT * FROM ".$this->userTable." WHERE id !='".$_SESSION['adminUserid']."' ";
		if(!empty($_POST["search"]["value"])){
			$sqlQuery .= '(id LIKE "%'.$_POST["search"]["value"].'%" ';
			$sqlQuery .= ' OR first_name LIKE "%'.$_POST["search"]["value"].'%" ';
			$sqlQuery .= ' OR last_name LIKE "%'.$_POST["search"]["value"].'%" ';
			$sqlQuery .= ' OR designation LIKE "%'.$_POST["search"]["value"].'%" ';
			$sqlQuery .= ' OR status LIKE "%'.$_POST["search"]["value"].'%" ';
			$sqlQuery .= ' OR mobile LIKE "%'.$_POST["search"]["value"].'%") ';			
		}
		if(!empty($_POST["order"])){
			$sqlQuery .= 'ORDER BY '.$_POST['order']['0']['column'].' '.$_POST['order']['0']['dir'].' ';
		} else {
			$sqlQuery .= 'ORDER BY id DESC ';
		}
		if($_POST["length"] != -1){
			$sqlQuery .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
		}	
		$result = mysqli_query($this->dbConnect, $sqlQuery);
		
		$sqlQuery1 = "SELECT * FROM ".$this->userTable." WHERE id !='".$_SESSION['adminUserid']."' ";
		$result1 = mysqli_query($this->dbConnect, $sqlQuery1);
		$numRows = mysqli_num_rows($result1);
		
		$userData = array();	
		while( $users = mysqli_fetch_assoc($result) ) {		
			$userRows = array();
			$status = '';
			if($users['status'] == 'active')	{
				$status = '<span class="label label-success">Active</span>';
			} else if($users['status'] == 'pending') {
				$status = '<span class="label label-warning">Inactive</span>';
			} else if($users['status'] == 'deleted') {
				$status = '<span class="label label-danger">Deleted</span>';
			}
			$userRows[] = $users['id'];
			$userRows[] = ucfirst($users['first_name']." ".$users['last_name']);
			$userRows[] = $users['gender'];			
			$userRows[] = $users['email'];	
			$userRows[] = $users['mobile'];	
			$userRows[] = $users['type'];
			$userRows[] = $status;						
			$userRows[] = '<button type="button" name="update" id="'.$users["id"].'" class="btn btn-warning btn-xs update">Update</button>';
			$userRows[] = '<button type="button" name="delete" id="'.$users["id"].'" class="btn btn-danger btn-xs delete" >Delete</button>';
			$userData[] = $userRows;
		}
		$output = array(
			"draw"				=>	intval($_POST["draw"]),
			"recordsTotal"  	=>  $numRows,
			"recordsFiltered" 	=> 	$numRows,
			"data"    			=> 	$userData
		);
		echo json_encode($output);
	}
public function deleteUser(){
		if($_POST["userid"]) {
			$sqlUpdate = "
				UPDATE ".$this->userTable." SET status = 'deleted'
				WHERE id = '".$_POST["userid"]."'";		
			mysqli_query($this->dbConnect, $sqlUpdate);		
		}
	}
	public function getUser(){
		$sqlQuery = "
			SELECT * FROM ".$this->userTable." 
			WHERE id = '".$_POST["userid"]."'";
		$result = mysqli_query($this->dbConnect, $sqlQuery);	
		$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
		echo json_encode($row);
	}
public function updateUser() {
		if($_POST['userid']) {	
			$updateQuery = "UPDATE ".$this->userTable." 
			SET first_name = '".$_POST["firstname"]."', last_name = '".$_POST["lastname"]."', email = '".$_POST["email"]."', mobile = '".$_POST["mobile"]."' , designation = '".$_POST["designation"]."', gender = '".$_POST["gender"]."', status = '".$_POST["status"]."', type = '".$_POST['user_type']."'
			WHERE id ='".$_POST["userid"]."'";
			$isUpdated = mysqli_query($this->dbConnect, $updateQuery);		
		}	
	}
public function updateLink($id, $tableName, $tenWebsite, $link, $view) {
    if ($id) {
        // Truyền các tham số đã được xác thực vào câu lệnh SQL
        $updateQuery = "UPDATE " . $tableName . " 
        SET Tenwebsite = '" . mysqli_real_escape_string($this->dbConnect, $tenWebsite) . "',
            Link = '" . mysqli_real_escape_string($this->dbConnect, $link) . "',
            View = " . intval($view) . " 
        WHERE Id = " . intval($id);

        $isUpdated = mysqli_query($this->dbConnect, $updateQuery);

        if ($isUpdated) {
            return true; // Cập nhật thành công
        } else {
            return false; // Cập nhật thất bại
        }
    }
    return false; // Nếu không có ID
}
	public function saveAdminPassword(){
		$message = '';
		if($_POST['password'] && $_POST['password'] != $_POST['cpassword']) {
			$message = "Password does not match the confirm password.";
		} else {			
			$sqlUpdate = "
				UPDATE ".$this->userTable." 
				SET password='".md5($_POST['password'])."'
				WHERE id='".$_SESSION['adminUserid']."' AND type='administrator'";	
			$isUpdated = mysqli_query($this->dbConnect, $sqlUpdate);	
			if($isUpdated) {
				$message = "Password saved successfully.";
			}				
		}
		return $message;
	}
	public function adminDetails () {
		$sqlQuery = "SELECT * FROM ".$this->userTable." 
			WHERE id ='".$_SESSION["adminUserid"]."'";
		$result = mysqli_query($this->dbConnect, $sqlQuery);	
		$userDetails = mysqli_fetch_assoc($result);
		return $userDetails;
	}

	public function addUser () {
		if($_POST["email"]) {
			$authtoken = $this->getAuthtoken($_POST['email']);
			$insertQuery = "INSERT INTO ".$this->userTable."(first_name, last_name, email, gender, password, mobile, designation, type, status, authtoken) 
				VALUES ('".$_POST["firstname"]."', '".$_POST["lastname"]."', '".$_POST["email"]."', '".$_POST["gender"]."', '".md5($_POST["password"])."', '".$_POST["mobile"]."', '".$_POST["designation"]."', '".$_POST['user_type']."', 'active', '".$authtoken."')";
			$userSaved = mysqli_query($this->dbConnect, $insertQuery);
		}
	}
public function totalUsers ($status) {
		$query = '';
		if($status) {
			$query = " AND status = '".$status."'";
		}
		$sqlQuery = "SELECT * FROM ".$this->userTable." 
		WHERE id !='".$_SESSION["adminUserid"]."' $query";
		$result = mysqli_query($this->dbConnect, $sqlQuery);
		$numRows = mysqli_num_rows($result);
		return $numRows;
	}
	function insertUser($id_form,$first_name, $last_name, $phone_mobile, $email,$password) {
		 if ($this->dbConnect1 === null) {
        return ['msg' => "Database connection is not established.", 'msgType' => "error"];
    }

    // SQL query to insert a new user
    $sql = "INSERT INTO `user` (`id_form`,`first_name`,`last_name`, `phone_mobile`, `email`,`authtoken`,`password`) VALUES (:id_form,:first_name, :last_name, :phone_mobile, :email,:authtoken,:password)"; 
    try {
        $stmt = $this->dbConnect->prepare($sql);
        $authtoken = $this->getAuthtoken($email);
        $stmt->bindValue(":id_form", $id_form);
        $stmt->bindValue(":first_name", $first_name);
        $stmt->bindValue(":last_name", $last_name);
        $stmt->bindValue(":phone_mobile", $phone_mobile);
        $stmt->bindValue(":email", $email);
        $stmt->bindValue(":authtoken", $authtoken);
        $stmt->bindValue(":password", $password);
        
		 // In ra câu lệnh SQL với các tham số đã được bind
        $debugSql = str_replace(
            [":id_form", ":first_name", ":last_name", ":phone_mobile", ":email", ":authtoken", ":password"],
            [$id_form, $first_name, $last_name, $phone_mobile, $email, $authtoken, $password],
            $sql
        );

        // In ra câu lệnh SQL
        echo "SQL: " . $debugSql; // Tạm thời in ra câu lệnh SQL

		
        // Execute the statement
        $stmt->execute();
        
        // Lấy ID của bản ghi vừa chèn
        //$lastId = $this->dbConnect->lastInsertId();
        
        // Trả về số lượng hàng bị ảnh hưởng và ID của bản ghi
        return [
            'rowCount' => $stmt->rowCount(),
             'lastInsertId' => $this->dbConnect->lastInsertId()
        ];
    } catch (Exception $e) {
        // Nếu có lỗi, trả về 0 cho rowCount và null cho lastInsertId
        return [
            'rowCount' => 0,
            'lastInsertId' => null,
            'error' => $e->getMessage() // Thêm thông tin lỗi nếu cần
        ];
    }
}

}	

   
  
// Sử dụng MySQLi
try {
    $user = new User('mysqli'); // Sử dụng lớp User
    $connection = $user->getMySQLiConnection(); // Lấy kết nối MySQLi
    // Bạn có thể thực hiện các truy vấn ở đây
} catch (Exception $e) {
    echo "Lỗi: " . $e->getMessage();
}

// Sử dụng PDO
try {
    $user1 = new User('pdo'); // Sử dụng lớp User
    $connection1 = $user1->getPDOConnection(); // Lấy kết nối PDO
    // Bạn có thể thực hiện các truy vấn ở đây
} catch (Exception $e) {
    echo "Lỗi: " . $e->getMessage();
}

 


function sendEmailVerification($last_name, $email, $lastID, $id_form) {
    $message = '<html><head>
                <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
                <title>Email kích hoạt đăng ký khóa học</title>
                </head>
                <body>';
    $message .= '<h1>Chào Bạn ' . htmlspecialchars($last_name) . '! đã đăng ký khóa học</h1>';
   $message .= '<p><a href="' . SITE_URL . 'activate.php?id=' . base64_encode($lastID) . '&id_danh_muc=' . base64_encode($id_form) . '&authtoken=' . $authtoken . '">Bạn nhấp vào đường link kích hoạt tài khoản đăng ký khóa học</a></p>'; $message .= "</body></html>";

    // Tạo đối tượng PHPMailer
    $mail = new PHPMailer(true);
    try {
        $mail->IsSMTP();
        $mail->SMTPDebug = 0;
        $mail->SMTPAuth = true;
        $mail->SMTPSecure = "ssl"; 
        $mail->Host = "smtp.mailgun.org"; 
        $mail->Port = 465; 
        $mail->Username = 'ssc@bizcrmweb.com';
        $mail->Password = '5f17a7d2a8bb33e4556be469e9fb0c79-24e2ac64-3787027b';
        
        $mail->SetFrom('ssc@bizcrmweb.com', 'daykembatnha.top');
        $mail->AddAddress($email);
        $mail->Subject = "Email Verification đăng ký khóa học";
        $mail->MsgHTML($message);

        // Gửi email
        $mail->send();
        return ["msg" => "An email has been sent for verification.", "msgType" => "success"];
    } catch (Exception $ex) {
        return ["msg" => $ex->getMessage(), "msgType" => "warning"];
    }
}

// Sử dụng hàm

		
		
	


	

?>