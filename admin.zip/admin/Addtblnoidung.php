<?php session_start(); ?>

<div class="container mt-5">
    <h2>Add Website</h2>
    <form id="frmNoidung" enctype="multipart/form-data">

        <div class="form-group">
            <label>ID Chương</label>
            <input type="number" class="form-control" id="id_chuong">
        </div>

        <div class="form-group">
            <label>Tên nội dung</label>
            <input type="text" class="form-control" id="ten_noidung">
        </div>

        <div class="form-group">
            <label>Type</label>
            <input type="text" class="form-control" id="type">
        </div>

        <div class="form-group">
            <label>Placeholder</label>
            <input type="text" class="form-control" id="placeholder">
        </div>

        <div class="form-group">
            <label>Namefunction</label>
            <input type="text" class="form-control" id="Namefunction">
        </div>

        <div class="form-group">
            <label>Folder</label>
            <input type="text" class="form-control" id="Folder">
        </div>

        <div class="form-group">
            <label>Link Video</label>
            <input type="text" class="form-control" id="Linkvideo">
        </div>

        <div class="form-group">
            <label>Hình ảnh</label>
            <input type="file" class="form-control" id="image" accept="image/*">
        </div>

        <div class="form-group">
            <label>Active</label>
            <select class="form-control" id="active">
                <option value="1">Hiển thị</option>
                <option value="0">Ẩn</option>
            </select>
        </div>

        <div class="form-group">
            <label>Mã xác nhận</label><br>
            <img src="random_image.php" id="captchaImg" style="cursor:pointer" title="Nhấn để đổi mã">
            <input type="text" class="form-control mt-2" id="txtCaptcha" placeholder="Nhập mã xác nhận">
        </div>

        <button type="button" class="btn btn-primary" id="AddNoidung">
            Thêm nội dung
        </button>

    </form>
</div>

<div id="message" class="container mt-3"></div>
<script>
$(document).ready(function () {

    // Nhấn vào ảnh captcha để load lại
    $('#captchaImg').on('click', function () {
        $(this).attr('src', 'random_image.php?t=' + new Date().getTime());
    });

    // Xử lý khi nhấn nút Thêm
    $('#AddNoidung').on('click', function () {

        var formData = new FormData();
        formData.append('id_chuong',   $('#id_chuong').val());
        formData.append('ten_noidung', $('#ten_noidung').val());
        formData.append('type',        $('#type').val());
        formData.append('placeholder', $('#placeholder').val());
        formData.append('Namefunction',$('#Namefunction').val());
        formData.append('Folder',      $('#Folder').val());
        formData.append('Linkvideo',   $('#Linkvideo').val());
        formData.append('active',      $('#active').val());
        formData.append('txtCaptcha',  $('#txtCaptcha').val());

        var imageFile = $('#image')[0].files[0];
        if (imageFile) {
            formData.append('image', imageFile);
        }

        $.ajax({
            type:        'POST',
            url:         'Add_tblnoidung.php',
            data:        formData,
            processData: false,
            contentType: false,
            dataType:    'json',
            success: function (response) {
                if (response.success) {
                    $('#message').html(
                        '<div class="alert alert-success">' + response.message + '</div>'
                    );
                    // Reset form sau khi thêm thành công
                    $('#frmNoidung')[0].reset();
                    // Đổi captcha mới
                    $('#captchaImg').attr('src', 'random_image.php?t=' + new Date().getTime());
                } else {
                    $('#message').html(
                        '<div class="alert alert-danger">' + response.message + '</div>'
                    );
                }
            },
            error: function (xhr) {
                $('#message').html(
                    '<div class="alert alert-danger">Đã xảy ra lỗi: ' + xhr.responseText + '</div>'
                );
            }
        });
    });

});
</script>