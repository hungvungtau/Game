<?php
header('Content-Type: application/json'); // Đặt tiêu đề cho phản hồi JSON

include('class/UserLink.php');
$user = new User1();

// register1.php
// Lấy dữ liệu từ POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if($_POST['txtCaptcha'] == NULL)
	{
		//echo "Please enter your code";
		$response['message'] .= "Please enter your code ";
	}
	else
	{
	if($_POST['txtCaptcha'] == $_SESSION['security_code'])
	{
		$Id = $_POST['userId']; // Sử dụng ID người dùng từ session
        $link = $_POST['link'];
		$category = $_POST['category'];
        $Namelink = $_POST['Namelink'];//
		$idweb=1;
		
					//echo "ma lenh hop le";
		 // Gọi hàm addWebsite và kiểm tra kết quả
        $insertResult = $user->insertlink($category,$idweb,$link,$Namelink);
       
		
			// Khởi tạo phản hồi
			$response = [];

			if (isset($insertResult['rowCount']) && $insertResult['rowCount'] > 0) {
				$response['success'] =$insertResult['success'];
				$response['message'] = $insertResult['message'];
			} else {
				/*if (isset($insertResult['error'])) {
					$response['message'] = " Error: " . $insertResult['error'];
				}*/
			}
		}
		else
		{
			$response['message'] = "Error:Invalid code ";
		}
	}
	
	// Trả về dữ liệu dưới dạng JSON
			echo json_encode($response);
			exit; // Đảm bảo không có thêm thông tin nào được in 
				
}
?>