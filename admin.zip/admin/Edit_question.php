<?php 
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
// update_question.php - Updates a question record
//session_start();
include('class/UserLink.php');

// Check if user is logged in
if (!isset($_SESSION['userid'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

// Check if required fields are provided
if (!isset($_POST['Id']) || empty($_POST['Id']) ||
    !isset($_POST['Id_Categories']) || 
    !isset($_POST['Namequestion']) ||
    !isset($_POST['Question']) ||
    !isset($_POST['Type']) ||
    !isset($_POST['answer1']) ||
    !isset($_POST['answer2']) ||
    !isset($_POST['answer3']) ||
    !isset($_POST['answer4']) ||
    !isset($_POST['Correct_answer'])) {
    echo json_encode(['success' => false, 'message' => 'All required fields must be provided']);
    exit;
}

// Get form data with proper sanitization
$questionId = intval($_POST['Id']);
$categoryId = intval($_POST['Id_Categories']);
$namequestion = trim($_POST['Namequestion']);
$images = isset($_POST['Images']) ? trim($_POST['Images']) : '';
$question = trim($_POST['Question']);
$type = trim($_POST['Type']);
$answer1 = trim($_POST['answer1']);
$answer2 = trim($_POST['answer2']);
$answer3 = trim($_POST['answer3']);
$answer4 = trim($_POST['answer4']);
$correct_answer = trim($_POST['Correct_answer']);

$user = new User1();

// Update question data
try {
    $result = $user->updateQuestion(
        $questionId, 
        $categoryId, 
        $namequestion, 
        $images, 
        $question, 
        $type, 
        $answer1, 
        $answer2, 
        $answer3, 
        $answer4, 
        $correct_answer
    );
    
    if ($result['success']) {
        echo json_encode(['success' => true, 'message' => 'Question updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => $result['message']]);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error updating question: ' . $e->getMessage()]);
}
?>