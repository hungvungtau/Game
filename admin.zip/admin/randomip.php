<?php
class NetworkManager {
    private $ethIP = '';
    private $ethDns = '';
    private $ethName = '';

    private $wifiIP = '';
    private $wifiDns = '';
    private $wifiName = '';

    private $newIps = [];
    private $stepNewIp = 0;

    public function getWifiInfo() {
        // Logic để lấy thông tin WiFi
        $interfaces = $this->getNetworkInterfaces();
        foreach ($interfaces as $ni) {
            if ($ni['type'] == 'Wireless') {
                $this->wifiName = $ni['name'];
                $this->wifiIP = $ni['ip'];
                $this->wifiDns = $ni['dns'];
                break;
            }
        }
    }

    public function getEthernetInfo() {
        // Logic để lấy thông tin Ethernet
        $interfaces = $this->getNetworkInterfaces();
        foreach ($interfaces as $ni) {
            if ($ni['type'] == 'Ethernet') {
                $this->ethName = $ni['name'];
                $this->ethIP = $ni['ip'];
                $this->ethDns = $ni['dns'];
                break;
            }
        }
    }

    private function getNetworkInterfaces() {
        // Logic để lấy thông tin mạng (cần sử dụng thư viện hoặc lệnh hệ thống)
        // Trả về danh sách các giao diện mạng với tên, IP, DNS và loại
        // Ví dụ trả về (cần thay thế bằng logic thực tế):
        return [
            ['name' => 'Ethernet', 'ip' => '192.168.1.10', 'dns' => '8.8.8.8', 'type' => 'Ethernet'],
            ['name' => 'WiFi', 'ip' => '192.168.1.11', 'dns' => '8.8.4.4', 'type' => 'Wireless'],
        ];
    }

    public function getNewIP($ip, $dns) {
        $dsIP = [];
        $ipParts = explode('.', $ip);
        $ipBase = implode('.', array_slice($ipParts, 0, -1)) . '.';
        $dnsLastOctet = (int)explode('.', $dns)[3];

        for ($i = $dnsLastOctet + 1; $i <= 254; $i++) {
            $newIp = $ipBase . $i;
            if ($newIp !== $dns && $newIp !== $ip) {
                $dsIP[] = $newIp;
            }
        }
        return $dsIP;
    }

    public function randomIP() {
        $this->getEthernetInfo();
        $this->getWifiInfo();

        if ($this->ethIP) {
            $this->newIps = $this->getNewIP($this->ethIP, $this->ethDns);
        } else {
            $this->newIps = $this->getNewIP($this->wifiIP, $this->wifiDns);
        }

        if (!empty($this->newIps)) {
            // Chọn một IP ngẫu nhiên từ danh sách
            $randomKey = array_rand($this->newIps);
            $newIp = $this->newIps[$randomKey];
            if ($this->ethIP) {
                $this->setStaticIP($this->ethName, $newIp, $this->ethDns);
            } else {
                $this->setStaticIP($this->wifiName, $newIp, $this->wifiDns);
            }
        } else {
            echo "Không tìm thấy IP mới khả dụng.";
        }
    }

    public function setStaticIP($interface, $ip, $dns) {
        $subnet = '255.255.255.0';
        $command = "netsh interface ip set address \"$interface\" static $ip $subnet $dns";
        $command .= " & netsh interface ip set dns \"$interface\" static $dns";

        $this->executeCommand($command);
    }

    private function executeCommand($command) {
        // Chạy lệnh hệ thống
        $output = [];
        $returnVar = 0;
        exec("cmd.exe /c $command", $output, $returnVar);

        if ($returnVar !== 0) {
            // Xử lý lỗi nếu cần
            echo "Error executing command: " . implode("\n", $output);
        }
    }

    public function setNewIP() {
        $this->stepNewIp++;
        if ($this->stepNewIp >= count($this->newIps)) {
            $this->stepNewIp = 0;
        }

        if ($this->ethIP) {
            $newIp = $this->newIps[$this->stepNewIp];
            $this->setStaticIP($this->ethName, $newIp, $this->ethDns);
        } else {
            $newIp = $this->newIps[$this->stepNewIp];
            $this->setStaticIP($this->wifiName, $newIp, $this->wifiDns);
        }
    }
}

// Ví dụ sử dụng
$networkManager = new NetworkManager();
$networkManager->randomIP(); // Gọi hàm để thực hiện thiết lập IP ngẫu nhiên
?>