<?php
include('class/User.php');
//session_start();
$user = new User();
$categories = $user->getcategory('categories',false);
?>
  <style>
  /* ===== POPUP TOÁN HỌC FLOATING ===== */
.math-popup {
    position: fixed;
    top: 80px;
    right: 10px;
    width: 300px;
    max-height: 80vh;
    overflow-y: auto;
    background: #ffffff;
    border: 1px solid #ccc;
    border-radius: 10px;
    box-shadow: 0 10px 25px rgba(0,0,0,.2);
    z-index: 9999;
    display: none;
}

.math-popup h4 {
    margin: 10px 0 5px;
    font-size: 15px;
}

.math-popup .special-buttons button {
    margin: 3px;
    padding: 5px 8px;
    font-size: 14px;
}

/* Nút mở popup */
.open-math-btn {
    position: fixed;
    right: 10px;
    bottom: 20px;
    background: #2563eb;
    color: #fff;
    border: none;
    padding: 10px 14px;
    border-radius: 30px;
    cursor: pointer;
    z-index: 9999;
}
        .form-group {
            margin: 20px;
        }
        .special-buttons {
            margin-top: 5px;
            margin-bottom: 5px;
        }
        .special-buttons button {
            margin-right: 5px;
            padding: 5px 10px;
            background-color: #f0f0f0;
            border: 1px solid #ccc;
            border-radius: 3px;
            cursor: pointer;
        }
        .special-buttons button:hover {
            background-color: #e0e0e0;
        }
		.math-section {
    border: 1px solid #ccc;
    border-radius: 8px;
    padding: 10px;
    margin: 15px 0;
    background-color: #fafafa;
}
.math-section h4 {
    margin-bottom: 10px;
    font-weight: bold;
}
    </style>    
<div class="container mt-5">
    <h2>Add Website</h2>
    <form id="addWebsiteForm" method="post" action="#">
       <div class="form-group">
		<label for="Namecategory">Name Category:</label>
		<select class="form-control" id="Namecategory" required>
			<option value="">-- Chọn danh mục --</option>
			<?php foreach ($categories as $category): ?>
				<option value="<?php echo $category['Id']; ?>">
					<?php echo htmlspecialchars($category['Category_name']); ?>
				</option>
			<?php endforeach; ?>
		</select>
</div> 
      
		<div class="form-group">
            <label for="NameQuestion"> Name Question:</label>
            <input type="text" class="form-control" id="Namequestion">
			<button type="button" id="pasteButton">Dán</button>
            <div class="special-buttons">
                <button type="button" class="insert-special" data-target="Namequestion" data-type="fraction">Phân số</button>
                <button type="button" class="insert-special" data-target="Namequestion" data-type="degree">Độ</button>
                <button type="button" class="insert-special" data-target="Namequestion" data-type="mixed">Hỗn số</button>
            </div>
        </div>
		<div class="form-group">
            <label for="ImageWebsite">Image Your Website:</label>
            <input type="file" class="form-control" id="Image" name="Image">
        </div>
<div class="form-group">
    <label for="options">Chọn Lựa Chọn:</label>
    <select id="options">
        <option value="">-- Chọn --</option>
        <option value="multiple">Nhiều Lựa Chọn</option>
		 <option value="multiple1">Nhiều Lựa Chọn có hình</option>
        <option value="truefalse">True/False</option>
        <option value="single">Một Lựa Chọn</option>
    </select>
</div>
<script>
 $(document).ready(function() {
	 // --- Chèn ký hiệu vào ô đang focus ---
let activeInput = null;

// Khi người dùng focus vào ô nhập
$(document).on('focus', 'input[type="text"]', function() {
    activeInput = this;
});

// Khi bấm nút trong khối biểu thức
$(document).on('click', '.math-section button', function() {
    if (!activeInput) return;
    const symbol = $(this).text();
    const $target = $(activeInput);
    const cursorPos = $target.prop('selectionStart');
    const v = $target.val();
    const textBefore = v.substring(0, cursorPos);
    const textAfter = v.substring(cursorPos, v.length);
    $target.val(textBefore + symbol + textAfter);
    $target.focus();
    $target.prop('selectionStart', cursorPos + symbol.length);
    $target.prop('selectionEnd', cursorPos + symbol.length);
});
            $('#pasteButton').on('click', function() {
                navigator.clipboard.readText().then(function(text) {
                    $('#Namequestion').val(text);
                }).catch(function(err) {
                    console.error('Lỗi khi dán:', err);
                });
            });

            // Thêm một listener cho sự kiện "paste" để hỗ trợ dán bằng phím tắt
            $('#Namequestion').on('paste', function(event) {
                event.preventDefault();
                var clipboardData = event.originalEvent.clipboardData || window.clipboardData;
                var pastedData = clipboardData.getData('Text');
                $(this).val(pastedData);
            });
            
            // Xử lý chèn phân số, độ, hỗn số
            $('.insert-special').on('click', function() {
                var targetId = $(this).data('target');
                var type = $(this).data('type');
                
                var $target = $('#' + targetId);
                var cursorPos = $target.prop('selectionStart');
                var v = $target.val();
                var textBefore = v.substring(0, cursorPos);
                var textAfter = v.substring(cursorPos, v.length);
                
                var insertText = '';
                
                if (type === 'fraction') {
                    insertText = '½'; // Có thể thay bằng mã HTML hoặc Unicode khác
                } else if (type === 'degree') {
                    insertText = '°';
                } else if (type === 'mixed') {
                    insertText = '1½'; // Có thể thay bằng mã HTML hoặc Unicode khác
                }
                
                $target.val(textBefore + insertText + textAfter);
                $target.focus();
                $target.prop('selectionStart', cursorPos + insertText.length);
                $target.prop('selectionEnd', cursorPos + insertText.length);
            });
        });
$(document).ready(function() {
    $('#options').change(function() {
        var selectedValue = $(this).val();
        $('#inputFields').empty(); // Xóa các trường cũ

     if (selectedValue === 'multiple1') {
    for (var i = 0; i < 4; i++) {

        var inputGroup = $('<div class="input-group mb-3"></div>');

        // Ô nhập text
        inputGroup.append(
            '<input type="text" name="answers[]" id="answer_m1_' + i +
            '" placeholder="Nhập đáp án ' + (i + 1) +
            '" class="form-control" />'
        );

        // Khu nút đặc biệt
        var specialButtons = $('<div class="input-group-append special-buttons"></div>');
        specialButtons.append('<button type="button" class="insert-special" data-target="answer_m1_' + i + '" data-type="fraction">Phân số</button>');
        specialButtons.append('<button type="button" class="insert-special" data-target="answer_m1_' + i + '" data-type="degree">Độ</button>');
        specialButtons.append('<button type="button" class="insert-special" data-target="answer_m1_' + i + '" data-type="mixed">Hỗn số</button>');

        // Nút thêm hình (version hỗ trợ upload tự động)
        specialButtons.append(
            '<label class="btn btn-secondary btn-sm ml-2">🖼 Chọn hình' +
            '<input type="file" class="image-upload" data-target="answer_m1_' + i +
            '" name="image_m1_' + i + '" accept="image/*" hidden>' +
            '</label>'
        );

        inputGroup.append(specialButtons);
        $('#inputFields').append(inputGroup);
    }
}

        else if (selectedValue === 'multiple') {
            // Tạo nhiều ô textbox cho nhiều lựa chọn
            for (var i = 0; i < 4; i++) { // Ví dụ: 4 ô textbox
                var inputGroup = $('<div class="input-group mb-3"></div>');
                inputGroup.append('<input type="text" name="answers[]" id="answer_' + i + '" placeholder="Nhập đáp án ' + (i + 1) + '" class="form-control" />');
                
                var specialButtons = $('<div class="input-group-append special-buttons"></div>');
                specialButtons.append('<button type="button" class="insert-special" data-target="answer_' + i + '" data-type="fraction">Phân số</button>');
                specialButtons.append('<button type="button" class="insert-special" data-target="answer_' + i + '" data-type="degree">Độ</button>');
                specialButtons.append('<button type="button" class="insert-special" data-target="answer_' + i + '" data-type="mixed">Hỗn số</button>');
                
                inputGroup.append(specialButtons);
                $('#inputFields').append(inputGroup);
            }
        } else if (selectedValue === 'truefalse') {
            // Tạo 2 ô textbox cho True/False
            for (var i = 0; i < 2; i++) {
                var placeholder = i === 0 ? "True" : "False";
                var inputGroup = $('<div class="input-group mb-3"></div>');
                inputGroup.append('<input type="text" name="answers[]" id="answer_tf_' + i + '" placeholder="' + placeholder + '" class="form-control" />');
                
                var specialButtons = $('<div class="input-group-append special-buttons"></div>');
                specialButtons.append('<button type="button" class="insert-special" data-target="answer_tf_' + i + '" data-type="fraction">Phân số</button>');
                specialButtons.append('<button type="button" class="insert-special" data-target="answer_tf_' + i + '" data-type="degree">Độ</button>');
                specialButtons.append('<button type="button" class="insert-special" data-target="answer_tf_' + i + '" data-type="mixed">Hỗn số</button>');
                
                inputGroup.append(specialButtons);
                $('#inputFields').append(inputGroup);
            }
        } else if (selectedValue === 'single') {
            // Tạo nhiều ô textbox cho một lựa chọn
            for (var j = 0; j < 4; j++) {
                var inputGroup = $('<div class="input-group mb-3"></div>');
                inputGroup.append('<input type="text" name="answers[]" id="answer_single_' + j + '" placeholder="Nhập đáp án ' + (j + 1) + '" class="form-control" />');
                
                var specialButtons = $('<div class="input-group-append special-buttons"></div>');
                specialButtons.append('<button type="button" class="insert-special" data-target="answer_single_' + j + '" data-type="fraction">Phân số</button>');
                specialButtons.append('<button type="button" class="insert-special" data-target="answer_single_' + j + '" data-type="degree">Độ</button>');
                specialButtons.append('<button type="button" class="insert-special" data-target="answer_single_' + j + '" data-type="mixed">Hỗn số</button>');
                
                inputGroup.append(specialButtons);
                $('#inputFields').append(inputGroup);
            }
        }
        
        // Kích hoạt lại sự kiện cho các nút đặc biệt mới được tạo
        $('.insert-special').off('click').on('click', function() {
            var targetId = $(this).data('target');
            var type = $(this).data('type');
            
            var $target = $('#' + targetId);
            var cursorPos = $target.prop('selectionStart');
            var v = $target.val();
            var textBefore = v.substring(0, cursorPos);
            var textAfter = v.substring(cursorPos, v.length);
            
            var insertText = '';
            
            if (type === 'fraction') {
                insertText = '½'; // Có thể thay bằng mã HTML hoặc Unicode khác
            } else if (type === 'degree') {
                insertText = '°';
            } else if (type === 'mixed') {
                insertText = '1½'; // Có thể thay bằng mã HTML hoặc Unicode khác
            }
            
            $target.val(textBefore + insertText + textAfter);
            $target.focus();
            $target.prop('selectionStart', cursorPos + insertText.length);
            $target.prop('selectionEnd', cursorPos + insertText.length);
        });
    });
});
$(document).on('change', '.image-upload', function () {

    var file = this.files[0];
    var targetTextbox = $(this).data('target');

    if (!file) return;

    var formData = new FormData();
    formData.append('image', file);

    fetch('upload.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.text())
    .then(filename => {
        $('#' + targetTextbox).val(filename); // chèn tên file vào textbox
    });
});
</script>
<div id="inputFields"></div>
<!-- 🔢 KHỐI BIỂU THỨC TOÁN HỌC -->
<div class="math-section">
    <h4>🔢 Số mũ & Căn</h4>
    <div class="special-buttons">
        <button> x² </button><button> x³ </button><button> xⁿ </button><button> 2^x </button><button> e^x </button>
        <button> √x </button><button> ∛x </button><button> ⁿ√x </button>
    </div>
	
	<div class="toolbar">
            <!-- Số mũ và căn -->
            <div class="section-title">🔢 Số mũ và Căn</div>
            <button type="button" onclick="insertTemplate('x²')">x²</button>
            <button type="button" onclick="insertTemplate('x³')">x³</button>
            <button type="button" onclick="insertTemplate('x^n')">x^n</button>
            <button type="button" onclick="insertTemplate('2^x')">2^x</button>
            <button type="button" onclick="insertTemplate('e^x')">e^x</button>
            <button type="button" onclick="insertTemplate('√x')">√x</button>
            <button type="button" onclick="insertTemplate('∛x')">∛x</button>
            <button type="button" onclick="insertTemplate('ⁿ√x')">ⁿ√x</button>

            <!-- So sánh -->
            <div class="section-title">⚖️ So sánh</div>
            <button type="button" onclick="insertTemplate(' > ')">(>) Lớn hơn</button>
            <button type="button" onclick="insertTemplate(' < ')"(<) Nhỏ hơn</button>
            <button type="button" onclick="insertTemplate(' ≥ ')">(≥) Lớn hơn bằng</button>
            <button type="button" onclick="insertTemplate(' ≤ ')">(≤) Nhỏ hơn bằng</button>
            <button type="button" onclick="insertTemplate(' ≠ ')">(≠) Khác</button>
            <button type="button" onclick="insertTemplate(' ≈ ')">(≈) Xấp xỉ</button>

            <!-- Tập hợp -->
            <div class="section-title">🗂️ Tập hợp</div>
            <button type="button" onclick="insertTemplate(' ∈ ')">(∈) Thuộc</button>
            <button type="button" onclick="insertTemplate(' ∉ ')">(∉) Không thuộc</button>
            <button type="button" onclick="insertTemplate(' ⊂ ')">(⊂) Tập con</button>
            <button type="button" onclick="insertTemplate(' ∪ ')">(∪) Hợp</button>
            <button type="button" onclick="insertTemplate(' ∩ ')">(∩) Giao</button>
            <button type="button" onclick="insertTemplate(' ∅ ')">(∅) Tập rỗng</button>
            <button type="button" onclick="insertTemplate('{}')">{} Tập hợp</button>
            <button type="button" onclick="insertTemplate('[a, b]')">[a, b] Đoạn</button>

            <!-- Ký hiệu đặc biệt -->
            <div class="section-title">🔤 Ký hiệu đặc biệt</div>
            <button type="button" onclick="insertTemplate('π')">π (Pi)</button>
            <button type="button" onclick="insertTemplate('∞')">(∞) Vô cực</button>
            <button type="button" onclick="insertTemplate('Δ')">(Δ) Delta</button>
            <button type="button" onclick="insertTemplate('α')">(α) Alpha</button>
            <button type="button" onclick="insertTemplate('β')">(β) Beta</button>
            <button type="button" onclick="insertTemplate('γ')">(γ) Gamma</button>
            <button type="button" onclick="insertTemplate('θ')">(θ) Theta</button>
            <button type="button" onclick="insertTemplate('λ')">(λ) Lambda</button>

            <!-- Tích phân và đạo hàm -->
            <div class="section-title">🧮 Tích phân & Đạo hàm</div>
            <button type="button" onclick="insertTemplate('∫')">∫ Tích phân</button>
            <button type="button" onclick="insertTemplate('∬')">∬ Tích phân kép</button>
            <button type="button" onclick="insertTemplate('∭')">∭ Tích phân ba</button>
            <button type="button" onclick="insertTemplate('∮')">∮ Tích phân đường</button>
            <button type="button" onclick="insertTemplate('d/dx')">d/dx</button>
            <button type="button" onclick="insertTemplate('∂/∂x')">∂/∂x</button>
            <button type="button" onclick="insertTemplate('lim')">lim</button>
            <button type="button" onclick="insertTemplate('Σ')">Σ (Tổng)</button>

            <!-- Xác suất và thống kê -->
            <div class="section-title">📊 Xác suất & Thống kê</div>
            <button type="button" onclick="insertTemplate('P(A)')">P(A)</button>
            <button type="button" onclick="insertTemplate('P(A|B)')">P(A|B)</button>
            <button type="button" onclick="insertTemplate('μ')">(μ) Trung bình</button>
            <button type="button" onclick="insertTemplate('σ')">(σ) Độ lệch chuẩn</button>
            <button type="button" onclick="insertTemplate('σ²')">(σ²) Phương sai</button>
            <button type="button" onclick="insertTemplate('n!')">(n!) Giai thừa</button>
            <button type="button" onclick="insertTemplate('C(n,k)')">C(n,k)</button>
            <button type="button" onclick="insertTemplate('A(n,k)')">A(n,k)</button>
        </div>
				<!-- Hình học -->
		<div class="section-title">📐 Hình học</div>

		<!-- Góc -->
		<button type="button" onclick="insertTemplate('∠ABC')">∠ Góc</button>
		<button type="button" onclick="insertTemplate('∡ABC')">∡ Góc định hướng</button>

		<!-- Tam giác -->
		<button type="button" onclick="insertTemplate('△ABC')">△ Tam giác</button>
		<button type="button" onclick="insertTemplate('≅')">≅ Bằng nhau</button>
		<button type="button" onclick="insertTemplate('≡')">≡ Trùng nhau</button>

		<!-- Đoạn thẳng & Quan hệ -->
		<button type="button" onclick="insertTemplate('AB̅')">AB̅ Đoạn thẳng</button>
		<button type="button" onclick="insertTemplate('AB⃡')">AB⃡ Đường thẳng</button>
		<button type="button" onclick="insertTemplate('AB⃥')">AB⃥ Tia</button>
		<button type="button" onclick="insertTemplate('∥')">∥ Song song</button>
		<button type="button" onclick="insertTemplate('⟂')">⟂ Vuông góc</button>

		<!-- Quan hệ góc -->
		<button type="button" onclick="insertTemplate('∠A = ∠B')">∠A = ∠B</button>
		<button type="button" onclick="insertTemplate('∠A + ∠B = 180°')">Góc bù</button>
		<button type="button" onclick="insertTemplate('∠A + ∠B = 90°')">Góc phụ</button>

		<!-- Đường tròn -->
		<button type="button" onclick="insertTemplate('⊙O')">⊙ Đường tròn</button>
		<button type="button" onclick="insertTemplate('⧠ABCD')">⧠ Hình chữ nhật</button>
		<button type="button" onclick="insertTemplate('□ABCD')">□ Hình vuông</button>
		<button type="button" onclick="insertTemplate('⟂ (AB, CD)')">Vuông góc 2 đường</button>
		<button type="button" onclick="insertTemplate('R')">R Bán kính</button>
		<button type="button" onclick="insertTemplate('d(O,AB)')">d(O,AB) Khoảng cách</button>

		<!-- Vector -->
		<button type="button" onclick="insertTemplate('→AB')">→AB Vector</button>
		<button type="button" onclick="insertTemplate('→a')">→a Vector đơn</button>
		<button type="button" onclick="insertTemplate('|→a|')">|→a| Độ dài vector</button>

		<!-- Góc độ -->
		<button type="button" onclick="insertTemplate('°')">° Độ</button>
		<button type="button" onclick="insertTemplate('rad')">rad Radian</button>

		</div>
        <div style="text-align: center;">
            <button class="clear-btn" onclick="clearText()">🗑️ Xóa tất cả</button>
        </div>

	
	
	
	

    <h4>⚖️ So sánh</h4>
    <div class="special-buttons">
        <button> > </button><button> ≥ </button><button> ≤ </button><button> ≠ </button><button> ≈ </button>
    </div>

    <h4>🗂️ Tập hợp</h4>
    <div class="special-buttons">
        <button> ∈ </button><button> ∉ </button><button> ⊂ </button><button> ∪ </button><button> ∩ </button><button> ∅ </button>
        <button> {} </button><button> [a,b] </button>
    </div>

    <h4>🔤 Ký hiệu đặc biệt</h4>
    <div class="special-buttons">
        <button> π </button><button> ∞ </button><button> Δ </button><button> α </button><button> β </button>
        <button> γ </button><button> θ </button><button> λ </button>
    </div>

    <h4>🧮 Tích phân & Đạo hàm</h4>
    <div class="special-buttons">
        <button> ∫ </button><button> ∬ </button><button> ∭ </button><button> ∮ </button><button> d/dx </button>
        <button> ∂/∂x </button><button> lim </button><button> Σ </button>
    </div>

    <h4>📊 Xác suất & Thống kê</h4>
    <div class="special-buttons">
        <button> P(A) </button><button> P(A|B) </button><button> μ </button><button> σ </button><button> σ² </button>
        <button> n! </button><button> C(n,k) </button><button> A(n,k) </button>
    </div>
</div>
<!-- HẾT KHỐI BIỂU THỨC -->
<div class="form-group">
    <label for="NameQuestion"> CorrectAnswer:</label>
    <input type="text" id="Correctanswer" placeholder="Nhập đáp án đúng" class="form-control" />
    <div class="special-buttons">
        <button type="button" class="insert-special" data-target="Correctanswer" data-type="fraction">Phân số</button>
        <button type="button" class="insert-special" data-target="Correctanswer" data-type="degree">Độ</button>
        <button type="button" class="insert-special" data-target="Correctanswer" data-type="mixed">Hỗn số</button>
    </div>
</div>
 
		 <div class="form-group">
           <label for="password" class="col-md-3 control-label">Captcha*</label>
			<div class="col-md-9">
				<input type="text" name="txtCaptcha" class="form-control" id="txtCaptcha" placeholder="txtCaptcha"  maxlength="10" size="32" />
		</div>
		</div>	
		<div class="form-group">
						
						<div class="col-md-9">
							<img src="random_image.php" />
						</div>	
		</div>	
        <button type="submit" class="btn btn-primary" id="Addquestion">Add question</button>
    </form>
</div>
<div id="message"></div>
<div id="addWebsiteForm1"></div> 
<script>
  // Tạo đối tượng FormData
$(document).ready(function() {
    $('#addWebsiteForm').on('submit', function(e) {
        e.preventDefault(); // Ngăn chặn hành vi mặc định của nút
        var formData = new FormData(this);
        
        // Lấy giá trị từ các trường input
        var Namecategory = $('#Namecategory').val();
        var Namequestion = $('#Namequestion').val();
        var Correctanswer = $('#Correctanswer').val();
        var Type = $('#options').val();
        var userId = <?php echo json_encode($_SESSION['userid']); ?>;
        var txtCaptcha = $('#txtCaptcha').val();
        
        var answers = $('input[name="answers[]"]').map(function() {
            return $(this).val(); // Lấy giá trị từ các ô nhập liệu
        }).get();
        
        // Thêm các giá trị answers vào FormData
        answers.forEach(function(answer) {
            formData.append('answers[]', answer); // Thêm vào FormData
        });
        
        // Thêm các giá trị cần thiết vào FormData
        formData.append('Namecategory', Namecategory);
        formData.append('Namequestion', Namequestion);
        formData.append('Correctanswer', Correctanswer);
        formData.append('Type', Type); // Sửa nơi cần thêm
        formData.append('userId', userId); // Sửa nơi cần thêm
        formData.append('txtCaptcha', txtCaptcha);
        
        // Gửi dữ liệu qua AJAX
        $.ajax({
            type: 'POST',
            url: 'Add_question.php', 
            data: formData,
            contentType: false, // Không thiết lập loại nội dung
            processData: false, // Không xử lý dữ liệu
            dataType: 'json', // Dự kiến dữ liệu trả về là JSON
            success: function(response) {
                if (response.message) {
                    $('#message').html(response.message);
                } else {
                    $('#message').html("Không có câu lệnh SQL nào để hiển thị.");
                }
            },
            error: function(xhr, status, error) {
                $('#message').html("Đã xảy ra lỗi: " + xhr.responseText); // Hiển thị thông báo lỗi
            }
        });
    });
});
$(function () {

    // Lưu input đang focus
    let activeInput = null;

    $(document).on('focus', 'input[type="text"]', function () {
        activeInput = this;
    });

    // Click nút popup → chèn ký hiệu
    $(document).on('click', '#mathPopup button', function () {
        if (!activeInput) return;

        const symbol = $(this).text();
        const $target = $(activeInput);

        const pos = $target.prop('selectionStart');
        const val = $target.val();

        $target.val(
            val.substring(0, pos) +
            symbol +
            val.substring(pos)
        );

        $target.focus();
        $target.prop('selectionStart', pos + symbol.length);
        $target.prop('selectionEnd', pos + symbol.length);
    });

    // Bật / tắt popup
    $('#toggleMath').on('click', function () {
        $('#mathPopup').toggle();
    });

});

</script>
<button class="open-math-btn" id="toggleMath">📐 Công thức</button>

<div class="math-popup" id="mathPopup">
    <h4>🔢 Số mũ & Căn</h4>
    <div class="special-buttons">
        <button>x²</button><button>x³</button><button>xⁿ</button>
        <button>√x</button><button>∛x</button>
    </div>

    <h4>⚖️ So sánh</h4>
    <div class="special-buttons">
        <button>></button><button>≥</button><button>≤</button>
        <button>≠</button><button>≈</button>
    </div>

    <h4>🗂️ Tập hợp</h4>
    <div class="special-buttons">
        <button>∈</button><button>∉</button><button>⊂</button>
        <button>∪</button><button>∩</button><button>∅</button>
    </div>

    <h4>📐 Hình học</h4>
    <div class="special-buttons">
        <button>△ABC</button><button>∠ABC</button>
        <button>⟂</button><button>∥</button>
    </div>

    <h4>🧮 Giải tích</h4>
    <div class="special-buttons">
        <button>∫</button><button>Σ</button><button>d/dx</button>
    </div>
</div>