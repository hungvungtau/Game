<?php
//including the database connection file
include_once("config.php");

//fetching data in descending order (lastest entry first)
//$result = mysql_query("SELECT * FROM users ORDER BY id DESC"); // mysql_query is deprecated
?>

<html>
<head>	
	<!-- HTML Meta Tags -->
<title>Học kèm tin học văn phòng Bà Rịa Châu Đức Tphcm</title>
<meta name="description" content="Học kèm tin học văn phòng Bà Rịa Châu Đức Tphcm">
 
<!-- Google / Search Engine Tags -->
<meta itemprop="name" content="Học kèm tin học văn phòng Bà Rịa Châu Đức Tphcm">
<meta itemprop="description" content="Học kèm tin học văn phòng Bà Rịa Châu Đức Tphcm">
<meta itemprop="image" content="http://daykembatnha.top/">
 
<!-- Facebook Meta Tags -->
<meta property="og:url" content="http://daykembatnha.top/">
<meta property="og:type" content="Học kèm tin học văn phòng Bà Rịa Châu Đức Tphcm">
<meta property="og:title" content="Học kèm tin học văn phòng Bà Rịa Châu Đức Tphcm">
<meta property="og:description" content="Học kèm tin học văn phòng Bà Rịa Châu Đức Tphcm">
<meta property="og:image" content="http://daykembatnha.top/">
 
<!-- Twitter Meta Tags -->
<meta name="twitter:card" content="Học kèm tin học văn phòng Bà Rịa Châu Đức Tphcm">
<meta name="twitter:title" content="Học kèm tin học văn phòng Bà Rịa Châu Đức Tphcm">
<meta name="twitter:description" content="Học kèm tin học văn phòng Bà Rịa Châu Đức Tphcm">
<meta name="twitter:image" content="http://daykembatnha.top/">
 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<style>
background-image: url("background.jpg");
</style>
</head>
<body>
<div class="container">
<fieldset>
<div style="text-align:center; font-weight:bold; color:#0000FF;"> THÂN TẶNG CÁC BẠN CÁC TÀI LIỆU SƯU TẦM CHẤT LƯỢNG. CHÚC CÁC BẠN THÀNH CÔNG<DIV>
<form name="form1" action="" method="GET">
 <table class="table table-bordered">
 <tr class="active">
 <td>
 <!--<select name="danhmuc">
        <option value="1" selected="1">Mời Bạn Chọn Loại tài liệu hoặc phần mềm</option>
		<?php
		/*$sql = "SELECT * FROM danhmucsanpham";
		$resultset = mysqli_query($mysqli, $sql) or die("database error:". mysqli_error($mysqli));
		while( $rows = mysqli_fetch_assoc($resultset) ) { 
		?>
		<option value="<?php echo $rows["id_dm"]; ?>"><?php echo $rows["Tendm"]; ?></option>
		<?php }	*/?>
</select>-->
</td>
</tr>
 <tr class="active">
<td><INPUT type="submit" name="submit" value="Gửi"></td>
</tr>
</table>
</FORM>

<div style="text-align:center; font-weight:bold; color:#0000FF;"> DANH SÁCH TÀI LIỆU DOWNLOAD <DIV>
<br/><br/>
    <table class="table table-bordered">
	<thead>
      <tr>
        <th>STT</th>
        <th>TÊN TÀI LIỆU</th>	
      </tr>
    </thead> 
   <tbody>
	<?php 
    /*$_GET["danhmuc"]=11;
	if(isset($_GET["danhmuc"]))
	{
	$danhmuc=$_GET["danhmuc"];
	echo $danhmuc;*/
	//$result = mysqli_query($mysqli, "SELECT * FROM link where id_dm=$danhmuc"); // using mysqli_query instead*/
	$Stt1=0;
	$mau1=array('active','sucess');
	$imau1=0;
	 $sql = "SELECT * FROM danhmucsanpham";
	 $resultset = mysqli_query($mysqli, $sql) or die("database error:". mysqli_error($mysqli));
	while( $rows = mysqli_fetch_assoc($resultset) ) { 
	//echo $rows["id_dm"]; echo $rows["Tendm"];
	 $Stt1=$Stt1+1;	
		echo "<tr class='".$mau1[$imau1]."'>";
		echo "<td colspan=2>".$rows['Tendm']."</td></tr>";
		$imau1=$imau1+1;			

	$danhmuc=$rows["id_dm"];
	$result = mysqli_query($mysqli, "SELECT * FROM link where id_dm=$danhmuc"); // using mysqli_query instead
	//while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array 
	$Stt=0;
	$mau=array('active','sucess');
	$imau=0;
	while($res = mysqli_fetch_array($result)) { 	
	    $Stt=$Stt+1;	
		echo "<tr class='".$mau[$imau]."'>";
		echo "<td>".$Stt."</td>";
		echo "<td><a href=\"vertify.php?id=$res[idlink]\">".$res['tenfile']."</a></td>";
		$imau=$imau+1;			
		}
	}
	?>
	</tbody>
	</table>
</fieldset>
</body>
</html>
