<?php header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

function msg($success, $status, $message, $extra = []) {
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ], $extra);
}

function getPostObject() {
    $str = file_get_contents('php://input');
    $std = json_decode($str);
    
    if ($std === null) {
        $std = new stdClass();
        $array = explode('&', $str);
        foreach ($array as $parm) {
            $parts = explode('=' ,$parm);
            if (sizeof($parts) != 2) {
                continue;
            }
            $key = urldecode($parts[0]);
            $value = urldecode($parts[1]);
            $std->$key = $value === '' ? null : $value;
        }
    }
    return $std;
}

$data = getPostObject();
$returnData = [];
include('class/User.php');
$user = new User();
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0, 404, 'Page Not Found!');
} elseif (!isset($data->ma) || (!isset($data->id))){
    $fields = ['fields' => ['ma','id']]; //id $fields = ['fields' => ['email','password']];
    $returnData = msg(0, 422, 'Please Fill in all Required Fields!', $fields);
} else {
    //$ma = base64_decode(trim($data->ma));
	$id = trim($data->id);
	$ma = mt_rand(100000, 999999);
	$cookie_name = "ma_".$id; // Tên cookie
$cookie_value =$ma; // Giá trị cookie
$cookie_expire = time() + (86400 * 30); // Thời gian sống của cookie (30 ngày)

// Gọi hàm setcookie để tạo cookie
setcookie($cookie_name, $cookie_value, $cookie_expire, "/"); // "/" để cookie có thể truy cập toàn bộ trang web
	//$_SESSION['ma']=$ma;
    // $id = $_POST['id'];
    //$tableName = 'detailproduct'; // Tên bảng bạn muốn cập nhật

    // Gọi hàm updateView
    //$isUpdated = $user->updateView($id,$tableName);

    if ($ma === false) {
        $returnData = msg(0, 422, 'Không tồn tại Mã!');
    } else {
        try {
            // Xử lý dữ liệu
            $message = "Code successed";
            $returnData = msg(1, 200, $message, ['ma' => $ma]);
        } catch (Exception $ex) {
            $returnData = msg(0, 500, $ex->getMessage(), ['ma' => $ma]);
        }
    }
}

echo json_encode($returnData);
?>