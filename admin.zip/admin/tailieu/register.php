<?php
session_start();
//require_once './config.php';
include_once("config.php");
include_once("config1.php");
// IF THERE ARE NO EMPTY FIELDS THEN-
?>
<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ],$extra);
}
function getPostObject() {
    $str = file_get_contents('php://input');
    $std = json_decode($str);
    if ($std === null) {
        $std = new stdClass();
        $array = explode('&', $str);
        foreach ($array as $parm) {
            $parts = explode('=', $parm);
            if(sizeof($parts) != 2){
                continue;
            }
            $key = $parts[0];
            $value = $parts[1];
            if ($key === NULL) {
                continue;
            }
            if (is_string($key)) {
                $key = urldecode($key);
            } else {
                continue;
            }
            if (is_bool($value)) {
                $value = boolval($value);
            } else if (is_numeric($value)) {
                $value += 0;
            } else if (is_string($value)) {
                if (empty($value)) {
                    $value = null;
                } else {
                    $lower = strtolower($value);
                    if ($lower === 'true') {
                        $value = true;
                    } else if ($lower === 'false') {
                        $value = false;
                    } else if ($lower === 'null') {
                        $value = null;
                    } else {
                        $value = urldecode($value);
                    }
                }
            } else if (is_array($value)) {
                // value is an array
            } else if (is_object($value)) {
                // value is an object
            }
            $std->$key = $value;
        }
        // length of post array
        //$std->length = sizeof($array);
    }
    return $std;
}
// GET DATA FORM REQUEST
//$data = json_decode(file_get_contents("php://input"));
$data=getPostObject();
$returnData = [];

// IF REQUEST METHOD IS NOT POST
if($_SERVER["REQUEST_METHOD"] != "POST"):
    $returnData = msg(0,404,'Page Not Found!');
// CHECKING EMPTY FIELDS
elseif(!isset($data->last_name) 
    || !isset($data->email) 
    || !isset($data->phone)
	|| !isset($data->course)
    || empty(trim($data->last_name))
    || empty(trim($data->email))
    || empty(trim($data->phone))
	|| empty(trim($data->course))
    ):
    $fields = ['fields' => ['name','email','phone']];
    $returnData = msg(0,422,'Please Fill in all Required Fields!',$fields);
// IF THERE ARE NO EMPTY FIELDS THEN-
else:
    $last_name = trim($data->last_name);
    $email = trim($data->email);
    $phone_mobile = trim($data->phone);
	$course = trim($data->course);

    if(!filter_var($email, FILTER_VALIDATE_EMAIL)):
        $returnData = msg(0,422,'Invalid Email Address!');
else:
//try
//{
			  require_once "phpmailer/class.phpmailer.php";
			  //$first_name = trim($_POST["first_name"]);
			  $id_form=2;			  
			  $sql = "SELECT COUNT(*) AS count from tbl_users where email = :email_id AND id_form =$id_form";
			  //echo $sql;
		  try {
				$stmt = $DB->prepare($sql);
				$stmt->bindValue(":email_id", $email);
				$stmt->execute();
				$result = $stmt->fetchAll();
			
				if ($result[0]["count"] > 0) {
				  $msg = "Email already exist";
				  $msgType = "warning";
				  $returnData = msg(0,422, 'This E-mail already in use!');
				} else {
				  $sql = "INSERT INTO `tbl_users` (`id_form`,`last_name`,`phone_mobile`,`email`,`course`) VALUES " . "(:id_form,:last_name,:phone_mobile,:email,:course)";
				  //echo $sql;
				  $stmt = $DB->prepare($sql);
				  $stmt->bindValue(":id_form", $id_form);
				  $stmt->bindValue(":last_name",  $last_name);
				  $stmt->bindValue(":phone_mobile", $phone_mobile);
				  $stmt->bindValue(":email", $email);
				  $stmt->bindValue(":course", $course);
				  $stmt->execute();
				  $result = $stmt->rowCount();
			
			
				  if ($result > 0) {
				   $returnData = msg(1,201,'Ban Kiem Tra Email kich hoat de nhan thong tin dang ky');
					$lastID = $DB->lastInsertId();
			
					$message = '<html><head>
					        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
							<title>Email kích hoạt đăng ký khóa học</title>
							</head>
							<body>';
					$message .= '<h1>Chào Bạn ' . $last_name . '! đã đăng ký khóa học</h1>';
					$message .= '<p><a href="'.SITE_URL.'activate.php?id=' . base64_encode($lastID).'&id_danh_muc='.base64_encode($id_form).'">Bạn nhấp vào đường link kích hoạt tài khoản đăng ký khóa học</a>';
					$message .= "</body></html>";
					
			
					// php mailer code starts
					$mail = new PHPMailer(true);
					$mail->IsSMTP(); // telling the class to use SMTP
			
					$mail->SMTPDebug = 0;                     // enables SMTP debug information (for testing)
					$mail->SMTPAuth = true;                  // enable SMTP authentication
					$mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
					$mail->Host = "smtp.mailgun.org";      // sets GMAIL as the SMTP server
					$mail->Port = 465;                   // set the SMTP port for the GMAIL server
			
					$mail->Username = 'ssc@bizcrmweb.com';
					$mail->Password = '5f17a7d2a8bb33e4556be469e9fb0c79-24e2ac64-3787027b';
			
					$mail->SetFrom('ssc@bizcrmweb.com', 'daykembatnha.top');
					$mail->AddAddress($email);
			
					$mail->Subject = trim("Email Verifcation dang ky khoa hoc");
					$mail->MsgHTML($message);
					
			        // Xóa session name
					try {
					  $mail->send();
					  //$mail2->send();
					  $msg = "An email has been sent for verfication.";
					  $msgType = "success";
					} catch (Exception $ex) {
					  $msg = $ex->getMessage();
					  $msgType = "warning";
					}
				  } else {
					$msg = "Failed to create User";
					$msgType = "warning";
				  }
				}
			  } catch (Exception $ex) {
				 $returnData = msg(0,500,$e->getMessage());
			  }

endif;
    
endif;

echo json_encode($returnData);

//}
//catch (Exception $ex) {
				//echo $ex->getMessage();
	//		  }
?>