<?php
// update_link.php - Script to handle the AJAX request for updating a link

header('Content-Type: application/json');
session_start();
include('class/UserLink.php');
$user = new User1();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $response = ['success' => false, 'message' => ''];
    
    // Validate captcha if required
    if(isset($_POST['txtCaptcha']) && isset($_SESSION['security_code'])) {
        if(empty($_POST['txtCaptcha'])) {
            $response['message'] = "Please enter the captcha code";
            echo json_encode($response);
            exit;
        }
        
        if($_POST['txtCaptcha'] != $_SESSION['security_code']) {
            $response['message'] = "Invalid captcha code";
            echo json_encode($response);
            exit;
        }
    }
    
    // Validate required fields
    if(empty($_POST['idlink']) || empty($_POST['id_dm']) || empty($_POST['url']) || empty($_POST['tenfile'])) {
        $response['message'] = "All fields are required";
        echo json_encode($response);
        exit;
    }
    
    // Get data from POST
    $idlink = (int)$_POST['idlink'];
    $id_dm = (int)$_POST['id_dm'];
    $url = $_POST['url'];
    $tenfile = $_POST['tenfile'];
    $userId = isset($_POST['userId']) ? (int)$_POST['userId'] : 0; // Optional user ID
    
    // Call the update link function
    $result = $user->updateLink($idlink, $id_dm, $url, $tenfile, $userId);
    
    if(isset($result['success']) && $result['success']) {
        $response['success'] = true;
        $response['message'] = $result['message'];
    } else {
        $response['message'] = "Error updating link: " . ($result['message'] ?? "Unknown error");
    }
    
    echo json_encode($response);
    exit;
}
?>

<?php
// delete_link.php - Script to handle the AJAX request for deleting a single link

header('Content-Type: application/json');
session_start();
include('class/UserLink.php');
$user = new User1();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $response = ['success' => false, 'message' => ''];
    
    // Validate required fields
    if(empty($_POST['idlink'])) {
        $response['message'] = "Link ID is required";
        echo json_encode($response);
        exit;
    }
    
    // Get data from POST
    $idlink = (int)$_POST['idlink'];
    
    // Call the delete link function
    $result = $user->deleteLink($idlink);
    
    if(isset($result['success']) && $result['success']) {
        $response['success'] = true;
        $response['message'] = $result['message'];
    } else {
        $response['message'] = "Error deleting link: " . ($result['message'] ?? "Unknown error");
    }
    
    echo json_encode($response);
    exit;
}
?>

<?php
// delete_links.php - Script to handle the AJAX request for bulk deleting links

header('Content-Type: application/json');
//session_start();
include('class/UserLink.php');
$user = new User1();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $response = ['success' => false, 'message' => ''];
    
    // Check if link IDs were provided
    if(empty($_POST['idlinks']) || !is_array($_POST['idlinks'])) {
        $response['message'] = "No links selected for deletion";
        echo json_encode($response);
        exit;
    }
    
    $idlinks = $_POST['idlinks'];
    
    // Call the delete links function
    $result = $user->deleteLinks($idlinks);
    
    if(isset($result['success']) && $result['success']) {
        $response['success'] = true;
        $response['message'] = $result['message'];
    } else {
        $response['message'] = "Error deleting links: " . ($result['message'] ?? "Unknown error");
    }
    
    echo json_encode($response);
    exit;
}
?>