<?php
header('Content-Type: application/json'); // Đặt tiêu đề cho phản hồi JSON
include('class/User.php');
$user = new User();

// Đảm bảo biến $tableName được định nghĩa trước khi gọi
$tableName = 'price'; // Thay thế bằng tên bảng của bạn

// Gọi hàm để lấy dữ liệu
$result = $user->getData1($tableName); // Lấy tất cả dữ liệu từ bảng

// Kiểm tra kết quả trả về
if ($result !== null) {
    if (count($result) > 0) {
        echo json_encode(['success' => true, 'data' => $result]); // Trả về toàn bộ dữ liệu
    } else {
        echo json_encode(['success' => false, 'message' => 'Không tìm thấy dữ liệu.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Lỗi truy vấn cơ sở dữ liệu.']);
}
?>