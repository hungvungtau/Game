<?php
header('Content-Type: application/json');

include('class/User.php');
$user = new User();

// Kiểm tra nếu người dùng chưa đăng nhập
if (!isset($_SESSION['userid'])) {
    echo json_encode(['success' => false, 'message' => 'Chưa đăng nhập.']);
    exit; 
}
if($_SESSION["type"] == "administrator")
{
	if ($_SERVER['REQUEST_METHOD'] === 'POST') {
		$id = $_SESSION['userid'];
		$tableName = 'user';

		// Gọi hàm để lấy dữ liệu
		$result = $user->getData2($tableName); // Lấy tất cả dữ liệu từ bảng

		// Kiểm tra kết quả trả về
		if ($result !== null) {
			if (count($result) > 0) {
				echo json_encode(['success' => true, 'data' => $result]); // Trả về toàn bộ dữ liệu
			} else {
				echo json_encode(['success' => false, 'message' => 'Không tìm thấy dữ liệu.']);
			}
		} else {
			echo json_encode(['success' => false, 'message' => 'Lỗi truy vấn cơ sở dữ liệu.']);
		}
	} else {
		echo json_encode(['success' => false, 'message' => 'Yêu cầu không hợp lệ.']);
	}
}else{echo json_encode(['success' => false, 'message' => 'Yêu cầu không hợp lệ.']);}
?>