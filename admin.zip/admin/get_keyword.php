<?php  session_start(); header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Connection: keep-alive");
header("Content-Type: application/json; charset=UTF-8");
header("Expires: Thu, 19 Nov 1981 08:52:00 GMT");
header("Pragma: no-cache");
header("Vary: Accept-Encoding");
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");
header("X-XSS-Protection: 1; mode=block");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header('Content-Type: application/json');
function msg($success, $status, $message, $extra = []) {
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ], $extra);
}

function getPostObject() {
    $str = file_get_contents('php://input');
    $std = json_decode($str);
    
    if ($std === null) {
        $std = new stdClass();
        $array = explode('&', $str);
        foreach ($array as $parm) {
            $parts = explode('=' ,$parm);
            if (sizeof($parts) != 2) {
                continue;
            }
            $key = urldecode($parts[0]);
            $value = urldecode($parts[1]);
            $std->$key = $value === '' ? null : $value;
        }
    }
    return $std;
}


$data = getPostObject();
$returnData = [];
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0, 404, 'Page Not Found!');
} elseif (!isset($data->id) || (!isset($data->Id)) || (!isset($data->keyword))){
    $fields = ['fields' => ['id','Id','keyword']]; //id $fields = ['fields' => ['email','password']];
    $returnData = msg(0, 422, 'Please Fill in all Required Fields!', $fields);
} else {
    $Id1 = trim($data->Id);
	$id = trim($data->id);
	//include('class/User.php');
//include(__DIR__ . '/class/User.php');
$Id="ma_".$Id1;
$keyword=trim($data->keyword);
include_once("config.php");
include('class/User.php');
$user = new User();
//fetching data in descending order (lastest entry first)
//$result = mysql_query("SELECT * FROM users ORDER BY id DESC"); // mysql_query is deprecated
$sql="SELECT * FROM link where idlink='".$id."'";
$result = mysqli_query($mysqli,$sql); // using mysqli_query instead
$result1 = mysqli_query($mysqli, "SELECT * FROM danhmucweb"); // using mysqli_query instead
	//while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array 
	while($res = mysqli_fetch_array($result)) 
	{
	    $row=$res['url'];	
		$Tenfile=$res['tenfile'];
	}
	while($res1 = mysqli_fetch_array($result1)) { 		
	   $row1[]=$res1;	
	}
	$num1 = array_rand($row1);	
	// Kiểm tra xem cookie có tồn tại không
	//$vaue=$user->getCookieValueById($Id);//setSessionById
	/*$vaue=$user->getSessionValueById($Id);
if (!isset($vaue)) {
    echo json_encode(['success' => false, 'message' => 'Not yet Code.', 'Id' => $vaue]);
    exit; 
}*/

	//$_SESSION['ma']=$ma;
    // $id = $_POST['id'];
    //$tableName = 'detailproduct'; // Tên bảng bạn muốn cập nhật
    
    // Gọi hàm updateView
    //$isUpdated = $user->updateView($id,$tableName);
    //$ma = $user->getCookieValueById($Id);
    //$keyword = $_POST['keyword'];
	// Giả định bạn đã có kết quả truy vấn trong biến $stmt	
	$links = [];
	  // Lấy mã
    //$Result = $user->getCode($Id1, "view",false);
	$links = $user->getCode($Id1, "view");
    if (!empty($links)) {
		// Khởi tạo mảng kết quả
// Bây giờ mảng $links chứa tất cả các hàng từ kết quả truy vấn
// Bạn có thể sử dụng $links như sau
	foreach ($links as $link)
		$Code=$link['Code'];
    } else {
        echo json_encode(['success' => false, 'message' => 'Not yet Code.']);
        exit;
    }
	//$Code='294260';

    $link = $row; // Thay đổi link nếu cần
    
    // So sánh mã nhập vào với mã trong cookie
    if ($keyword === $Code) {
        echo json_encode(['success' => true, 'message' => "You entered successfully", 'link' => $link]);
    } else {
        echo json_encode(['success' => false, 'message' => 'You entered code not successful.']);
    }
} 
?>