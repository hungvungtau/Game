<div id="top-nav" class="navbar navbar-inverse navbar-static-top" style="background:#c4e3f3;color:white;border-color:white;">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">Dashboard</a>
            <span class="icon-bar"> <a class="navbar-brand" href="#" id="viewWebsite">View Website</a></span>
			<span class="icon-bar"> <a class="navbar-brand" href="#" id="Addcategory">Add category</a></span>
			<span class="icon-bar"> <a class="navbar-brand" href="#" id="Addnoidung">Add noidung</a></span> 
			<span class="icon-bar"> <a class="navbar-brand" href="#" id="Addtblnoidung">Addtblnoidung</a></span> 
			<span class="icon-bar"> <a class="navbar-brand" href="#" id="Addhocsinhnoidung">Addhocsinhnoidung</a></span>
			<span class="icon-bar"> <a class="navbar-brand" href="#" id="Addfolder">Addfolder</a></span> 
			<span class="icon-bar"> <a class="navbar-brand" href="#" id="Addfile">Addfile</a></span> 
			<span class="icon-bar"> <a class="navbar-brand" href="#" id="Addquestion">Addquestion</a></span>
			<span class="icon-bar"> <a class="navbar-brand" href="#" id="viewhocsinh">view hocsinh</a></span>
				<span class="icon-bar"> <a class="navbar-brand" href="#" id="Editsource">Edit Course</a></span>
				<span class="icon-bar"> <a class="navbar-brand" href="#" id="Editsourcefull">Edit Course Full</a></span>
				<span class="icon-bar"> <a class="navbar-brand" href="#" id="Editsourcefullv1">Edit Course Fullv1</a></span>
				<span class="icon-bar"> <a class="navbar-brand" href="#" id="Addexercise">Addexercise</a></span>
				<span class="icon-bar"> <a class="navbar-brand" href="#" id="Editquestion">Editquestion</a></span>
				
		
        </div>
        <div class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-right">
                <li class="dropdown">
                    <a class="dropdown-toggle" role="button" data-toggle="dropdown" href="#"><i class="fa fa-user-circle"></i> <?php echo strtoupper($_SESSION['name']); ?> <span class="caret"></span></a>
                    <input type="hidden" id="email" value="<?php if(isset($_SESSION['email'])) echo $_SESSION['email'];?>">
					<input type="hidden" id="name" value="<?php if(isset($_SESSION["name"])) echo $_SESSION["name"];?>">
					<input type="hidden" id="id" value="<?php if(isset($_SESSION["userid"])) echo $_SESSION["userid"];?>">
					<ul id="g-account-menu" class="dropdown-menu" role="menu">
                        <li><a href="account.php"><i class="fa fa-user-secret"></i> My Profile</a></li>
                    </ul>
                </li>
                <li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>
            </ul>
        </div>
    </div>
</div>

<div id="content">
    <h1>Boost Your Website Traffic for Free with SSC</h1>

<h2>Introduction</h2>
<p>
    In the ever-evolving digital world, increasing website traffic is vital for businesses aiming to excel online. Regardless of whether you are a budding startup or a well-established company, a strong online presence can dramatically influence your success. At SSC, we recognize the challenges businesses encounter in attracting visitors and transforming them into loyal customers. That’s why we are thrilled to present our <strong>free solutions</strong> designed to effectively enhance your website traffic and boost your Google rankings.
</p>

<h2>The Significance of Website Traffic</h2>
<p>
    Website traffic is more than just a statistic; it represents genuine potential customers interested in your offerings. Higher visitor numbers translate to greater opportunities for conversions—whether through newsletter sign-ups, product purchases, or content engagement. However, driving traffic can be daunting, especially in competitive niches.
</p>

<h2>How SSC Can Elevate Your Traffic</h2>
<p>
    At SSC, we provide innovative tools and strategies aimed at increasing your website traffic at no cost. Here’s how our solutions can empower you:
</p>

<h3>1. SEO Optimization</h3>
<p>
    Our team offers valuable insights and recommendations to enhance your website’s search engine optimization (SEO). By refining your content and site structure, you can significantly boost your visibility in search engine results, attracting organic traffic that leads to higher rankings on Google.
</p>

<h3>2. Effective Content Marketing</h3>
<p>
    Our experts guide you in crafting engaging content that resonates with your audience. Captivating blogs, infographics, and videos not only attract more visitors but also encourage them to return to your site, enhancing your overall traffic.
</p>

<h3>3. Strategic Social Media Engagement</h3>
<p>
    Harness the power of social media to funnel traffic to your website. We assist you in creating impactful campaigns that captivate your audience and motivate them to explore your site.
</p>

<h3>4. Networking and Collaboration</h3>
<p>
    Become part of a community of like-minded businesses. Collaborating and networking can lead to increased exposure and traffic through shared audiences, helping you reach new potential customers.
</p>

<h2>Discover the Benefits for Free</h2>
<p>
    We invite you to join SSC and take advantage of our free services tailored to elevate your website traffic. Our intuitive platform allows you to implement these strategies with ease, enabling you to concentrate on what you do best—growing your business.
</p>

<h2>Conclusion</h2>
<p>
    Elevating website traffic is crucial for any business aspiring to thrive in the online marketplace. With SSC, you gain access to free tools and resources that can help you attract more visitors and convert them into loyal customers. Don’t miss this opportunity to strengthen your online presence and improve your Google rankings.
</p>

<p>
    <strong>Sign up today to experience our services for free!</strong> Join us at SSC and embark on your journey towards enhanced visibility and success.
</p><!-- Kết quả sẽ được hiển thị ở đây -->
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $('#viewWebsite').click(function(event) {
        event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết

        // Gửi yêu cầu AJAX để lấy nội dung
        $.ajax({
            url: 'getlink.php', // Đường dẫn đến tệp PHP
            method: 'POST',
            success: function(response) {
                // Hiển thị kết quả trong phần tử #content
                $('#content').html(response);
            },
            error: function() {
                $('#content').html('<p>An error has occurred</p>');
            }
        });
    });
});
$(document).ready(function() {
    $('#viewhocsinh').click(function(event) {
        event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết

        // Gửi yêu cầu AJAX để lấy nội dung
        $.ajax({
            url: 'getstudent.php', // Đường dẫn đến tệp PHP
            method: 'POST',
            success: function(response) {
                // Hiển thị kết quả trong phần tử #content
                $('#content').html(response);
            },
            error: function() {
                $('#content').html('<p>An error has occurred</p>');
            }
        });
    });
});//Editsource  
$(document).ready(function() {
    $('#Addfile').click(function(event) {
        event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết

        // Gửi yêu cầu AJAX để lấy nội dung
        $.ajax({
            url: 'Addfile.php', // Đường dẫn đến tệp PHP
            method: 'POST',
            success: function(response) {
                // Hiển thị kết quả trong phần tử #content
                $('#content').html(response);
            },
            error: function() {
                $('#content').html('<p>An error has occurred</p>');
            }
        });
    });
});
$(document).ready(function() {
    $('#Addfolder').click(function(event) {
        event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết

        // Gửi yêu cầu AJAX để lấy nội dung
        $.ajax({
            url: 'Addfolder.php', // Đường dẫn đến tệp PHP
            method: 'POST',
            success: function(response) {
                // Hiển thị kết quả trong phần tử #content
                $('#content').html(response);
            },
            error: function() {
                $('#content').html('<p>An error has occurred</p>');
            }
        });
    });
});
//Addnoidung 
$(document).ready(function() {
    $('#Addhocsinhnoidung').click(function(event) {
        event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết

        // Gửi yêu cầu AJAX để lấy nội dung
        $.ajax({
            url: 'Addhocsinhnoidung.php', // Đường dẫn đến tệp PHP
            method: 'POST',
            success: function(response) {
                // Hiển thị kết quả trong phần tử #content
                $('#content').html(response);
            },
            error: function() {
                $('#content').html('<p>An error has occurred</p>');
            }
        });
    });
});

$(document).ready(function() {
    $('#Addnoidung').click(function(event) {
        event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết

        // Gửi yêu cầu AJAX để lấy nội dung
        $.ajax({
            url: 'Addnoidung.php', // Đường dẫn đến tệp PHP
            method: 'POST',
            success: function(response) {
                // Hiển thị kết quả trong phần tử #content
                $('#content').html(response);
            },
            error: function() {
                $('#content').html('<p>An error has occurred</p>');
            }
        });
    });
});

$(document).ready(function() {
    $('#Addexercise').click(function(event) {
        event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết

        // Gửi yêu cầu AJAX để lấy nội dung
        $.ajax({
            url: 'Addexercise.php', // Đường dẫn đến tệp PHP
            method: 'POST',
            success: function(response) {
                // Hiển thị kết quả trong phần tử #content
                $('#content').html(response);
            },
            error: function() {
                $('#content').html('<p>An error has occurred</p>');
            }
        });
    });
});
$(document).ready(function() {
    $('#Editsource').click(function(event) {
        event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết

        // Gửi yêu cầu AJAX để lấy nội dung
        $.ajax({
            url: 'getcourse.php', // Đường dẫn đến tệp PHP
            method: 'POST',
            success: function(response) {
                // Hiển thị kết quả trong phần tử #content
                $('#content').html(response);
            },
            error: function() {
                $('#content').html('<p>An error has occurred</p>');
            }
        });
    });
});
$(document).ready(function() {
    $('#Editsourcefull').click(function(event) {
        event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết

        // Gửi yêu cầu AJAX để lấy nội dung
        $.ajax({
            url: 'getcoursefull.php', // Đường dẫn đến tệp PHP
            method: 'POST',
            success: function(response) {
                // Hiển thị kết quả trong phần tử #content
                $('#content').html(response);
            },
            error: function() {
                $('#content').html('<p>An error has occurred</p>');
            }
        });
    });
});
//
$(document).ready(function() {
    $('#Addtblnoidung').click(function(event) {
        event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết

        // Gửi yêu cầu AJAX để lấy nội dung
        $.ajax({
            url: 'Addtblnoidung.php', // Đường dẫn đến tệp PHP
            method: 'POST',
            success: function(response) {
                // Hiển thị kết quả trong phần tử #content
                $('#content').html(response);
            },
            error: function() {
                $('#content').html('<p>An error has occurred</p>');
            }
        });
    });
});

$(document).ready(function() {
    $('#Editsourcefullv1').click(function(event) {
        event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết

        // Gửi yêu cầu AJAX để lấy nội dung
        $.ajax({
            url: 'getcoursefullv1.php', // Đường dẫn đến tệp PHP
            method: 'POST',
            success: function(response) {
                // Hiển thị kết quả trong phần tử #content
                $('#content').html(response);
            },
            error: function() {
                $('#content').html('<p>An error has occurred</p>');
            }
        });
    });
});

$(document).ready(function() {
    $('#Editquestion').click(function(event) {
        event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết

        // Gửi yêu cầu AJAX để lấy nội dung
        $.ajax({
            url: 'Editquestion.php', // Đường dẫn đến tệp PHP
            method: 'POST',
            success: function(response) {
                // Hiển thị kết quả trong phần tử #content
                $('#content').html(response);
            },
            error: function() {
                $('#content').html('<p>An error has occurred</p>');
            }
        });
    });
});
//
/*$('#viewWebsite').click(function(event) {
    event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết

    var idValue = $("#Id").val(); // Lấy giá trị từ input
    var email = $("#email").val(); // Lấy giá trị từ input
    var name = $("#name").val(); // Lấy giá trị từ input

    // Gửi yêu cầu AJAX để lấy nội dung
    $.ajax({
        url: 'get_linkall.php', // Đường dẫn đến tệp PHP
        method: 'POST',
        data: { userId: idValue, name: name, email: email }, // Gửi giá trị userId
        dataType: 'json',
 success: function(response) {
    if (response.success) {
        var data = '';
        data += '<input type="hidden" value="' + email + '" id="email1" name="email">';
        data += '<input type="hidden" value="' + name + '" id="name1" name="name">';
        
        var table = '<table class="table table-striped table-custom">';
        table += '<thead><tr><th>STT</th><th>Date (Ngày)</th><th>Code (Mã đề) </th><th>Question </th><th>Type </th><th colspan=4>Result Student (Kết quả học sinh)</th><th>Core (Điểm)</th></tr></thead>';
        table += '<tbody>';
        
       // let previousId = null; // Biến lưu trữ Id_noidung trước đó
        response.data.forEach(function(item, index) {
            // Nếu Id_noidung thay đổi, thêm một dòng tiêu đề mới
           /* if (item.Id !== previousId) {
                // Dòng tiêu đề cho Id_noidung
                table += '<tr><td colspan="6" style="font-weight: bold; background-color: #f8f9fa;">' + item.Id_noidung + '</td></tr>';
                previousId = item.Id; // Cập nhật Id_noidung trước đó
            }*/
            
            // Dòng nội dung bài làm
  /*          table += '<tr>';
           // table += '<td>' + (index + 1) + '</td>'; // STT
			table += '<td><div id="item_' + item.idlink + '">' + item.idlink + '</div></td>';
			/*table += '<td><input type="hidden" value="' + item.Code + '" id="Code_' + item.Id + '">' + item.Code+ '</td>';
            table += '<td><input type="hidden" value="' + item.Namequestion + '" id="Namequestion_' + item.Id + '">' + item.Namequestion + '</td>';
            table += '<td><input type="hidden" value="' + item.Type+ '" id="Type_' + item.Id + '">' + item.Type + '</td>';
            table += '<td><input type="hidden" value="' + item.answer1 + '" id="answer1_' + item.Id + '">' + item.answer1 + '</td>';
			table += '<td><input type="hidden" value="' + item.answer2 + '" id="answer2_' + item.Id + '">' + item.answer2 + '</td>';
			table += '<td><input type="hidden" value="' + item.answer3 + '" id="answer3_' + item.Id + '">' + item.answer3 + '</td>';
			table += '<td><input type="hidden" value="' + item.answer4 + '" id="answer4_' + item.Id + '">' + item.answer4 + '</td>';
			//table += '<td><input type="hidden" value="' + item.Correct_answer + '" id="Correct_answer_' + item.Id + '">' + item.Correct_answer + '</td>';
           table += '<td><input type="hidden" value="' + item.Score + '" id="	Score_' + item.Id + '">' + item.Score + '</td>';*/
            //table += '</tr>';
        /*});
        
        table += '</tbody></table>';
        $('#content').html(data + table); // Hiển thị bảng trong phần tử #content
    } else {
        $('#content').html('<p>' + response.message + '</p>');
    }
}
    });
});*/

/*$('#viewWebsite').click(function(event) {
    event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết
    var idValue = $("#Id").val(); // Lấy giá trị từ input
    var email = $("#email").val(); // Lấy giá trị từ input
    var name = $("#name").val(); // Lấy giá trị từ input
    
    // Gửi yêu cầu AJAX để lấy nội dung
    $.ajax({
        url: 'get_linkall.php', // Đường dẫn đến tệp PHP
        method: 'POST',
        data: { userId: idValue, name: name, email: email }, // Gửi giá trị userId
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                // Tạo input ẩn để lưu trữ thông tin
                var data = '';
                data += '<input type="hidden" value="' + email + '" id="email1" name="email">';
                data += '<input type="hidden" value="' + name + '" id="name1" name="name">';
                
                // Tạo bảng Bootstrap để hiển thị dữ liệu
                var table = '<table class="table table-striped">';
                table += '<thead><tr><th>ID</th><th>Website ID</th><th>DM ID</th><th>URL</th><th>Tên File</th><th>Hành động</th></tr></thead>';
                table += '<tbody>';
                
                // Lặp qua các phần tử trong response.data
                response.data.forEach(function(item) {
                    table += '<tr>';
                    table += '<td><div id="item_' + item.idlink + '">' + item.idlink + '</div></td>';
                    /*table += '<td><input type="hidden" value="' + item.idweb + '" id="idweb_' + item.idlink + '">' + item.idweb + '</td>';
                    table += '<td><input type="hidden" value="' + item.id_dm + '" id="id_dm_' + item.idlink + '">' + item.id_dm + '</td>';
                    table += '<td><input type="hidden" value="' + item.url + '" id="url_' + item.idlink + '"><a href="' + item.url + '" target="_blank">Xem link</a></td>';
                    table += '<td><input type="hidden" value="' + item.tenfile + '" id="tenfile_' + item.idlink + '">' + item.tenfile + '</td>';
                    table += '<td><button type="button" class="btn btn-primary" id="buy_' + item.idlink + '" onclick="Buymomo(' + item.idlink + ')">Mua ngay</button></td>';*/
  /*                  table += '</tr>';
                });
                
                table += '</tbody></table>';
                $('#content').html(data + table); // Hiển thị bảng trong phần tử #content
            } else {
                $('#content').html('<div class="alert alert-danger">' + response.message + '</div>');
            }
        },
        error: function(xhr, status, error) {
            console.error(xhr.responseText); // In ra thông tin lỗi
            $('#content').html('<div class="alert alert-danger">Đã xảy ra lỗi: ' + error + '</div>');
        }
    });
});&/
/*$(document).ready(function() {
       /* $(document).ready(function() {
            $('button.view-button').click(function(e) {
                e.preventDefault(); // Ngăn chặn hành vi mặc định của nút
                var id = $(this).data('id');
                var link = $(this).data('link');
                $.ajax({
                    url: 'viewwebsite.php',
                    type: 'GET',
                    data: { id: id, link: link },
                    success: function(data) {
                        $('#content').html(data); // Hiển thị nội dung trả về từ viewwebsite.php trong thẻ div#content
                    },
                    error: function() {
                        alert('Lỗi khi tải nội dung');
                    }
                });
            });
        });*///Partner
$(document).ready(function() {
    $('#Addcategory').click(function(event) {
        event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết

        // Gửi yêu cầu AJAX để lấy nội dung
        $.ajax({
            url: 'addcategory.php', // Đường dẫn đến tệp PHP
            method: 'POST',
            success: function(response) {
                // Hiển thị kết quả trong phần tử #content
                $('#content').html(response);
            },
            error: function() {
                $('#content').html('<p>An error has occurred</p>');
            }
        });
    });
});
$(document).ready(function() {
    $('#Addquestion').click(function(event) {
        event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết

        // Gửi yêu cầu AJAX để lấy nội dung
        $.ajax({
            url: 'Addquestion.php', // Đường dẫn đến tệp PHP
            method: 'POST',
            success: function(response) {
                // Hiển thị kết quả trong phần tử #content
                $('#content').html(response);
            },
            error: function() {
                $('#content').html('<p>An error has occurred</p>');
            }
        });
    });
});

$(document).ready(function() {
    $('#Partner').click(function(event) {
        event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết
           var id = $(this).data('id');
        // Gửi yêu cầu AJAX để lấy nội dung
        $.ajax({
            url: 'updatePartner.php', // Đường dẫn đến tệp PHP
            method: 'POST',
			data: { id: id},
            success: function(response) {
                // Hiển thị kết quả trong phần tử #content
                $('#content').html(response);
            },
            error: function() {
                $('#content').html('<p>An error has occurred</p>');
            }
        });
    });
});
$(document).ready(function() {
    $('#User').click(function(event) {
        event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết
           var id = $(this).data('id');
        // Gửi yêu cầu AJAX để lấy nội dung
        $.ajax({
            url: 'get_user.php', // Đường dẫn đến tệp PHP
            method: 'POST',
			data: { id: id},
            success: function(response) {
                // Hiển thị kết quả trong phần tử #content
                $('#content').html(response);
            },
            error: function() {
                $('#content').html('<p>An error has occurred</p>');
            }
        });
    });
});
$(document).ready(function() {
    $('#Deposit').click(function(event) {
        event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết
           var id = $(this).data('id');
        // Gửi yêu cầu AJAX để lấy nội dung
        $.ajax({
            url: 'get_user.php', // Đường dẫn đến tệp PHP
            method: 'POST',
			data: { id: id},
            success: function(response) {
                // Hiển thị kết quả trong phần tử #content
                $('#content').html(response);
            },
            error: function() {
                $('#content').html('<p>An error has occurred</p>');
            }
        });
    });
});

$('#Price').click(function(event) {
    event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết

    var idValue = $("#Id").val(); // Lấy giá trị từ input
	var email = $("#email").val(); // Lấy giá trị từ input
	var name = $("#name").val(); // Lấy giá trị từ input



    // Gửi yêu cầu AJAX để lấy nội dung
    $.ajax({
        url: 'get_price.php', // Đường dẫn đến tệp PHP
        method: 'POST',
        data: { userId: idValue,name: name,email: email}, // Gửi giá trị userId
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                // Tạo bảng Bootstrap để hiển thị dữ liệu
				var data;
				data += '<input type="hidden" value="'+email+'" id="email1" name="email">';
				data += '<input type="hidden" value="'+name+'" id="name1" name="name">';
                var table = '<table class="table table-striped">';
                table += '<thead><tr><th>Ordinal number</th><th>Service Package</th><th>Number View</th><th>Price</th><th>Buy</th></tr></thead>';
                table += '<tbody>';
		
                
							// Giả sử response.data là mảng các bản ghiNumber View
			  response.data.forEach(function(item) {
				table += '<tr>';
				table += '<td><div id="item_' + item.Id + '">' + item.Id + '</div></td>'; // Sử dụng ID duy nhất cho mỗi dòng
				table += '<td><input type="hidden" value="' + item.ServicePackage + '" id="ServicePackage_' + item.Id + '">' + item.ServicePackage + '</div></td>';
				table += '<td><input type="hidden" value="' + item.Number_View + '" id="Number_View_' + item.Id + '">' + item.Number_View + '</div></td>';
				table += '<td><input type="hidden" value="' + item.Price + '" id="Price_' + item.Id + '">' + item.Price + '</div></td>';
				table += '<td><button type="button" id="buy_' + item.Id + '" onclick="Buymomo(' + item.Id + ')">Buy</button></td>';
				table += '</tr>';
			});
                table += '</tbody></table>';
                $('#content').html(data+table); // Hiển thị bảng trong phần tử #content
            } else {
                $('#content').html('<p>' + response.message + '</p>');
            }
        },
        error: function(xhr, status, error) {
            console.error(xhr.responseText); // In ra thông tin lỗi
            $('#content').html('<p>An error has occurred: ' + error + '</p>');
        }
    });
});/*$(document).ready(function() {
    $('#Price').click(function(event) {
        event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết

        // Gửi yêu cầu AJAX để lấy nội dung
        $.ajax({
            url: 'get_price.php', // Đường dẫn đến tệp PHP
            method: 'POST',
            success: function(response) {
                // Hiển thị kết quả trong phần tử #content
                $('#content').html(response);
            },
            error: function() {
                $('#content').html('<p>An error has occurred</p>');
            }
        });
    });
});*/
/*
$('#Price').click(function(event) {
    event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết

    var idValue = $("#Id").val(); // Lấy giá trị từ input
    var email = $("#email").val(); // Lấy giá trị từ input
    var name = $("#name").val(); // Lấy giá trị từ input

    // Gửi yêu cầu AJAX để lấy nội dung
    $.ajax({
        url: 'get_price.php', // Đường dẫn đến tệp PHP
        method: 'POST',
        data: { userId: idValue, name: name, email: email }, // Gửi giá trị userId
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                // Tạo bảng Bootstrap để hiển thị dữ liệu
                var data;
                data += '<input type="hidden" value="' + email + '" id="email1" name="email">';
                data += '<input type="hidden" value="' + name + '" id="name1" name="name">';
                var table = '<table class="table table-striped">';
                table += '<thead><tr><th>Ordinal number</th><th>Service Package</th><th>Number View</th><th>Price</th><th>Buy</th></tr></thead>';
                table += '<tbody>';

                // Giả sử response.data là mảng các bản ghi
                response.data.forEach(function(item) {
                    table += '<tr>';
                    table += '<td><div id="item_' + item.Id + '">' + item.Id + '</div></td>'; // Sử dụng ID duy nhất cho mỗi dòng
                    table += '<td><input type="hidden" value="' + item.ServicePackage + '" id="ServicePackage_' + item.Id + '">' + item.ServicePackage + '</td>';
                    table += '<td><input type="hidden" value="' + item.Number_View + '" id="Number_View_' + item.Id + '">' + item.Number_View + '</td>';
                    table += '<td><input type="hidden" value="' + item.Price + '" id="Price_' + item.Id + '">' + item.Price + '</td>';
                    table += '<td><button type="button" id="buy_' + item.Id + '" onclick="handleBuy(' + item.Id + ')">Buy</button></td>';
                    table += '</tr>';
                });

                table += '</tbody></table>';
                $('#content').html(data + table); // Hiển thị bảng trong phần tử #content
            } else {
                $('#content').html('<p>' + response.message + '</p>');
            }
        },
        error: function(xhr, status, error) {
            console.error(xhr.responseText); // In ra thông tin lỗi
            $('#content').html('<p>An error has occurred: ' + error + '</p>');
        }
    });
});

// Hàm xử lý nút Buy
function handleBuy(itemId) {
    var country = $("#countrySelect").val(); // Lấy giá trị từ dropdown chọn quốc gia

    if (country === "Vietnam") {
        BuyPayOS(itemId);
    } else {
        Buymomo(itemId);
    }
}*/

function Buy(id) {
    var email = $('#email1').val();
    var Name = $('#name1').val();
    var packageName = $('#ServicePackage_' + id).val();
    var price = $('#Price_' + id).val();

    var payoneerUrl = 'https://www.payoneer.com/?email=' + encodeURIComponent(email) +
                      '&userName=' + encodeURIComponent(Name) +
                      '&package=' + encodeURIComponent(packageName) +
                      '&price=' + encodeURIComponent(price);

    window.location.href = payoneerUrl;
}
function Buymomo(itemId) {
    var email = $("#email1").val(); // Lấy giá trị email
    var name = $("#name1").val(); // Lấy giá trị tên
    var price = $("#Price_" + itemId).val(); // Lấy giá trị giá từ bảng

    // Gọi AJAX để thực hiện thanh toán qua MoMo
    $.ajax({
        url: 'process_payment.php', // Đường dẫn đến tệp PHP xử lý thanh toán
        method: 'POST',
        data: {
            itemId: itemId,
            email: email,
            name: name,
            price: price
        },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                // Chuyển hướng đến trang thanh toán MoMo hoặc hiển thị thông báo thành công
                window.location.href = response.paymentUrl; // URL thanh toán từ MoMo
            } else {
                alert('Thanh toán không thành công: ' + response.message);
            }
        },
        error: function(xhr, status, error) {
            console.error(xhr.responseText); // In ra thông tin lỗi
            alert('Có lỗi xảy ra trong quá trình thanh toán: ' + error);
        }
    });
}
function BuyPayOS(itemId) {
    var email = $("#email1").val(); // Lấy giá trị email
    var name = $("#name1").val(); // Lấy giá trị tên
    var price = $("#Price_" + itemId).val(); // Lấy giá trị giá từ bảng

    // Gọi AJAX để thực hiện thanh toán qua payOS
    $.ajax({
        url: 'process_payment_payos.php', // Đường dẫn đến tệp PHP xử lý thanh toán
        method: 'POST',
        data: {
            itemId: itemId,
            email: email,
            name: name,
            price: price
        },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                // Hiển thị thông báo thành công hoặc chuyển hướng
                alert('Thanh toán thành công! Mã giao dịch: ' + response.transactionId);
                // Bạn có thể thêm mã để chuyển hướng đến trang khác nếu cần
            } else {
                alert('Thanh toán không thành công: ' + response.message);
            }
        },
        error: function(xhr, status, error) {
            console.error(xhr.responseText); // In ra thông tin lỗi
            alert('Có lỗi xảy ra trong quá trình thanh toán: ' + error);
        }
    });
}</script>
