<?php
header('Content-Type: application/json'); // Đặt tiêu đề cho phản hồi JSON

include('class/UserLink.php');
$user = new User1();

// Add_hocsinhnoidung.php
// Lấy dữ liệu từ POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

	$response = []; // Khởi tạo phản hồi ngay từ đầu để tránh lỗi undefined

	if ($_POST['txtCaptcha'] == NULL)
	{
		$response['success'] = false;
		$response['message'] = "Please enter your code ";
	}
	else
	{
		if ($_POST['txtCaptcha'] == $_SESSION['security_code'])
		{
			$userId       = $_SESSION['userid']; // Sử dụng ID người dùng từ session
			$Partner      = isset($_SESSION["Partner"]) ? $_SESSION["Partner"] : null;

			$id_hocsinh = isset($_POST['id_hocsinh']) ? trim($_POST['id_hocsinh']) : '';
			$id_noidung = isset($_POST['id_noidung']) ? trim($_POST['id_noidung']) : '';

			if ($id_hocsinh === '' || !ctype_digit($id_hocsinh))
			{
				$response['success'] = false;
				$response['message'] = 'Học sinh không hợp lệ';
			}
			elseif ($id_noidung === '' || !ctype_digit($id_noidung))
			{
				$response['success'] = false;
				$response['message'] = 'Nội dung không hợp lệ';
			}
			else
			{
				// Gọi hàm addHocSinhNoiDung và kiểm tra kết quả
				$insertResult = $user->addHocSinhNoiDung($id_hocsinh, $id_noidung);

				if (isset($insertResult['success']) && $insertResult['success'] == true)
				{
					$response['success'] = $insertResult['success'];
					$response['message'] = $insertResult['message'];
				}
				else
				{
					$response['success'] = false;
					$response['message'] = isset($insertResult['message']) ? $insertResult['message'] : 'Lỗi không xác định';
				}
			}
		}
		else
		{
			$response['success'] = false;
			$response['message'] = "Error: Invalid code ";
		}
	}

	// Trả về dữ liệu dưới dạng JSON
	echo json_encode($response);
	exit; // Đảm bảo không có thêm thông tin nào được in
}
?>