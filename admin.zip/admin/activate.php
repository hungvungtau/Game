<html>
<head>
 <title>Học tin học văn phòng daykembatnha.top</title>
 <meta charset="utf-8" />
 <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
<?php
/*
 * @author Shahrukh Khan
 * @website http://www.thesoftwareguy.in
 * @facebbok https://www.facebook.com/Thesoftwareguy7
 * @twitter https://twitter.com/thesoftwareguy7
 * @googleplus https://plus.google.com/+thesoftwareguyIn
 */
?>
<?php
$s='<fieldset>
<div style="text-align:center; font-weight:bold; color:#0000FF;">KHÓA HỌC TÙY TÂM. NHẰM CHIA SẼ HỖ TRỢ QUÝ ANH CHỊ EM TRONG MÙA DỊCH, ỦNG HỘ TRẺ EM KHUYẾT TẬT VÀ TRẺ EM MỒ CÔI <DIV><br/><br/>
<table class="table table-bordered"><thead><tr><th>STT</th><th>TÊN KHÓA HỌC</th><th>THỜI GIAN</th><th>LINK THAM GIA</th></tr></thead><tbody>';
?> 
	<?php 
/*	$sql="SELECT * FROM khoahoc";
	//echp $sql;
	$result = mysqli_query($mysqli,$sql) or die("database error:".mysqli_error($mysqli));// using mysqli_query instead
	if (mysqli_num_rows($result) > 0) 
	{
	$Stt=0;
	$mau=array('active','sucess');
	$imau=0;
	while($res = mysqli_fetch_array($result)) { 	
	    $Stt=$Stt+1;	
		$s.="<tr class='".$mau[$Stt]."'>";
		$s.="<td>".$Stt."</td>";
		$s.="<td>".$res['Tenkhoahoc']."</td>";
		$s.="<td>".$res['Thoigian']."</td>";
		$s.="<td>".$res['Link']."</td>";
		//$imau=$imau+1;			
		}
	}*/
?>
<?php
	$s.='</tbody></table></fieldset>';
	//echo $s;
?>
<?php
include('class/User.php');
$user = new User();
if (isset($_GET["id"])) {
  $id = intval(base64_decode(trim($_GET["id"])));
  $id_form = intval(base64_decode(trim($_GET["id_danh_muc"])));
  $authtoken = trim($_GET["authtoken"]);
    // Lấy thông tin từ POST
    

    // Gọi hàm để kích hoạt tài khoản
    $activateResult = $user->activateUser($id, $id_form, $authtoken);

    // Xử lý kết quả từ hàm activateUser
    if (isset($activateResult['msg']) && $activateResult['msgType'] === "success") {
        echo json_encode(['success' => true, 'message' => $activateResult['msg']]);
    } else {
        $errorMessage = isset($activateResult['msg']) ? $activateResult['msg'] : 'An unknown error occurred.';
        echo json_encode(['success' => false, 'message' => $errorMessage]);
    }

    exit; // Đảm bảo không có thêm thông tin nào được in
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
}
?>
<?php if ($msg <> "") { ?>
  <div class="alert alert-dismissable alert-<?php echo $msgType; ?>">
    <button data-dismiss="alert" class="close" type="button">x</button>
    <p><?php echo $msg; ?></p>
  </div>
<?php } ?>
<div class="container">
  <div class="row">
    <div class="col-lg-9">
      <h1>Thank you for registering with us.</h1>
    </div>
  </div>
</div>

<script type="text/javascript">
  function validateForm() {

    var your_name = $.trim($("#uname").val());
    var your_email = $.trim($("#uemail").val());
    var pass1 = $.trim($("#pass1").val());
    var pass2 = $.trim($("#pass2").val());


    // validate name
    if (your_name == "") {
      alert("Enter your name.");
      $("#uname").focus();
      return false;
    } else if (your_name.length < 3) {
      alert("Name must be atleast 3 character.");
      $("#uname").focus();
      return false;
    }

    // validate email
    if (!isValidEmail(your_email)) {
      alert("Enter valid email.");
      $("#uemail").focus();
      return false;
    }

    // validate subject
    if (pass1 == "") {
      alert("Enter password");
      $("#pass1").focus();
      return false;
    } else if (pass1.length < 6) {
      alert("Password must be atleast 6 character.");
      $("#pass1").focus();
      return false;
    }

    if (pass1 != pass2) {
      alert("Password does not matched.");
      $("#pass2").focus();
      return false;
    }

    return true;
  }

  function isValidEmail(email) {
    var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return regex.test(email);
  }


</script>

<?php
include './footer.php';
?>
</body>
</html>