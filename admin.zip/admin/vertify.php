<?php  //session_start();
//including the database connection file
//include_once("config.php");
//$_GET['id']=6;
if (isset($_GET['id']))
{
  $id=$_GET['id'];
  //$_SESSION["id"]=$id;
}
else
{
 //$id=$_SESSION["id"];
}
include('class/User.php');
//include(__DIR__ . '/class/User.php');
$user = new User();
$tableName = 'user';

    // Gọi hàm để lấy dữ liệu
    $result = $user->getData4($tableName); // Lấy tất cả dữ liệu từ bảng
    // Khởi tạo mảng chứa các sản phẩm
$Keywords = [];

// Kiểm tra xem kết quả có dữ liệu không
if (!empty($result)) {
    foreach ($result as $row) {
			 $Keywords[] = array(
			  'Id' => $row['Id'],
            'NameDeltail' => $row['NameDeltail'],
            'Picture' => $row['Picture']);
    }
}
// Khởi tạo mảng chứa dữ liệu đã tách
$keywordsArray = [];

// Lặp qua từng sản phẩm trong kết quả
foreach ($Keywords as $row) {
    // Tách từ khóa từ NameDeltail
    $keys = explode(',', $row['NameDeltail']); // Tách các từ khóa bằng dấu phẩy

    // Lặp qua từng từ khóa và thêm vào mảng mới
    foreach ($keys as $key) {
        $keywordsArray[] = array(
            'Id' => $row['Id'],
            'NameDeltail' => trim($key), // Loại bỏ khoảng trắng
            'Picture' => $row['Picture']
        );
    }
}

// Kiểm tra xem mảng không rỗng
if (!empty($keywordsArray)) {
    // Lấy chỉ số ngẫu nhiên của phần tử trong mảng
    $randomIndex = array_rand($keywordsArray);

    // Lưu giá trị ngẫu nhiên vào biến
    $randomKeyword = $keywordsArray[$randomIndex];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LÀM THEO CÁC BƯỚC ĐỂ LẤY LINK TRUY CẬP</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
      <style>
        body {
            background-color: #f8f9fa;
        }
        .header {
            background-color: #343a40;
            color: white;
            padding: 30px 0;
        }
        .step-title {
            margin-top: 20px;
            font-size: 1.5rem;
            color: #343a40;
        }
        .btn-dark-custom {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-dark-custom:hover {
            background-color: #0056b3;
            border-color: #004085;
        }
        .instruction-text {
            font-size: 1.2rem;
            color: #495057;
        }
        .footer {
            margin-top: 40px;
            padding: 20px 0;
            text-align: center;
        }
    </style>
	 <script>
        function copyToClipboard() {
            // Lấy giá trị từ ô nhập liệu
            const input = document.getElementById("key");
            input.select(); // Chọn nội dung trong ô nhập liệu
            
            // Sao chép nội dung vào bộ nhớ tạm
            document.execCommand("copy");

            // Hiển thị thông báo (tuỳ chọn)
            alert("Đã sao chép: " + input.value);
        }
    </script>
</head>
<body>
      <div class="container-fluid header">
        <h1 class="text-center">LÀM THEO CÁC BƯỚC ĐỂ LẤY LINK TRUY CẬP</h1>
    </div>
    <div class="container my-5">
        <div class="row">
            <div class="col-md-12">
                <h3 class="step-title">Bước 1: Mở tab mới, truy cập Google.com</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h3 class="step-title">Bước 2: Hãy nhập từ khóa trong ô dưới đây vào google.com</h3>
                <input type="text" class="form-control" id="key" value="<?php  echo $randomKeyword["NameDeltail"];?>" readonly>
				 <button onclick="copyToClipboard()">Copy</button>
                <input type="hidden" id="Id" class="form-control" value="<?php echo $randomKeyword["Id"];?>" readonly>
             <input type="hidden" id="id" class="form-control" value="<?php echo   $id;//$_SESSION["id"];?>" readonly>
            </div>
			</div>
        </div>
<?php 
    // Xóa phần tử vừa lấy ra khỏi mảng
    unset($keywordsArray[$randomIndex]);

    // Nếu cần, bạn có thể reindex lại mảng
    $keywordsArray = array_values($keywordsArray);
}?>
		<h4>Bạn vào web tìm từ khóa ở trên tìm ở cuối trang hoặc bên trái hoặc bên phải<br> giống rồi click vào nút Get Code như trên hình</h4>
        <div class="row mt-4">
            <p><div class="col-md-6" id="img1"><img src="<?php echo 'http://marketingfunnel.top/'.$randomKeyword["Picture"];?>" width="100%"></div></p>
        </div>
		 <div class="row mt-4">        
            <div class="col-md-6">
                <h3 class="step-title">Bước 3: Sau khi vào website bạn tìm cuối bài viết hình dưới đây</h3>
               <p><div class="col-md-6" id="img1"><img src="laymacode.png" width="100%"></div></p>
            </div>
        </div>
		 <div class="row mt-4">        
            <div class="col-md-6">
                <h3 class="step-title">Bước 4:</h3>
                <div class="input-group mb-3">
				    <div style="margin-left: 20px;">
                    <input type="text" id="keyword" class="form-control" placeholder="Nhập mã vào đây"></div>
                    <div class="input-group-append">
                        <button id="vertify" class="btn btn-dark-custom" type="button">Xác nhận</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="text-center footer">
                    <button class="btn btn-dark-custom">VIDEO HƯỚNG DẪN CÁCH LẤY MÃ</button>
                </div>
            </div>
        </div>
    </div>

    
  <script>
  $(document).ready(function() {
    $('#vertify').click(function(event) {
        event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết
        var keyword =$('#keyword').val(); 
		var Id =$('#Id').val();
		var id =$('#id').val();		
        //alert(keyword);
        // Gửi yêu cầu AJAX để lấy nội dung
        $.ajax({
            url: 'get_keyword.php', // Đường dẫn đến tệp PHP
            method: 'POST',
            data: {'keyword': keyword,'Id': Id,'id': id},
            success: function(response) {
                // Giả sử response chứa đường dẫn link
                var link = response.link; // Lấy đường link từ phản hồi

                // Tạo thẻ meta và thêm vào head
               // $('head').append('<meta http-equiv="refresh" content="0;url=' + link + '">');
			   alert(response.message);
			   alert(response.success);//
			    //alert(response.Id);//
			   //alert(response.ma);//
			   
			      // alert(response.message);
                    if (response.success) {
                        // Chuyển hướng nếu thành công
                        window.location.href = response.link;
                    }

                // Hiển thị kết quả trong phần tử #content (nếu cần)
                ///$('#content').html(response.link);
            },
            error: function() {
                $('#content').html('<p>An error has occurred</p>');
            }
        });
    });
});
	$(document).ready(function() {
    // Gửi yêu cầu AJAX ngay khi tài liệu đã sẵn sàng
    loadData();
    var id =$('#id').val();	
    function loadData() {
        $.ajax({
            url: 'http://marketingfunnel.top/get_product.php', // Đường dẫn đến file PHP
			//url: 'get_product.php', // Đường dẫn đến file PHP
            method: 'POST',
			data: {'id': id},
            success: function(response) {
                // Phân tích dữ liệu JSON trả về
                //var keywordsArray = JSON.parse(response.data);
				var keywordsArray = response.data;
                 // In ra giá trị của keywordsArray trong console
                //console.log(keywordsArray);
                // Lấy chỉ số ngẫu nhiên
                var randomIndex = Math.floor(Math.random() * keywordsArray.length);
                
                // Lấy phần tử ngẫu nhiên
                var randomKeyword = keywordsArray[randomIndex];
                 // Gán giá trị cho input có id="key"
				// alert(randomKeyword.NameDeltail);
                $('#key').val(randomKeyword.NameDeltail);//img
				 $('#Id').val(randomKeyword.Id);//img
				//$('#img').val(randomKeyword.picture);
				// Hiển thị kết quả
				var content = '<div>';
				content += '<img src="' + randomKeyword.Picture + '" class="img-fluid" width=100%>';
				content += '</div>';

				// Cập nhật nội dung trong phần tử #content
				//$('#content').html(content);
				//img=randomKeyword.picture;
                // Hiển thị kết quả
               /* var content = '<div>';
                content += '<h3>' + randomKeyword.NameDeltail + '</h3>';
                content += '<img src="' + randomKeyword.Picture + '" alt="' + randomKeyword.NameDeltail + '">';
                content += '</div>';*/
                 $('#img1').html(content);
                // Cập nhật nội dung trong phần tử #content
               // $('#content').html(content);
            },
           error: function(jqXHR, textStatus, errorThrown) {
    console.log("Error: " + textStatus + " - " + errorThrown);
    $('#content').html('<p>An error has occurred: ' + textStatus + '</p>');
}
        });
    }
});
  	

    </script>
</body>
</html>
