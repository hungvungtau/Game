<script>
  $(document).ready(function() {
    $('#vertify').click(function(event) {
        event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết
        var keyword =$('#keyword').val(); 
        //alert(keyword);
        // Gửi yêu cầu AJAX để lấy nội dung
        $.ajax({
            url: 'get_keyword.php', // Đường dẫn đến tệp PHP
            method: 'POST',
            data: {'keyword': keyword},
            success: function(response) {
                // Giả sử response chứa đường dẫn link
                var link = response.link; // Lấy đường link từ phản hồi

                // Tạo thẻ meta và thêm vào head
               // $('head').append('<meta http-equiv="refresh" content="0;url=' + link + '">');
			   alert(response.message);
			   alert(response.success);//
			   //alert(response.ma);//
			   
			       alert(response.message);
                    if (response.success) {
                        // Chuyển hướng nếu thành công
                        window.location.href = response.link;
                    }

                // Hiển thị kết quả trong phần tử #content (nếu cần)
                ///$('#content').html(response.link);
            },
            error: function() {
                $('#content').html('<p>An error has occurred</p>');
            }
        });
    });
});