<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Connection: keep-alive");
header("Content-Type: application/json; charset=UTF-8");
header("Expires: Thu, 19 Nov 1981 08:52:00 GMT");
header("Pragma: no-cache");
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");
header("X-XSS-Protection: 1; mode=block");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

function msg($success, $status, $message, $extra = []) {
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ], $extra);
}

function getPostObject() {
    $str = file_get_contents('php://input');
    $std = json_decode($str);
    
    if ($std === null) {
        // Kiểm tra lỗi JSON
        if (json_last_error() !== JSON_ERROR_NONE) {
            return msg(0, 400, 'Invalid JSON');
        }
        $std = new stdClass();
        $array = explode('&', $str);
        foreach ($array as $parm) {
            $parts = explode('=', $parm);
            if (sizeof($parts) != 2) {
                continue;
            }
            $key = urldecode($parts[0]);
            $value = urldecode($parts[1]);
            $std->$key = $value === '' ? null : $value;
        }
    }
    return $std;
}

$data = getPostObject();
$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0, 405, 'Method Not Allowed');
} elseif (!isset($data->id) || !isset($data->Id) || !isset($data->keyword)) {
    $fields = ['fields' => ['id', 'Id', 'keyword']];
    $returnData = msg(0, 422, 'Please Fill in all Required Fields!', $fields);
} else {
    $Id = trim($data->Id);
    $id = trim($data->id);
    include('class/User.php');

    $Id = 'ma_' . $Id;
    $keyword = trim($data->keyword);
    include_once("config.php");

    $sql = "SELECT * FROM link WHERE idlink='" . mysqli_real_escape_string($mysqli, $id) . "'";
    $result = mysqli_query($mysqli, $sql);

    if (!$result) {
        echo json_encode(msg(0, 500, 'Database query failed: ' . mysqli_error($mysqli)));
        exit;
    }

    $row = mysqli_fetch_array($result);
    $link = $row['url'] ?? null;

    if (!isset($_COOKIE[$Id])) {
        echo json_encode(['success' => false, 'message' => 'Not yet Code.']);
        exit; 
    }

    $ma = $_COOKIE[$Id];

    if ($keyword === $ma) {
        echo json_encode(['success' => true, 'message' => "You entered successfully", 'link' => $link]);
    } else {
        echo json_encode(['success' => false, 'message' => 'You entered code not successful.']);
    }
}
?>