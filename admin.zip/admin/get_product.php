<?php session_set_cookie_params([
    'lifetime' => 0, // Thời gian sống của cookie
    'path' => '/', // Đường dẫn cookie
    'domain' => '', // Miền cookie
    'secure' => true, // Chỉ gửi cookie qua HTTPS
    'httponly' => true, // Ngăn JavaScript truy cập cookie
    'samesite' => 'None' // Cho phép gửi cookie trong ngữ cảnh bên thứ ba
]);
session_start();
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Connection: keep-alive");
header("Content-Encoding: gzip");
header("Content-Type: application/json; charset=UTF-8");
header("Date: Sun, 10 Nov 2024 05:38:01 GMT");
header("Expires: Thu, 19 Nov 1981 08:52:00 GMT");
header("Pragma: no-cache");
header("Server: nginx");
header("Transfer-Encoding: chunked");
header("Vary: Accept-Encoding");
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");
header("X-XSS-Protection: 1; mode=block");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
function msg($success, $status, $message, $extra = []) {
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ], $extra);
}

function getPostObject() {
    $str = file_get_contents('php://input');
    $std = json_decode($str);
    if ($std === null) {
        $std = new stdClass();
        $array = explode('&', $str);
        foreach ($array as $parm) {
            $parts = explode('=', $parm);
            if(sizeof($parts) != 2){
                continue;
            }
            $key = $parts[0];
            $value = $parts[1];
            if ($key === NULL) {
                continue;
            }
            if (is_string($key)) {
                $key = urldecode($key);
            } else {
                continue;
            }
            if (is_bool($value)) {
                $value = boolval($value);
            } else if (is_numeric($value)) {
                $value += 0;
            } else if (is_string($value)) {
                if (empty($value)) {
                    $value = null;
                } else {
                    $lower = strtolower($value);
                    if ($lower === 'true') {
                        $value = true;
                    } else if ($lower === 'false') {
                        $value = false;
                    } else if ($lower === 'null') {
                        $value = null;
                    } else {
                        $value = urldecode($value);
                    }
                }
            } else if (is_array($value)) {
                // value is an array
            } else if (is_object($value)) {
                // value is an object
            }
            $std->$key = $value;
        }
        // length of post array
        //$std->length = sizeof($array);
    }
    return $std;
}

$data = getPostObject();
$returnData = [];
//include('class/User.php');
//$user = new User();
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0, 404, 'Page Not Found!');
} elseif (!isset($data->id)){
    $fields = ['fields' => ['id']]; //id $fields = ['fields' => ['email','password']];
    $returnData = msg(0, 422, 'Please Fill in all Required Fields!', $fields);
} else {
    //$ma = base64_decode(trim($data->ma));
	$id = trim($data->id);
	include('class/User.php');
//include(__DIR__ . '/class/User.php');
$user = new User();
$tableName = 'user';

    // Gọi hàm để lấy dữ liệu
    $result = $user->getData4($tableName); // Lấy tất cả dữ liệu từ bảng
    // Khởi tạo mảng chứa các sản phẩm
$Keywords = [];

// Kiểm tra xem kết quả có dữ liệu không
if (!empty($result)) {
    foreach ($result as $row) {
			 $Keywords[] = array(
			  'Id' => $row['Id'],
            'NameDeltail' => $row['NameDeltail'],
            'Picture' => $row['Picture']);
    }
}
// Khởi tạo mảng chứa dữ liệu đã tách
$keywordsArray = [];

// Lặp qua từng sản phẩm trong kết quả
foreach ($Keywords as $row) {
    // Tách từ khóa từ NameDeltail
    $keys = explode(',', $row['NameDeltail']); // Tách các từ khóa bằng dấu phẩy

    // Lặp qua từng từ khóa và thêm vào mảng mới
    foreach ($keys as $key) {
        $keywordsArray[] = array(
            'Id' => $row['Id'],
            'NameDeltail' => trim($key), // Loại bỏ khoảng trắng
            'Picture' => $row['Picture']
        );
    }
}
	
	
	//$_SESSION['ma']=$ma;
    // $id = $_POST['id'];
    //$tableName = 'detailproduct'; // Tên bảng bạn muốn cập nhật

    // Gọi hàm updateView
    //$isUpdated = $user->updateView($id,$tableName);

  if (count($keywordsArray)) {
        //if (count($result) > 0) {
            echo json_encode(['success' => true, 'data' => $keywordsArray]); // Trả về toàn bộ dữ liệu
        } else {
            echo json_encode(['success' => false, 'message' => 'Không tìm thấy dữ liệu.']);
        }
	
}
?>