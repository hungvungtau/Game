<?php
header('Content-Type: application/json'); // Đặt tiêu đề cho phản hồi JSON

include('class/User.php');
$user = new User();

// register1.php
// Lấy dữ liệu từ POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if($_POST['txtCaptcha'] == NULL)
	{
		//echo "Please enter your code";
		$response['message'] .= "Please enter your code ";
	}
	else
	{
	if($_POST['txtCaptcha'] == $_SESSION['security_code'])
	{
		$userId = $_SESSION['userid']; // Sử dụng ID người dùng từ session
        $Namecategory = $_POST['Namecategory'];
		$Namequestion = $_POST['Namequestion'];
		//Correctanswer
		$Correctanswer = $_POST['Correctanswer'];//Type
		$Type = $_POST['Type'];
    // Lấy dữ liệu từ biểu mẫu
    $answers = $_POST['answers']; // Mảng chứa các đáp án
// Khởi tạo các biến cho từng đáp án
    $answer1 = $answer2 = $answer3 = $answer4 = null;

    // Gán giá trị từ mảng vào các biến
    if (isset($answers[0])) {
        $answer1 = htmlspecialchars($answers[0]);
    }
    if (isset($answers[1])) {
        $answer2 = htmlspecialchars($answers[1]);
    }
    if (isset($answers[2])) {
        $answer3 = htmlspecialchars($answers[2]);
    }
    if (isset($answers[3])) {
        $answer4 = htmlspecialchars($answers[3]);
    }


function getCurrentTime() {
    // Đặt múi giờ nếu cần
    date_default_timezone_set('Asia/Ho_Chi_Minh'); // Thay đổi theo múi giờ bạn muốn

    // Lấy thời gian hiện tại
    $currentTime = date('Y-m-d H:i:s'); // Định dạng: Năm-Tháng-Ngày Giờ:Phút:Giây

    return $currentTime;
}

// Gọi hàm và in ra thời gian hiện tại
$time=getCurrentTime();
  // Kiểm tra và xử lý hình ảnh
            if (isset($_FILES['Image']) && $_FILES['Image']['error'] === UPLOAD_ERR_OK) {
                // Đường dẫn lưu trữ hình ảnh
                $uploadDir = 'images/'; // Đảm bảo thư mục này tồn tại và có quyền ghi
                $uploadFile = $uploadDir . basename($_FILES['Image']['name']);
                
                // Di chuyển tệp hình ảnh vào thư mục đích
                if (move_uploaded_file($_FILES['Image']['tmp_name'], $uploadFile)) {

      }}else{
		    if (isset($_FILES['Image'])) {
        if ($_FILES['Image']['error'] !== UPLOAD_ERR_NO_FILE) {
            // Nếu có lỗi khác ngoài không có tệp tin
            echo "Lỗi tải lên: " . $_FILES['Image']['error'];
        } else {
            // Không có hình ảnh nào được tải lên
            echo "Không có hình ảnh nào được tải lên.";
			$uploadFile="";
        }
    }
	  }
    // Xử lý dữ liệu (ví dụ: in ra)
			//echo "ma lenh hop le";
		 // Gọi hàm addWebsite và kiểm tra kết quả
        $insertResult = $user->Addquestion($Namecategory,$Namequestion,$uploadFile,$answer1,$answer2,$answer3,$answer4,$Correctanswer,$Type,$time);
       
	   
		
			// Khởi tạo phản hồi
			$response = [];

			if (isset($insertResult['rowCount']) && $insertResult['rowCount'] > 0) {
				$response['success'] =$insertResult['success'];
				$response['message'] = $insertResult['message'];
			} else {
				if (isset($insertResult['error'])) {
					$response['message'] = " Error: " . $insertResult['error'];
				}
			}

			
		}
		else
		{
			$message = "Error:Invalid code ";
		}
	}
	
	// Trả về dữ liệu dưới dạng JSON
	
			echo json_encode($response);
			exit; // Đảm bảo không có thêm thông tin nào được in 
				
}
?>