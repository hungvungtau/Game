<?php
header('Content-Type: application/json');

// Lấy dữ liệu từ AJAX
$itemId = $_POST['itemId'];
$email = $_POST['email'];
$name = $_POST['name'];
$price = $_POST['price'];

// Cấu hình thông tin thanh toán
$data = [
    'itemId' => $itemId,
    'email' => $email,
    'name' => $name,
    'price' => $price,
    'returnUrl' => 'YOUR_RETURN_URL', // URL quay lại sau khi thanh toán
];

// Gọi API payOS để thực hiện thanh toán
$response = callPayOSApi($data);

if ($response['success']) {
    echo json_encode(['success' => true, 'transactionId' => $response['transactionId']]);
} else {
    echo json_encode(['success' => false, 'message' => $response['message']]);
}

function callPayOSApi($data) {
    // Thực hiện gọi API của payOS
    // Cần cấu hình thêm các thông tin như API key, endpoint, và mã hóa nếu cần
    // Trả về phản hồi từ payOS
}
?>