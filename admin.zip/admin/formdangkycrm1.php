<html lang='en_us'><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></head><body><style type="text/css"><!--
form#WebToLeadForm, form#WebToLeadForm * {margin: 0; padding: 0; border: none; color: #333; font-size: 12px; line-height: 1.6em; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;}
form#WebToLeadForm {float: left; border: 1px solid #ccc; margin: 10px;}
form#WebToLeadForm h1 {font-size: 32px; font-weight: bold; background-color: rgb(60, 141, 188); color: rgb(247, 247, 247); padding: 10px 20px;}
form#WebToLeadForm h2 {font-size: 24px; font-weight: bold; background-color: rgb(60, 141, 188); color: rgb(247, 247, 247); padding: 10px 20px;}
form#WebToLeadForm h3 {font-size: 12px; font-weight: bold; padding: 10px 20px;}
form#WebToLeadForm h4 {font-size: 10px; font-weight: bold; padding: 10px 20px;}
form#WebToLeadForm h5 {font-size: 8px; font-weight: bold; padding: 10px 20px;}
form#WebToLeadForm h6 {font-size: 6px; font-weight: bold; padding: 10px 20px;}
form#WebToLeadForm p {padding: 10px 20px;}
form#WebToLeadForm input,
form#WebToLeadForm select,
form#WebToLeadForm textarea {border: 1px solid #ccc; display: block; float: left; min-width: 170px; padding: 5px;}
form#WebToLeadForm select {background-color: white;}
form#WebToLeadForm input[type="button"],
form#WebToLeadForm input[type="submit"] {display: inline; float: none; padding: 5px 10px; width: auto; min-width: auto;}
form#WebToLeadForm input[type="checkbox"],
form#WebToLeadForm input[type="radio"] {width: 18px; min-width: auto;}
form#WebToLeadForm div.col {display: block; float: left; width: 330px; padding: 10px 20px;}
form#WebToLeadForm div.clear {display: block; float: none; clear: both; height: 0px; overflow: hidden;}
form#WebToLeadForm div.center {text-align: center;}
form#WebToLeadForm div.buttons {padding: 10px 0; border-top: 1px solid #ccc; background-color: #f7f7f7}
form#WebToLeadForm label {display: block; float: left; width: 160px; font-weight: bold;}
form#WebToLeadForm span.required {color: #FF0000;}
--></style>
<script type='text/javascript'> window.onload = detectarCarga; function detectarCarga() { document.getElementById("imgLOAD").style.display="none"; document.getElementById("WholePage").style.display=""; } </script> <div id="imgLOAD" style="position:fixed;top:210px;right:610px;border:0px solid gray;padding:10px; background: " align="center"> Vui lòng chờ giây lát ...<br/> <img src="http://img165.imageshack.us/img165/1922/loadinganimationliferaysd8.gif" border=0><br>www.bizcrmweb.com</div> <DIV id="WholePage" style="display:none">
<!-- TODO ??
<script type=\"text/javascript\" src='http://crm1.bizcrmweb.com/cache/include/javascript/sugar_grp1.js?v=oJiQgAT4QKqZKSuO3FUQfA'></script>
<?php echo "
--><form id=\"WebToLeadForm\" action=\"http://crm1.bizcrmweb.com/index.php?entryPoint=WebToPersonCapture\" method=\"POST\" name=\"WebToLeadForm\">
<h2>Bạn vui lòng chờ 1 phút. Xin cảm ơn</h2>
<p></p>
<div class=\"row\">
<div class=\"col\"><label> </label><input name=\"first_name\" id=\"first_name\" type=\"hidden\" value=\"$first_name\" /></div>
<div class=\"clear\"></div>
</div>
<div class=\"row\">
<div class=\"col\"><label> <span class=\"required\">*</span></label><input name=\"last_name\" id=\"last_name\" type=\"hidden\" required=\"\" value=\"$last_name\"/></div>
<div class=\"clear\"> </div>
</div>
<div class=\"row\">
<div class=\"col\"><label> </label><input name=\"department\" id=\"department\" type=\"hidden\" value=\"$department\"/></div>
<div class=\"clear\">? </div>
</div>
<div class=\"row\">
<div class=\"col\"><label> </label><input name=\"phone_mobile\" id=\"phone_mobile\" type=\"hidden\" value=\"$phone_mobile\" /></div>
<div class=\"clear\"> </div>
</div>
<div class=\"row\">
<div class=\"col\"><label> </label><input name=\"email1\" id=\"email1\" type=\"hidden\" value=\"$email\"/></div>
<div class=\"clear\"> </div>
</div>
<div class=\"row\">
<div class=\"col\"><label> </label><input name=\"birthdate\" id=\"birthdate\" type=\"hidden\" value=\"$birthdate\"/></div>
<div class=\"clear\"> </div>
</div>
<div class=\"row\">
<div class=\"col\"><label></label><span class=\"sugarslot\"><textarea type=\"hidden\" name=\"description\" id=\"description\" value=\"$description\"  /> </textarea></span></div>
<div class=\"clear\"></div>
</div>
<div class=\"row center buttons\"><input class=\"button\" id=\"Submit\" name=\"Submit\" type=\"hidden\" value=\"Submit\" onclick=\"submit_form();\"  />
<div class=\"clear\"></div>
</div>
<input name=\"campaign_id\" id=\"campaign_id\" type=\"hidden\" value=\"2313f670-f69b-95f9-9162-58c8aaf063a7\" /> <input name=\"redirect_url\" id=\"redirect_url\" type=\"hidden\" value=\"http://register1.bizcrmweb.com/chuyentrang.html\" /> <input name=\"assigned_user_id\" id=\"assigned_user_id\" type=\"hidden\" value=\"1\" /> <input name=\"moduleDir\" id=\"moduleDir\" type=\"hidden\" value=\"Leads\" /></form>
<p>
<script type=\"text/javascript\">// <![CDATA[
    function submit_form() {
        if (typeof(validateCaptchaAndSubmit) != 'undefined') {
            validateCaptchaAndSubmit();
        } else {
            check_webtolead_fields();
            //document.WebToLeadForm.submit();
        }
    }

    function check_webtolead_fields() {
        if (document.getElementById('bool_id') != null) {
            var reqs = document.getElementById('bool_id').value;
            bools = reqs.substring(0, reqs.lastIndexOf(';'));
            var bool_fields = new Array();
            var bool_fields = bools.split(';');
            nbr_fields = bool_fields.length;
            for (var i = 0; i < nbr_fields; i++) {
                if (document.getElementById(bool_fields[i]).value == 'on') {
                    document.getElementById(bool_fields[i]).value = 1;
                } else {
                    document.getElementById(bool_fields[i]).value = 0;
                }
            }
        }
    }
// ]]></script>
<script type=\"text/javascript\">
document.getElementById('WebToLeadForm').submit(); 
</script>";?>
</p></body></html>