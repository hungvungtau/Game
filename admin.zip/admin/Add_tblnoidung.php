<?php
session_start(); // ← LỖI CHÍNH: thiếu dòng này nên $_SESSION['security_code'] luôn rỗng
header('Content-Type: application/json');

include('class/UserLink.php');

$user     = new User1();
$response = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (empty($_POST['txtCaptcha'])) {
        echo json_encode(['success' => false, 'message' => 'Vui lòng nhập mã xác nhận']);
        exit;
    }

    if ($_POST['txtCaptcha'] != $_SESSION['security_code']) {
        echo json_encode(['success' => false, 'message' => 'Mã xác nhận không đúng']);
        exit;
    }

    $imageName = '';

    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $uploadDir = '../uploads/';
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        $imageName = time() . '_' . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $imageName);
    }

    $data = array(
        'id_chuong'    => $_POST['id_chuong'],
        'ten_noidung'  => $_POST['ten_noidung'],
        'type'         => $_POST['type'],
        'placeholder'  => $_POST['placeholder'],
        'Namefunction' => $_POST['Namefunction'],
        'Folder'       => $_POST['Folder'],
        'Linkvideo'    => $_POST['Linkvideo'],
        'image'        => $imageName,
        'active'       => $_POST['active'],
    );

    $insertResult = $user->addNoiDung($data);

    echo json_encode($insertResult);
    exit;
}
?>